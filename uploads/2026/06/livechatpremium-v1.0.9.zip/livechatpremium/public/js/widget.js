/**
 * LiveChatPremium — Widget visiteur v1.0.5
 */
(function() {
  'use strict';

  var cfg   = window.LCP_Config || {};
  var state = {
    open: false, sessionToken: null, visitorId: null,
    visitorName: null, visitorPhone: null,
    pusher: null, channel: null, msgIds: new Set(),
    recording: false, mediaRecorder: null, audioChunks: [],
    recInterval: null, recSeconds: 0, typingTimeout: null,
  };

  function init() {
    state.visitorId    = getOrCreate('lcp_visitor_id', 'v_' + rand());
    state.visitorName  = localStorage.getItem('lcp_visitor_name')  || null;
    state.visitorPhone = localStorage.getItem('lcp_visitor_phone') || null;
    state.sessionToken = localStorage.getItem('lcp_session_token') || null;

    bindToggle();

    // Restaurer session si elle existe
    if (state.sessionToken) {
      restoreSession();
    }
  }

  function getOrCreate(key, val) {
    var v = localStorage.getItem(key);
    if (!v) { v = val; localStorage.setItem(key, v); }
    return v;
  }
  function rand() { return Math.random().toString(36).substr(2,16); }

  /* ── Toggle ──────────────────────────────────────── */
  function bindToggle() {
    var btn   = document.getElementById('lcp-toggle-btn');
    var close = document.getElementById('lcp-close-btn');
    if (btn)   btn.addEventListener('click', toggle);
    if (close) close.addEventListener('click', closeWidget);
  }

  function toggle() { state.open ? closeWidget() : openWidget(); }

  function openWidget() {
    var popup = document.getElementById('lcp-popup');
    if (!popup) return;
    popup.style.display = 'flex';
    state.open = true;
    var icon = document.getElementById('lcp-btn-icon');
    if (icon) icon.textContent = '✕';
    clearUnreadBadge();

    if (state.sessionToken) {
      showScreen('lcp-chat-screen');
      loadMessages();
      if (!state.channel) initPusherForSession(state.sessionToken);
    } else {
      startFlow();
    }
  }

  function closeWidget() {
    var popup = document.getElementById('lcp-popup');
    if (popup) popup.style.display = 'none';
    state.open = false;
    var icon = document.getElementById('lcp-btn-icon');
    if (icon) icon.textContent = cfg.icon || '💬';
  }

  /* ── Flux d'entrée ───────────────────────────────── */
  function startFlow() {
    // Si déjà identifié → RGPD ou chat
    if (state.visitorName && state.visitorPhone) {
      afterIdentity();
      return;
    }
    // Sinon → formulaire identité
    showScreen('lcp-identity-screen');
    bindIdentityForm();
  }

  function bindIdentityForm() {
    var form = document.getElementById('lcp-identity-form');
    if (!form || form._bound) return;
    form._bound = true;
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      var name  = document.getElementById('lcp-identity-name').value.trim();
      var phone = document.getElementById('lcp-identity-phone').value.trim();
      if (!name || !phone) { showFormError('Veuillez remplir tous les champs.'); return; }
      if (!/^[\d\s\+\-\(\)]{7,20}$/.test(phone)) { showFormError('Numéro de téléphone invalide.'); return; }
      state.visitorName  = name;
      state.visitorPhone = phone;
      localStorage.setItem('lcp_visitor_name',  name);
      localStorage.setItem('lcp_visitor_phone', phone);
      afterIdentity();
    });
  }

  function showFormError(msg) {
    var el = document.getElementById('lcp-identity-error');
    if (el) { el.textContent = msg; el.style.display = 'block'; }
  }

  function afterIdentity() {
    if (cfg.rgpd_enabled && !localStorage.getItem('lcp_rgpd_consent')) {
      showScreen('lcp-rgpd-screen');
      bindRgpd();
    } else {
      afterConsent();
    }
  }

  function bindRgpd() {
    var accept  = document.getElementById('lcp-accept-rgpd');
    var decline = document.getElementById('lcp-decline-rgpd');
    if (accept && !accept._bound) {
      accept._bound = true;
      accept.addEventListener('click', function() {
        localStorage.setItem('lcp_rgpd_consent','1');
        afterConsent();
      });
    }
    if (decline && !decline._bound) {
      decline._bound = true;
      decline.addEventListener('click', closeWidget);
    }
  }

  function afterConsent() {
    if (!cfg.is_online) { showOfflineScreen(); return; }
    showScreen('lcp-welcome-screen');
    var msg = document.getElementById('lcp-welcome-message');
    if (msg) msg.textContent = 'Bonjour ' + (state.visitorName || '') + ' ! ' + (cfg.online_message || 'Comment puis-je vous aider ?');
    var startBtn = document.getElementById('lcp-start-chat');
    if (startBtn && !startBtn._bound) {
      startBtn._bound = true;
      startBtn.addEventListener('click', function() {
        startSession();
      });
    }
  }

  /* ── Session ─────────────────────────────────────── */
  async function startSession() {
    showScreen('lcp-chat-screen');
    setStatusLabel(false, 'Connexion...');

    try {
      var res = await api('session/start', {
        visitor_id:   state.visitorId,
        visitor_name: state.visitorName,
        visitor_phone:state.visitorPhone,
        page_url:     window.location.href,
        referrer:     document.referrer,
      });
      if (!res.success) { setStatusLabel(false, 'Erreur de connexion'); return; }

      state.sessionToken = res.session_token;
      localStorage.setItem('lcp_session_token', res.session_token);

      initPusherForSession(res.session_token);
      bindInput();
      trackPageView();

      // Message de bienvenue système
      appendMsg({ sender_type:'system', content:'Chat démarré. Un agent va vous répondre.', sent_at: new Date().toISOString() });

    } catch(e) { setStatusLabel(false, 'Erreur réseau'); console.error(e); }
  }

  async function restoreSession() {
    try {
      var res = await api('session/messages?session_token=' + state.sessionToken, null, 'GET');
      if (!res.success) {
        // Session expirée
        localStorage.removeItem('lcp_session_token');
        state.sessionToken = null;
        return;
      }
      if (state.open) {
        showScreen('lcp-chat-screen');
        var container = document.getElementById('lcp-chat-messages');
        if (container) container.innerHTML = '';
        (res.messages || []).forEach(appendMsg);
        scrollBottom();
        initPusherForSession(state.sessionToken);
        bindInput();
      }
    } catch(e) {}
  }

  /* ── Pusher ──────────────────────────────────────── */
  function initPusherForSession(token) {
    if (!cfg.pusher_key || !window.Pusher || state.channel) return;

    state.pusher = new Pusher(cfg.pusher_key, {
      cluster: cfg.pusher_cluster,
      authEndpoint: cfg.ajax_url + '?action=lcp_pusher_auth',
      auth: {
        params: { nonce: cfg.nonce },
        headers: { 'X-WP-Nonce': cfg.nonce },
      },
    });

    var channelName = 'private-lcp-session-' + token;
    state.channel = state.pusher.subscribe(channelName);

    state.channel.bind('new-message',    function(d) { appendMsg(d); scrollBottom(); hideTyping(); if (!state.open) showUnreadBadge(); });
    state.channel.bind('push-page',      onPushPage);
    state.channel.bind('typing',         function(d) { if (d.sender==='agent') showTyping(); });
    state.channel.bind('session-closed', onSessionClosed);

    state.pusher.connection.bind('connected',    function() { setStatusLabel(true, 'En ligne'); });
    state.pusher.connection.bind('disconnected', function() { setStatusLabel(false, 'Hors ligne'); });
  }

  /* ── Écrans ──────────────────────────────────────── */
  function showScreen(id) {
    ['lcp-identity-screen','lcp-rgpd-screen','lcp-welcome-screen','lcp-chat-screen','lcp-offline-screen'].forEach(function(s) {
      var el = document.getElementById(s);
      if (el) el.style.display = 'none';
    });
    var target = document.getElementById(id);
    if (target) target.style.display = 'flex';
  }

  function setStatusLabel(online, text) {
    var dot   = document.getElementById('lcp-online-dot');
    var label = document.getElementById('lcp-status-label');
    if (dot)   dot.className = 'lcp-status-dot ' + (online ? 'lcp-dot-online' : 'lcp-dot-offline');
    if (label) label.textContent = text || (online ? 'En ligne' : 'Hors ligne');
  }

  function showOfflineScreen() {
    showScreen('lcp-offline-screen');
    var sendBtn = document.getElementById('lcp-send-offline');
    if (sendBtn && !sendBtn._bound) {
      sendBtn._bound = true;
      sendBtn.addEventListener('click', sendOfflineMessage);
    }
  }

  /* ── Messages ────────────────────────────────────── */
  async function loadMessages() {
    if (!state.sessionToken) return;
    try {
      var res = await api('session/messages?session_token=' + state.sessionToken, null, 'GET');
      if (!res.success) return;
      var container = document.getElementById('lcp-chat-messages');
      if (container) container.innerHTML = '';
      (res.messages || []).forEach(appendMsg);
      scrollBottom();
      setStatusLabel(true, 'En ligne');
      bindInput();
    } catch(e) {}
  }

  function appendMsg(msg) {
    var container = document.getElementById('lcp-chat-messages');
    if (!container) return;
    // Dédoublonnage par ID
    if (msg.id) {
      if (state.msgIds.has(String(msg.id))) return;
      state.msgIds.add(String(msg.id));
    }

    if (msg.type === 'system' || msg.sender_type === 'system') {
      var sys = document.createElement('div');
      sys.className = 'lcp-msg-system';
      sys.innerHTML = '<small>' + esc(msg.content) + '</small>';
      container.appendChild(sys);
      scrollBottom();
      return;
    }

    var isMine = msg.sender_type === 'visitor';
    var div = document.createElement('div');
    div.className = 'lcp-msg ' + (isMine ? 'lcp-msg-out' : 'lcp-msg-in');

    var content = '';
    var time = msg.sent_at ? new Date(msg.sent_at).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}) : '';

    switch (msg.type) {
      case 'image':
        content = '<img src="'+esc(msg.file_url)+'" class="lcp-msg-image" alt="" loading="lazy">';
        break;
      case 'audio':
        content = '<audio controls src="'+esc(msg.file_url)+'" class="lcp-msg-audio"></audio>';
        break;
      case 'pdf': case 'file':
        content = '<a href="'+esc(msg.file_url)+'" target="_blank" class="lcp-msg-file">📎 '+esc(msg.file_name||'Fichier')+'</a>';
        break;
      case 'page':
        content = '<a href="'+esc(msg.file_url)+'" class="lcp-msg-page-link" target="_blank">🔗 '+esc(msg.content||msg.file_url)+'</a>';
        break;
      case 'product':
        var meta = {};
        try { meta = typeof msg.metadata==='string' ? JSON.parse(msg.metadata||'{}') : (msg.metadata||{}); } catch(e){}
        content = '<div class="lcp-msg-product">'+(meta.image?'<img src="'+esc(meta.image)+'" alt="">':'')+'<div class="lcp-product-info"><strong>'+esc(meta.title||msg.content)+'</strong><span class="lcp-price">'+( meta.price||'')+'</span><a href="'+esc(msg.file_url||meta.url||'#')+'" target="_blank" class="lcp-view-product">Voir →</a></div></div>';
        break;
      default:
        content = '<p>'+esc(msg.content)+'</p>';
    }

    div.innerHTML = '<div class="lcp-msg-bubble">'+content+'<span class="lcp-msg-time">'+time+'</span></div>';
    container.appendChild(div);
    scrollBottom();
  }

  /* ── Input ───────────────────────────────────────── */
  function bindInput() {
    var input    = document.getElementById('lcp-visitor-input');
    var sendBtn  = document.getElementById('lcp-visitor-send');
    var fileInput= document.getElementById('lcp-visitor-file');
    var attachBtn= document.getElementById('lcp-attach-btn');
    var audioBtn = document.getElementById('lcp-audio-btn');

    if (input && !input._bound) {
      input._bound = true;
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendText(); }
      });
      input.addEventListener('input', function() {
        sendTypingIndicator();
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 100) + 'px';
      });
      // Fix mobile : scroll vers le bas quand le clavier s'ouvre
      input.addEventListener('focus', function() {
        setTimeout(scrollBottom, 400);
      });
    }
    if (sendBtn && !sendBtn._bound) { sendBtn._bound = true; sendBtn.addEventListener('click', sendText); }
    if (attachBtn && !attachBtn._bound) { attachBtn._bound = true; attachBtn.addEventListener('click', function(){ if(fileInput) fileInput.click(); }); }
    if (fileInput && !fileInput._bound) { fileInput._bound = true; fileInput.addEventListener('change', function(e){ if(e.target.files[0]) sendFile(e.target.files[0]); }); }
    if (audioBtn && !audioBtn._bound) { audioBtn._bound = true; audioBtn.addEventListener('click', startRecording); }

    var stopRec   = document.getElementById('lcp-stop-visitor-rec');
    var cancelRec = document.getElementById('lcp-cancel-visitor-rec');
    if (stopRec   && !stopRec._bound)   { stopRec._bound=true;   stopRec.addEventListener('click',   function(){ stopRecording(true);  }); }
    if (cancelRec && !cancelRec._bound) { cancelRec._bound=true; cancelRec.addEventListener('click', function(){ stopRecording(false); }); }
  }

  async function sendText() {
    var input = document.getElementById('lcp-visitor-input');
    if (!input) return;
    var text = input.value.trim();
    if (!text || !state.sessionToken) return;
    input.value = ''; input.style.height = 'auto';

    // Affichage optimiste
    appendMsg({ sender_type:'visitor', type:'text', content:text, sent_at:new Date().toISOString() });

    await api('message/send', { session_token:state.sessionToken, content:text, type:'text' });
  }

  function sendTypingIndicator() {
    if (!state.sessionToken) return;
    clearTimeout(state.typingTimeout);
    api('message/typing', { session_token:state.sessionToken, sender:'visitor' });
    state.typingTimeout = setTimeout(function(){}, 2000);
  }

  async function sendFile(file) {
    var maxMb = cfg.max_file_size || 5;
    if (file.size > maxMb * 1024 * 1024) { alert('Fichier trop volumineux (max '+maxMb+'Mo)'); return; }
    var fd = new FormData();
    fd.append('file', file);
    fd.append('session_token', state.sessionToken);
    try {
      var r = await fetch(cfg.rest_url+'/upload', { method:'POST', headers:{'X-WP-Nonce':cfg.nonce}, body:fd });
      var d = await r.json();
      if (d.success) {
        appendMsg({ sender_type:'visitor', type:d.type, content:d.name, file_url:d.url, file_name:d.name, sent_at:new Date().toISOString() });
        await api('message/send', { session_token:state.sessionToken, type:d.type, content:d.name, file_url:d.url, file_name:d.name });
      }
    } catch(e) { console.error('LCP upload',e); }
  }

  /* ── Audio ───────────────────────────────────────── */
  async function startRecording() {
    try {
      var stream = await navigator.mediaDevices.getUserMedia({audio:true});
      state.mediaRecorder = new MediaRecorder(stream);
      state.audioChunks = []; state.recSeconds = 0;
      state.mediaRecorder.ondataavailable = function(e){ if(e.data.size>0) state.audioChunks.push(e.data); };
      state.mediaRecorder.start();
      state.recording = true;
      var rec = document.getElementById('lcp-visitor-recorder');
      var ab  = document.getElementById('lcp-audio-btn');
      if (rec) rec.style.display = 'flex';
      if (ab)  ab.style.display  = 'none';
      state.recInterval = setInterval(function(){
        state.recSeconds++;
        var m=Math.floor(state.recSeconds/60), s=state.recSeconds%60;
        var el=document.getElementById('lcp-visitor-rec-time');
        if(el) el.textContent=m+':'+(s<10?'0':'')+s;
      },1000);
    } catch(e) { alert('Microphone non disponible'); }
  }

  function stopRecording(send) {
    if (!state.mediaRecorder) return;
    clearInterval(state.recInterval);
    state.recording = false;
    state.mediaRecorder.stream.getTracks().forEach(function(t){ t.stop(); });
    if (send) {
      state.mediaRecorder.onstop = function(){
        var blob = new Blob(state.audioChunks, {type:'audio/ogg; codecs=opus'});
        sendFile(new File([blob],'vocal_'+Date.now()+'.ogg',{type:'audio/ogg'}));
      };
    }
    state.mediaRecorder.stop();
    var rec=document.getElementById('lcp-visitor-recorder'), ab=document.getElementById('lcp-audio-btn');
    if(rec) rec.style.display='none';
    if(ab)  ab.style.display='';
  }

  /* ── Pusher events ───────────────────────────────── */
  function onPushPage(data) {
    if (!data.url) return;
    appendMsg({ sender_type:'agent', type:'page', content:data.title||data.url, file_url:data.url, sent_at:new Date().toISOString() });
    scrollBottom();
    setTimeout(function(){
      if (confirm('💬 L\'agent vous suggère : '+(data.title||data.url)+'\n\nOuvrir cette page ?')) {
        window.location.href = data.url;
      }
    },300);
  }

  function onSessionClosed() {
    appendMsg({ sender_type:'system', content:'La conversation a été fermée.', sent_at:new Date().toISOString() });
    localStorage.removeItem('lcp_session_token');
    state.sessionToken = null;
    state.channel = null;
  }

  function showTyping() {
    var el = document.getElementById('lcp-visitor-typing');
    if (el) el.style.display = 'flex';
    setTimeout(function(){ if(el) el.style.display='none'; }, 3000);
  }
  function hideTyping() {
    var el = document.getElementById('lcp-visitor-typing');
    if (el) el.style.display = 'none';
  }

  function showOfflineMsg() { showScreen('lcp-offline-screen'); }

  async function sendOfflineMessage() {
    var msg   = (document.getElementById('lcp-offline-msg')  ||{}).value||'';
    var email = (document.getElementById('lcp-offline-email')||{}).value||'';
    if (!msg.trim()) return;
    if (state.sessionToken) {
      await api('message/send', { session_token:state.sessionToken, content:(email?'['+email+'] ':'')+msg, type:'text' });
    }
    var el = document.getElementById('lcp-offline-screen');
    if (el) el.innerHTML = '<div class="lcp-offline-content"><div class="lcp-offline-icon">✅</div><h3>Message envoyé !</h3><p>Nous vous répondrons dès que possible.</p></div>';
  }

  /* ── Unread badge ────────────────────────────────── */
  function showUnreadBadge() {
    var b = document.getElementById('lcp-unread-badge');
    if (!b) return;
    b.textContent = parseInt(b.textContent||'0') + 1;
    b.style.display = 'flex';
  }
  function clearUnreadBadge() {
    var b = document.getElementById('lcp-unread-badge');
    if (b) { b.textContent='0'; b.style.display='none'; }
  }

  function scrollBottom() {
    var el = document.getElementById('lcp-chat-messages');
    if (el) el.scrollTop = el.scrollHeight;
  }

  function trackPageView() {
    if (!state.sessionToken) return;
    api('event/track', { session_token:state.sessionToken, type:'page_view', page_url:window.location.href, payload:{title:document.title} });
  }

  function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  async function api(endpoint, body, method) {
    method = method || 'POST';
    var url = cfg.rest_url + '/' + endpoint;
    var opts = { method:method, headers:{'Content-Type':'application/json','X-WP-Nonce':cfg.nonce} };
    if (body && method !== 'GET') opts.body = JSON.stringify(body);
    var r = await fetch(url, opts);
    return r.json();
  }

  // Tracking navigation SPA
  window.addEventListener('popstate', function(){ if(state.sessionToken) trackPageView(); });

  // Démarrage
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.LiveChatPremium = { state: state };
})();
