<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Frontend {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', [$this, 'enqueue_assets'] );
        add_action( 'wp_footer',          [$this, 'render_widget'] );
    }

    public function enqueue_assets() {
        if ( ! LCP_Pusher::is_configured() ) return;
        wp_enqueue_script('pusher-js', 'https://js.pusher.com/8.3.0/pusher.min.js', [], null, true);
        wp_enqueue_script('lcp-widget', LCP_PLUGIN_URL . 'public/js/widget.js', ['pusher-js'], LCP_VERSION, true);
        wp_enqueue_style('lcp-widget', LCP_PLUGIN_URL . 'public/css/widget.css', [], LCP_VERSION);
        wp_localize_script('lcp-widget', 'LCP_Config', LCP_Session::get_widget_config());
    }

    public function render_widget() {
        if ( ! LCP_Pusher::is_configured() ) return;
        if ( is_admin() ) return;

        $pos   = get_option('lcp_widget_position', 'bottom-right');
        $color = get_option('lcp_widget_color', '#6366f1');
        $icon  = get_option('lcp_widget_icon', '💬');
        $text  = get_option('lcp_widget_text', 'Besoin d\'aide ?');
        $w     = (int) get_option('lcp_popup_width', 380);
        $h     = (int) get_option('lcp_popup_height', 500);
        $sizes = ['small'=>48,'medium'=>56,'large'=>64];
        $btn   = $sizes[get_option('lcp_widget_size','medium')] ?? 56;
        ?>
        <div id="lcp-widget-root" style="--lcp-color:<?php echo esc_attr($color);?>;--lcp-width:<?php echo $w;?>px;--lcp-height:<?php echo $h;?>px;--lcp-btn-size:<?php echo $btn;?>px;">

          <!-- Bouton -->
          <button id="lcp-toggle-btn" class="lcp-toggle-btn lcp-pos-<?php echo esc_attr($pos);?>" aria-label="<?php echo esc_attr($text);?>">
            <span class="lcp-btn-icon" id="lcp-btn-icon"><?php echo esc_html($icon);?></span>
            <span class="lcp-btn-text"><?php echo esc_html($text);?></span>
            <span class="lcp-unread-badge" id="lcp-unread-badge" style="display:none;">0</span>
          </button>

          <!-- Pop-up -->
          <div id="lcp-popup" class="lcp-popup lcp-popup-<?php echo esc_attr($pos);?>" style="display:none;" role="dialog">

            <!-- Header -->
            <div class="lcp-popup-header">
              <div class="lcp-popup-brand">
                <span class="lcp-popup-icon"><?php echo esc_html($icon);?></span>
                <div>
                  <div class="lcp-popup-title"><?php echo esc_html(get_bloginfo('name'));?></div>
                  <div class="lcp-popup-status">
                    <span class="lcp-status-dot lcp-dot-offline" id="lcp-online-dot"></span>
                    <span id="lcp-status-label"><?php _e('Connexion...','livechatpremium');?></span>
                  </div>
                </div>
              </div>
              <button id="lcp-close-btn" class="lcp-close-btn">✕</button>
            </div>

            <!-- ÉCRAN IDENTITÉ -->
            <div id="lcp-identity-screen" class="lcp-screen" style="display:none;">
              <div class="lcp-identity-content">
                <div class="lcp-identity-icon">👋</div>
                <h3>Avant de commencer</h3>
                <p>Identifiez-vous pour que nous puissions vous contacter.</p>
                <form id="lcp-identity-form" novalidate>
                  <div class="lcp-form-group">
                    <input type="text" id="lcp-identity-name" class="lcp-form-input" placeholder="Votre prénom *" required autocomplete="given-name">
                  </div>
                  <div class="lcp-form-group">
                    <input type="tel" id="lcp-identity-phone" class="lcp-form-input" placeholder="Votre téléphone (ex: +212661...) *" required autocomplete="tel">
                  </div>
                  <div id="lcp-identity-error" class="lcp-form-error" style="display:none;"></div>
                  <button type="submit" class="lcp-btn-primary-full">Démarrer le chat →</button>
                </form>
              </div>
            </div>

            <!-- ÉCRAN RGPD -->
            <div id="lcp-rgpd-screen" class="lcp-screen" style="display:none;">
              <div class="lcp-rgpd-content">
                <div class="lcp-rgpd-icon">🔒</div>
                <p class="lcp-rgpd-text"><?php echo wp_kses_post(LCP_Rgpd::get_consent_text());?></p>
                <button id="lcp-accept-rgpd" class="lcp-btn-primary-full"><?php _e('Accepter et démarrer','livechatpremium');?></button>
                <button id="lcp-decline-rgpd" class="lcp-btn-ghost"><?php _e('Refuser','livechatpremium');?></button>
              </div>
            </div>

            <!-- ÉCRAN ACCUEIL -->
            <div id="lcp-welcome-screen" class="lcp-screen" style="display:none;">
              <div class="lcp-welcome-content">
                <div class="lcp-welcome-icon"><?php echo esc_html($icon);?></div>
                <h3><?php echo esc_html(get_bloginfo('name'));?></h3>
                <p id="lcp-welcome-message"></p>
                <button id="lcp-start-chat" class="lcp-btn-primary-full"><?php _e('Démarrer le chat','livechatpremium');?></button>
              </div>
            </div>

            <!-- ÉCRAN CHAT -->
            <div id="lcp-chat-screen" class="lcp-screen" style="display:none;">
              <div class="lcp-chat-messages" id="lcp-chat-messages" role="log" aria-live="polite"></div>
              <div class="lcp-typing-bar" id="lcp-visitor-typing" style="display:none;">
                <div class="lcp-typing-dots"><span></span><span></span><span></span></div>
                <small><?php _e('En train d\'écrire...','livechatpremium');?></small>
              </div>
              <div class="lcp-chat-input-area">
                <?php if(get_option('lcp_file_upload_enabled','1')=='1'):?>
                <div class="lcp-input-tools">
                  <button class="lcp-tool" id="lcp-attach-btn" title="Fichier">📎</button>
                  <button class="lcp-tool" id="lcp-audio-btn" title="Vocal">🎤</button>
                  <input type="file" id="lcp-visitor-file" style="display:none;" accept="image/*,.pdf,.mp3,.ogg,.wav">
                </div>
                <?php endif;?>
                <div class="lcp-input-row">
                  <textarea id="lcp-visitor-input" placeholder="<?php _e('Votre message...','livechatpremium');?>" rows="1"></textarea>
                  <button id="lcp-visitor-send" class="lcp-send">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                  </button>
                </div>
                <div id="lcp-visitor-recorder" style="display:none;" class="lcp-visitor-rec">
                  <span class="lcp-rec-dot">⏺</span>
                  <span id="lcp-visitor-rec-time">0:00</span>
                  <button id="lcp-stop-visitor-rec" class="lcp-rec-stop"><?php _e('Envoyer','livechatpremium');?></button>
                  <button id="lcp-cancel-visitor-rec" class="lcp-rec-cancel"><?php _e('Annuler','livechatpremium');?></button>
                </div>
              </div>
            </div>

            <!-- ÉCRAN HORS LIGNE -->
            <div id="lcp-offline-screen" class="lcp-screen" style="display:none;">
              <div class="lcp-offline-content">
                <div class="lcp-offline-icon">😴</div>
                <h3><?php _e('Nous sommes absents','livechatpremium');?></h3>
                <p><?php echo esc_html(get_option('lcp_offline_message','Laissez-nous un message !'));?></p>
                <textarea id="lcp-offline-msg" placeholder="Votre message..." class="lcp-offline-textarea"></textarea>
                <input type="email" id="lcp-offline-email" placeholder="Votre email" class="lcp-offline-input">
                <button id="lcp-send-offline" class="lcp-btn-primary-full"><?php _e('Envoyer','livechatpremium');?></button>
              </div>
            </div>

          </div><!-- #lcp-popup -->
        </div>
        <?php
    }
}
