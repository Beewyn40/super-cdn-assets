<?php
/**
 * Plugin Name:       LiveChatPremium
 * Plugin URI:        https://o-k.ma
 * Description:       Chat live professionnel avec visiteurs — temps réel Pusher, IA Groq, push de contenu WooCommerce, vocal, fichiers, RGPD.
 * Version:           1.0.9
 * Author:            LiveChatPremium
 * Author URI:        https://o-k.ma
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       livechatpremium
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Constantes
define( 'LCP_VERSION',     '1.0.9' );
define( 'LCP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'LCP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'LCP_PLUGIN_FILE', __FILE__ );
define( 'LCP_DB_VERSION',  '1.0' );

// Autoload classes
spl_autoload_register( function( $class ) {
    $prefix = 'LCP_';
    if ( strpos( $class, $prefix ) !== 0 ) return;
    $file = LCP_PLUGIN_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', substr( $class, 4 ) ) ) . '.php';
    if ( file_exists( $file ) ) require_once $file;
});

// Activation / Désactivation
register_activation_hook(   __FILE__, ['LCP_Installer', 'activate'] );
register_deactivation_hook( __FILE__, ['LCP_Installer', 'deactivate'] );

// Démarrage
add_action( 'plugins_loaded', function() {
    require_once LCP_PLUGIN_DIR . 'includes/class-installer.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-core.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-settings.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-database.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-pusher.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-groq.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-session.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-messages.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-upload.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-rgpd.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-woocommerce.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-translation.php';
    require_once LCP_PLUGIN_DIR . 'includes/class-rest-api.php';
    require_once LCP_PLUGIN_DIR . 'admin/class-admin.php';
    require_once LCP_PLUGIN_DIR . 'public/class-frontend.php';

    LCP_Core::get_instance();
});
