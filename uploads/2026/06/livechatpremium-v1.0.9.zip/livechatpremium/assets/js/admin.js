/**
 * LiveChatPremium — Admin JS v1.0.3
 */
(function() {
  'use strict';

  const cfg = window.LCP_Admin || {};

  /* ═══════════════════════════════════════════════════
     SETTINGS PAGE — indépendant de Pusher
  ═══════════════════════════════════════════════════ */
  function initSettings() {
    const wrap = document.getElementById('lcp-settings');
    if (!wrap) return;

    // ── Navigation onglets ────────────────────────────
    document.querySelectorAll('.lcp-snav').forEach(function(btn) {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.lcp-snav').forEach(function(b) { b.classList.remove('active'); });
        document.querySelectorAll('.lcp-section').forEach(function(s) { s.classList.remove('active'); });
        btn.classList.add('active');
        var sec = document.getElementById('section-' + btn.dataset.section);
        if (sec) sec.classList.add('active');
      });
    });

    // ── Sync couleur ──────────────────────────────────
    var colorPicker = document.getElementById('widget-color');
    var colorHex    = document.getElementById('widget-color-hex');
    if (colorPicker) {
      colorPicker.addEventListener('input', function() {
        if (colorHex) colorHex.value = colorPicker.value;
        var bubble = document.getElementById('preview-bubble');
        if (bubble) bubble.style.background = colorPicker.value;
      });
    }
    if (colorHex) {
      colorHex.addEventListener('input', function() {
        if (/^#[0-9a-fA-F]{6}$/.test(colorHex.value)) {
          if (colorPicker) colorPicker.value = colorHex.value;
          var bubble = document.getElementById('preview-bubble');
          if (bubble) bubble.style.background = colorHex.value;
        }
      });
    }

    // ── Icône picker ──────────────────────────────────
    document.querySelectorAll('.lcp-icon-opt').forEach(function(opt) {
      opt.addEventListener('click', function() {
        document.querySelectorAll('.lcp-icon-opt').forEach(function(o) { o.classList.remove('active'); });
        opt.classList.add('active');
        var val = document.getElementById('widget-icon-val');
        if (val) val.value = opt.dataset.icon;
        var prev = document.getElementById('preview-icon');
        if (prev) prev.textContent = opt.dataset.icon;
      });
    });

    // ── Preview texte ─────────────────────────────────
    var txtInput = wrap.querySelector('[name="lcp_widget_text"]');
    if (txtInput) {
      txtInput.addEventListener('input', function() {
        var el = document.getElementById('preview-text');
        if (el) el.textContent = txtInput.value;
      });
    }

    // ── Business hours ────────────────────────────────
    initHoursGrid();

    // ── Test Pusher ───────────────────────────────────
    document.getElementById('btn-test-pusher')?.addEventListener('click', testPusher);

    // ── Sauvegarde ────────────────────────────────────
    var saveBtn = document.getElementById('lcp-save-settings');
    if (saveBtn) {
      saveBtn.addEventListener('click', saveSettings);
    }
  }

  function initHoursGrid() {
    var grid    = document.getElementById('lcp-hours-grid');
    var valEl   = document.getElementById('lcp-business-hours-val');
    var enabled = document.getElementById('bh-enabled');
    if (!grid || !valEl) return;

    var days   = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    var labels = {monday:'Lundi',tuesday:'Mardi',wednesday:'Mercredi',thursday:'Jeudi',friday:'Vendredi',saturday:'Samedi',sunday:'Dimanche'};
    var bh = {};
    try { bh = JSON.parse(valEl.value || '{}'); } catch(e) {}

    if (enabled && bh.enabled) enabled.checked = true;

    grid.innerHTML = '';
    days.forEach(function(day) {
      var h = (bh.hours && bh.hours[day]) || { open:'09:00', close:'18:00', enabled: (day !== 'saturday' && day !== 'sunday') };
      var row = document.createElement('div');
      row.className = 'lcp-hour-row';
      row.innerHTML =
        '<span class="lcp-hour-day">' + labels[day] + '</span>' +
        '<input type="checkbox" class="lcp-hour-toggle" data-day="' + day + '"' + (h.enabled ? ' checked' : '') + '>' +
        '<div class="lcp-hour-times">' +
          '<input type="time" data-day="' + day + '" class="lcp-hour-open"  value="' + h.open  + '">' +
          '<span>→</span>' +
          '<input type="time" data-day="' + day + '" class="lcp-hour-close" value="' + h.close + '">' +
        '</div>';
      grid.appendChild(row);
    });

    function syncHours() {
      var hours = {};
      days.forEach(function(day) {
        hours[day] = {
          enabled: !!(grid.querySelector('input[data-day="' + day + '"].lcp-hour-toggle') || {}).checked,
          open:   (grid.querySelector('.lcp-hour-open[data-day="'  + day + '"]') || {}).value || '09:00',
          close:  (grid.querySelector('.lcp-hour-close[data-day="' + day + '"]') || {}).value || '18:00',
        };
      });
      valEl.value = JSON.stringify({
        enabled: enabled ? enabled.checked : false,
        timezone: 'Africa/Casablanca',
        hours: hours
      });
    }
    grid.addEventListener('change', syncHours);
    if (enabled) enabled.addEventListener('change', syncHours);
  }

  function saveSettings() {
    var btn = document.getElementById('lcp-save-settings');
    if (btn) { btn.textContent = '⏳ Sauvegarde...'; btn.disabled = true; }

    var form = new FormData();
    form.append('action', 'lcp_save_settings');
    form.append('nonce',  cfg.ajax_nonce);

    // Collecter tous les champs du formulaire settings
    var wrap = document.getElementById('lcp-settings');
    wrap.querySelectorAll('input, select, textarea').forEach(function(el) {
      if (!el.name) return;
      if (el.type === 'checkbox') {
        form.append(el.name, el.checked ? '1' : '0');
      } else if (el.type === 'radio') {
        if (el.checked) form.append(el.name, el.value);
      } else {
        form.append(el.name, el.value);
      }
    });

    fetch(cfg.ajax_url, { method: 'POST', body: form })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        showNotice(data.success ? 'success' : 'error',
          data.data && data.data.message ? data.data.message : (data.success ? '✅ Réglages sauvegardés !' : '❌ Erreur de sauvegarde.'));
      })
      .catch(function() { showNotice('error', '❌ Erreur réseau.'); })
      .finally(function() {
        if (btn) { btn.textContent = '💾 Sauvegarder'; btn.disabled = false; }
      });
  }

  function showNotice(type, msg) {
    var el = document.getElementById('lcp-settings-notice');
    if (!el) return;
    el.className = 'lcp-notice lcp-notice-' + type;
    el.textContent = msg;
    el.style.display = 'block';
    setTimeout(function() { el.style.display = 'none'; }, 4000);
  }

  function testPusher() {
    var result = document.getElementById('pusher-test-result');
    if (!result) return;
    result.textContent = '⏳ Test...';
    // Test via un simple fetch sur l'API Pusher
    var appId   = document.querySelector('[name="lcp_pusher_app_id"]')?.value;
    var key     = document.querySelector('[name="lcp_pusher_key"]')?.value;
    var cluster = document.querySelector('[name="lcp_pusher_cluster"]')?.value || 'eu';
    if (!appId || !key) {
      result.textContent = '⚠️ Saisissez d\'abord App ID et Key.';
      result.style.color = '#f59e0b';
      return;
    }
    // Tentative de connexion Pusher JS
    if (window.Pusher) {
      try {
        var testPusher = new Pusher(key, { cluster: cluster });
        testPusher.connection.bind('connected', function() {
          result.textContent = '✅ Connexion Pusher réussie !';
          result.style.color = '#22c55e';
          testPusher.disconnect();
        });
        testPusher.connection.bind('failed', function() {
          result.textContent = '❌ Échec — vérifiez vos clés.';
          result.style.color = '#ef4444';
        });
        setTimeout(function() {
          if (result.textContent === '⏳ Test...') {
            result.textContent = '⏳ Connexion en cours...';
          }
        }, 2000);
      } catch(e) {
        result.textContent = '❌ Erreur : ' + e.message;
        result.style.color = '#ef4444';
      }
    } else {
      result.textContent = '⚠️ SDK Pusher non chargé.';
      result.style.color = '#f59e0b';
    }
  }

  /* ═══════════════════════════════════════════════════
     DASHBOARD — nécessite Pusher configuré
  ═══════════════════════════════════════════════════ */
  function initDashboard() {
    if (!document.getElementById('lcp-dashboard')) return;

    bindAgentStatus();
    bindSendArea();
    bindActions();
    bindModals();
    bindSearch();
    loadSessions().then(function() {
      // Ouvrir automatiquement une session depuis un deep link #session=TOKEN
      var hash = window.location.hash;
      if (hash && hash.indexOf('#session=') === 0) {
        var token = hash.replace('#session=', '');
        if (token) setTimeout(function(){ openChat(token); }, 500);
        history.replaceState(null, '', window.location.pathname + window.location.search);
      }
    });
    loadCanned();
    startHeartbeat();

    if (cfg.pusher_key) {
      initPusher();
      updateAgentStatus('online');
    }
  }

  var pusherInstance  = null;
  var adminChannel    = null;
  var activeSessions  = {};
  var currentToken    = null;
  var cannedResponses = [];
  var recMediaRecorder = null, recChunks = [], recInterval = null, recSeconds = 0;
  var typingTimeout   = null;

  function initPusher() {
    if (!cfg.pusher_key || !window.Pusher) return;
    pusherInstance = new Pusher(cfg.pusher_key, {
      cluster: cfg.pusher_cluster,
      authEndpoint: cfg.ajax_url + '?action=lcp_pusher_auth',
      auth: {
        params: { nonce: cfg.nonce },
        headers: { 'X-WP-Nonce': cfg.nonce },
      },
    });
    adminChannel = pusherInstance.subscribe(cfg.admin_channel);
    adminChannel.bind('new-visitor',               onNewVisitor);
    adminChannel.bind('visitor-message',           onVisitorMessage);
    adminChannel.bind('visitor-navigation',        onVisitorNavigation);
    adminChannel.bind('session-closed-by-visitor', onVisitorLeft);
    adminChannel.bind('urgent-visitor',            onUrgentVisitor);
    adminChannel.bind('typing',                    onVisitorTyping);
    pusherInstance.connection.bind('connected',    function() { setDot('online'); });
    pusherInstance.connection.bind('disconnected', function() { setDot('offline'); });
  }

  function setDot(status) {
    var dot = document.getElementById('lcp-status-dot');
    if (dot) dot.className = 'lcp-dot lcp-dot-' + status;
  }

  /* ── Sessions ───────────────────────────────────── */
  async function loadSessions() {
    try {
      var res = await api('admin/sessions');
      if (!res.success) return;
      var container = document.getElementById('lcp-visitors-container');
      if (!container) return;
      if (!res.sessions || !res.sessions.length) {
        container.innerHTML = '<div class="lcp-empty-state"><span>👁️</span><p>' + (cfg.translations && cfg.translations.no_sessions || 'Aucun visiteur') + '</p></div>';
        return;
      }
      container.innerHTML = '';
      res.sessions.forEach(renderVisitorCard);
      updateStats(
        res.sessions.filter(function(s) { return s.status === 'active'; }).length,
        res.sessions.filter(function(s) { return s.status === 'waiting'; }).length
      );
    } catch(e) { console.error('LCP loadSessions', e); }
  }

  function renderVisitorCard(session) {
    var container = document.getElementById('lcp-visitors-container');
    if (!container) return;
    var empty = container.querySelector('.lcp-empty-state');
    if (empty) empty.remove();
    var existing = container.querySelector('[data-token="' + session.session_token + '"]');
    if (existing) existing.remove();

    var card = document.createElement('div');
    card.className = 'lcp-visitor-card ' + session.status;
    card.dataset.token = session.session_token;
    if (session.session_token === currentToken) card.classList.add('active');

    var flags = {'France':'🇫🇷','Morocco':'🇲🇦','Algeria':'🇩🇿','Tunisia':'🇹🇳','United States':'🇺🇸','Germany':'🇩🇪','Spain':'🇪🇸','Belgium':'🇧🇪'};
    var flag = flags[session.country] || '🌍';
    var time = timeAgo(session.started_at);
    var unread = session.unread_count > 0 ? '<span class="lcp-vc-unread">' + session.unread_count + '</span>' : '';
    var page = session.page_url ? session.page_url.replace(/^https?:\/\/[^/]+/, '') || '/' : '';

    card.innerHTML =
      '<div class="lcp-vc-top">' +
        '<span class="lcp-vc-id">' + flag + ' ' + esc(session.visitor_name || session.visitor_id.substr(0,12)) + '</span>' +
        '<span class="lcp-vc-time">' + time + '</span>' +
      '</div>' +
      '<div class="lcp-vc-meta">' +
        '<span class="lcp-vc-status ' + session.status + '"></span>' +
        (session.visitor_phone ? '<span>📱 '+esc(session.visitor_phone)+'</span>' : '') +
      '<span>' + esc(session.country || '?') + '</span>' +
        '<span>' + esc(session.browser || '?') + '</span>' +
        unread +
      '</div>' +
      (page ? '<div class="lcp-vc-page">📄 ' + esc(page) + '</div>' : '');

    card.addEventListener('click', function() { openChat(session.session_token); });
    container.prepend(card);
    activeSessions[session.session_token] = session;
  }

  async function openChat(token) {
    currentToken = token;
    document.querySelectorAll('.lcp-visitor-card').forEach(function(c) { c.classList.remove('active'); });
    var card = document.querySelector('[data-token="' + token + '"]');
    if (card) card.classList.add('active');
    document.getElementById('lcp-chat-placeholder').style.display = 'none';
    var win = document.getElementById('lcp-chat-window');
    if (win) win.style.display = 'flex';
    var panel = document.getElementById('lcp-info-panel');
    if (panel) panel.style.display = 'flex';

    var res = await api('admin/session/' + token);
    if (!res.success) return;
    renderChatHeader(res.session);
    renderInfoPanel(res.session);
    renderMessages(res.messages || []);
    var badge = document.querySelector('[data-token="' + token + '"] .lcp-vc-unread');
    if (badge) badge.remove();
    var navEl = document.getElementById('visitor-current-page');
    if (navEl && res.session.page_url) navEl.textContent = res.session.page_url;
  }

  function renderChatHeader(s) {
    var av = document.getElementById('chat-avatar');
    if (av) av.textContent = (s.country || '?')[0].toUpperCase();
    var id = document.getElementById('chat-visitor-id');
    if (id) id.textContent = s.visitor_name || s.visitor_id.substr(0,16);
    var meta = document.getElementById('chat-visitor-meta');
    if (meta) meta.textContent = (s.country||'') + ' · ' + (s.browser||'') + ' · ' + (s.os||'');
  }

  function renderInfoPanel(s) {
    var el = document.getElementById('lcp-visitor-details-panel');
    if (!el) return;
    var rows = [['Pays',s.country||'N/A'],['Ville',s.city||'N/A'],['Navigateur',s.browser||'N/A'],['OS',s.os||'N/A'],['Appareil',s.device||'N/A'],['Statut',s.status],['Début',formatDate(s.started_at)]];
    el.innerHTML = rows.map(function(r) {
      return '<div class="lcp-info-row"><span class="lcp-info-key">' + r[0] + '</span><span class="lcp-info-value">' + esc(r[1]) + '</span></div>';
    }).join('');
  }

  function renderMessages(messages) {
    var container = document.getElementById('lcp-messages-container');
    if (!container) return;
    container.innerHTML = '';
    messages.forEach(appendMessage);
    container.scrollTop = container.scrollHeight;
  }

  function appendMessage(msg) {
    var container = document.getElementById('lcp-messages-container');
    if (!container) return;
    if (msg.type === 'system') {
      var sys = document.createElement('div');
      sys.className = 'lcp-adm-msg-system';
      sys.textContent = msg.content;
      container.appendChild(sys);
      container.scrollTop = container.scrollHeight;
      return;
    }
    var wrap = document.createElement('div');
    wrap.className = 'lcp-adm-msg from-' + msg.sender_type;
    var avatarHtml = msg.sender_type === 'agent'
      ? '<div class="lcp-adm-avatar">' + esc((msg.sender_name||'A')[0]) + '</div>'
      : '<div class="lcp-adm-avatar">' + (msg.sender_type === 'bot' ? '🤖' : '👤') + '</div>';
    var meta = {};
    try { meta = typeof msg.metadata === 'string' ? JSON.parse(msg.metadata||'{}') : (msg.metadata||{}); } catch(e){}
    var content = '';
    if (msg.type === 'image')        content = '<img src="' + esc(msg.file_url) + '" class="lcp-adm-msg-image" alt="">';
    else if (msg.type === 'audio')   content = '<audio controls src="' + esc(msg.file_url) + '" class="lcp-adm-msg-audio"></audio>';
    else if (msg.type === 'pdf' || msg.type === 'file') content = '<a href="' + esc(msg.file_url) + '" target="_blank" class="lcp-adm-msg-file">📎 ' + esc(msg.file_name||'Fichier') + '</a>';
    else if (msg.type === 'page')    content = '<div class="lcp-adm-msg-page">📄 <a href="' + esc(msg.file_url) + '" target="_blank">' + esc(msg.content||msg.file_url) + '</a></div>';
    else if (msg.type === 'product') content = '<div class="lcp-adm-msg-product">' + (meta.image ? '<img src="' + esc(meta.image) + '" alt="">' : '') + '<div class="lcp-adm-product-info"><strong>' + esc(meta.title||msg.content) + '</strong><div>' + (meta.price||'') + '</div><a href="' + esc(msg.file_url||'#') + '" target="_blank">Voir →</a></div></div>';
    else content = '<p>' + esc(msg.content) + '</p>';

    var time = msg.sent_at ? new Date(msg.sent_at).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}) : '';
    wrap.innerHTML = avatarHtml + '<div><div class="lcp-adm-sender">' + (msg.sender_type==='agent' ? (msg.sender_name||'Agent') : msg.sender_type==='bot' ? '🤖 Bot' : 'Visiteur') + '</div><div class="lcp-adm-bubble">' + content + '<span class="lcp-adm-time">' + time + '</span></div></div>';
    container.appendChild(wrap);
    container.scrollTop = container.scrollHeight;
  }

  /* ── Pusher events ──────────────────────────────── */
  function onNewVisitor(d) {
    renderVisitorCard(Object.assign({}, d, {status:'waiting',unread_count:0}));
    playSound();
    showNotifBrowser(cfg.translations && cfg.translations.new_visitor || 'Nouveau visiteur', (d.country||'') + ' · ' + (d.browser||''));
  }
  function onVisitorMessage(d) {
    var card = document.querySelector('[data-token="' + d.session_token + '"]');
    if (card && d.session_token !== currentToken) {
      var badge = card.querySelector('.lcp-vc-unread');
      if (!badge) { badge = document.createElement('span'); badge.className = 'lcp-vc-unread'; badge.textContent = '1'; card.querySelector('.lcp-vc-meta').appendChild(badge); }
      else badge.textContent = parseInt(badge.textContent||0) + 1;
      card.parentElement && card.parentElement.prepend(card);
    }
    if (d.session_token === currentToken) appendMessage(d);
    playSound('msg');
  }
  function onVisitorNavigation(d) {
    if (d.session_token === currentToken) { var el = document.getElementById('visitor-current-page'); if (el) el.textContent = d.page_url; }
    var pg = document.querySelector('[data-token="' + d.session_token + '"] .lcp-vc-page');
    if (pg) pg.textContent = '📄 ' + (d.page_url.replace(/^https?:\/\/[^/]+/,'') || '/');
  }
  function onVisitorLeft(d) {
    var card = document.querySelector('[data-token="' + d.session_token + '"]');
    if (card) card.style.opacity = '.5';
    if (d.session_token === currentToken) {
      var c = document.getElementById('lcp-messages-container');
      if (c) { var s = document.createElement('div'); s.className = 'lcp-adm-msg-system'; s.textContent = cfg.translations && cfg.translations.visitor_left || 'Le visiteur a quitté'; c.appendChild(s); c.scrollTop = c.scrollHeight; }
    }
  }
  function onUrgentVisitor(d) {
    var card = document.querySelector('[data-token="' + d.session_token + '"]');
    if (card) { card.style.background = '#fef2f2'; card.style.borderLeft = '3px solid #ef4444'; }
    showNotifBrowser('⚠️ Urgent', (d.message||'').substr(0,60));
  }
  function onVisitorTyping(d) {
    if (d.sender === 'visitor' && currentToken) {
      var el = document.getElementById('lcp-typing-indicator');
      if (el) { el.style.display = 'flex'; clearTimeout(typingTimeout); typingTimeout = setTimeout(function(){ el.style.display='none'; }, 3000); }
    }
  }

  /* ── Envoi message ──────────────────────────────── */
  async function sendMessage(content, type, extra) {
    if (!currentToken) return;
    extra = extra || {};
    var res = await api('admin/message/send', Object.assign({ session_token: currentToken, content: content, type: type }, extra));
    if (res.success || res.message_id) {
      appendMessage(Object.assign({ sender_type:'agent', sender_name: cfg.current_user && cfg.current_user.name || 'Agent', type:type, content:content, sent_at: new Date().toISOString() }, extra));
    }
  }

  function bindSendArea() {
    var input = document.getElementById('lcp-message-input');
    var btn   = document.getElementById('lcp-send-btn');
    if (input) {
      input.addEventListener('keydown', function(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); } });
      input.addEventListener('input', function() { input.style.height='auto'; input.style.height = Math.min(input.scrollHeight,120)+'px'; });
    }
    if (btn) btn.addEventListener('click', doSend);
    var fileInput = document.getElementById('lcp-file-input');
    document.getElementById('btn-upload-file')?.addEventListener('click', function() { if(fileInput) fileInput.click(); });
    if (fileInput) fileInput.addEventListener('change', function(e) { if(e.target.files[0]) uploadAndSend(e.target.files[0]); });
    document.getElementById('btn-record-audio')?.addEventListener('click',  startRecording);
    document.getElementById('btn-stop-record')?.addEventListener('click',   function(){ stopRecording(true); });
    document.getElementById('btn-cancel-record')?.addEventListener('click', function(){ stopRecording(false); });
    document.getElementById('btn-canned')?.addEventListener('click', function() { openModal('modal-canned'); });
  }

  function doSend() {
    var input = document.getElementById('lcp-message-input');
    if (!input) return;
    var text = input.value.trim();
    if (!text) return;
    input.value = ''; input.style.height = 'auto';
    sendMessage(text, 'text');
  }

  /* ── Actions ────────────────────────────────────── */
  function bindActions() {
    document.getElementById('btn-push-page')?.addEventListener('click', function() { openModal('modal-push-page'); });
    document.getElementById('btn-send-product')?.addEventListener('click', function() { openModal('modal-push-page'); setTimeout(function(){ var t=document.querySelector('[data-tab="products"]'); if(t) t.click(); },100); });
    document.getElementById('btn-ai-suggest')?.addEventListener('click', loadAiSuggestions);
    document.getElementById('btn-close-ai')?.addEventListener('click', function() { var el=document.getElementById('lcp-ai-suggestions'); if(el) el.style.display='none'; });
    document.getElementById('btn-transcript')?.addEventListener('click', function() { if(currentToken) window.open(cfg.ajax_url+'?action=lcp_export_transcript&token='+currentToken+'&nonce='+cfg.ajax_nonce,'_blank'); });
    document.getElementById('btn-close-session')?.addEventListener('click', async function() {
      if (!confirm(cfg.translations && cfg.translations.confirm_close || 'Fermer ?')) return;
      await api('admin/session/close', { session_token: currentToken });
      var card = document.querySelector('[data-token="' + currentToken + '"]');
      if (card) card.remove();
      document.getElementById('lcp-chat-window').style.display = 'none';
      document.getElementById('lcp-chat-placeholder').style.display = 'flex';
      currentToken = null;
    });
    document.getElementById('lcp-refresh-sessions')?.addEventListener('click', loadSessions);
    document.getElementById('qa-push-home')?.addEventListener('click', function(){ api('admin/push/page',{session_token:currentToken,url:window.location.origin,title:'Accueil'}); });
    document.getElementById('qa-push-shop')?.addEventListener('click', function(){ api('admin/push/page',{session_token:currentToken,url:window.location.origin+'/boutique',title:'Boutique'}); });
  }

  /* ── Modals ─────────────────────────────────────── */
  function bindModals() {
    document.querySelectorAll('.lcp-modal-close').forEach(function(btn) { btn.addEventListener('click', closeAllModals); });
    var overlay = document.getElementById('lcp-modal-overlay');
    if (overlay) overlay.addEventListener('click', closeAllModals);

    document.querySelectorAll('.lcp-tab').forEach(function(tab) {
      tab.addEventListener('click', function() {
        var panel = tab.closest('.lcp-modal-content');
        if (!panel) return;
        panel.querySelectorAll('.lcp-tab').forEach(function(t){ t.classList.remove('active'); });
        panel.querySelectorAll('.lcp-tab-content').forEach(function(c){ c.classList.remove('active'); });
        tab.classList.add('active');
        var tc = document.getElementById('tab-' + tab.dataset.tab);
        if (tc) tc.classList.add('active');
      });
    });

    var pTimer, prTimer, cTimer;
    var sp = document.getElementById('search-pages');
    if (sp) sp.addEventListener('input', function(){ clearTimeout(pTimer); pTimer = setTimeout(function(){ searchPages(sp.value,'any','pages-results'); },400); });
    var spr = document.getElementById('search-products');
    if (spr) spr.addEventListener('input', function(){ clearTimeout(prTimer); prTimer = setTimeout(function(){ searchWoo(spr.value,'product','products-results'); },400); });
    var sc = document.getElementById('search-categories');
    if (sc) sc.addEventListener('input', function(){ clearTimeout(cTimer); cTimer = setTimeout(function(){ searchWoo(sc.value,'category','categories-results'); },400); });

    document.getElementById('btn-push-custom')?.addEventListener('click', function(){
      var url   = (document.getElementById('custom-url')||{}).value;
      var title = (document.getElementById('custom-title')||{}).value || '';
      if (url && currentToken) { api('admin/push/page',{session_token:currentToken,url:url,title:title}); closeAllModals(); }
    });
    document.getElementById('search-canned')?.addEventListener('input', function(e){ filterCanned(e.target.value); });
  }

  function openModal(id) {
    var el = document.getElementById(id);
    var ov = document.getElementById('lcp-modal-overlay');
    if (el) el.style.display = 'flex';
    if (ov) ov.style.display = 'block';
    if (id === 'modal-push-page') { searchPages('','any','pages-results'); if(cfg.woo_active) searchWoo('','product','products-results'); }
    if (id === 'modal-canned') renderCannedModal();
  }

  function closeAllModals() {
    document.querySelectorAll('.lcp-modal').forEach(function(m){ m.style.display='none'; });
    var ov = document.getElementById('lcp-modal-overlay');
    if (ov) ov.style.display = 'none';
  }

  async function searchPages(q, type, containerId) {
    var c = document.getElementById(containerId);
    if (!c) return;
    c.innerHTML = '<div class="lcp-loading">Recherche...</div>';
    var res = await api('admin/pages/search?q=' + encodeURIComponent(q) + '&type=' + type, null, 'GET');
    c.innerHTML = '';
    if (!res.success || !res.results || !res.results.length) { c.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:16px;">Aucun résultat</p>'; return; }
    res.results.forEach(function(item) {
      var div = document.createElement('div'); div.className = 'lcp-result-item';
      div.innerHTML = '<div class="lcp-result-info"><strong>' + esc(item.title) + '</strong><small>' + esc(item.type) + '</small></div><button class="lcp-btn lcp-btn-primary lcp-btn-sm">Pousser</button>';
      div.querySelector('button').addEventListener('click', function(){ api('admin/push/page',{session_token:currentToken,url:item.url,title:item.title}); closeAllModals(); });
      c.appendChild(div);
    });
  }

  async function searchWoo(q, type, containerId) {
    var c = document.getElementById(containerId);
    if (!c) return;
    c.innerHTML = '<div class="lcp-loading">Recherche...</div>';
    var res = await api('admin/woo/search?q=' + encodeURIComponent(q) + '&type=' + type, null, 'GET');
    c.innerHTML = '';
    if (!res.success || !res.results || !res.results.length) { c.innerHTML = '<p style="text-align:center;color:#94a3b8;padding:16px;">Aucun résultat</p>'; return; }
    res.results.forEach(function(item) {
      var div = document.createElement('div'); div.className = 'lcp-result-item';
      div.innerHTML = (item.image ? '<img src="' + esc(item.image) + '" alt="">' : '') + '<div class="lcp-result-info"><strong>' + esc(item.title) + '</strong><small>' + esc(item.category||item.type||'') + '</small></div>' + (item.price ? '<span class="lcp-result-price">' + item.price + '</span>' : '') + '<button class="lcp-btn lcp-btn-primary lcp-btn-sm">Envoyer</button>';
      div.querySelector('button').addEventListener('click', function(){
        if (item.type === 'product') sendMessage(item.title,'product',{file_url:item.url,metadata:{title:item.title,price:item.price,image:item.image,url:item.url}});
        else api('admin/push/page',{session_token:currentToken,url:item.url,title:item.title});
        closeAllModals();
      });
      c.appendChild(div);
    });
  }

  /* ── Canned ─────────────────────────────────────── */
  async function loadCanned() {
    var res = await api('admin/canned', null, 'GET');
    if (res.success) cannedResponses = res.canned || [];
    loadCannedAdminList();
  }

  function renderCannedModal() {
    var list = document.getElementById('canned-list');
    if (!list) return;
    list.innerHTML = '';
    if (!cannedResponses.length) { list.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:20px;">Aucune réponse. <a href="?page=lcp-canned">En créer une</a></p>'; return; }
    cannedResponses.forEach(function(c) {
      var div = document.createElement('div'); div.className = 'lcp-canned-item';
      div.innerHTML = '<span class="lcp-canned-shortcut">' + esc(c.shortcut) + '</span> <strong>' + esc(c.title) + '</strong><small>' + esc(c.content.substr(0,80)) + '...</small>';
      div.addEventListener('click', function(){ var inp = document.getElementById('lcp-message-input'); if(inp){ inp.value=c.content; inp.focus(); } closeAllModals(); });
      list.appendChild(div);
    });
  }

  function filterCanned(q) {
    document.querySelectorAll('#canned-list .lcp-canned-item').forEach(function(item){ item.style.display = item.textContent.toLowerCase().includes(q.toLowerCase()) ? '' : 'none'; });
  }

  async function loadCannedAdminList() {
    var list = document.getElementById('lcp-canned-list');
    if (!list) return;
    var res = await api('admin/canned', null, 'GET');
    if (!res.success) return;
    list.innerHTML = '';
    (res.canned||[]).forEach(function(c) {
      var div = document.createElement('div'); div.className = 'lcp-canned-admin-item';
      div.innerHTML = '<div class="lcp-canned-admin-info"><span class="lcp-canned-shortcut">' + esc(c.shortcut) + '</span> <strong>' + esc(c.title) + '</strong><p>' + esc(c.content) + '</p></div><div class="lcp-canned-actions"><button class="lcp-btn lcp-btn-sm lcp-btn-danger btn-del" data-id="' + c.id + '">🗑️</button></div>';
      div.querySelector('.btn-del').addEventListener('click', async function(){
        if (confirm('Supprimer ?')) { await ajaxPost('lcp_delete_canned',{id:c.id}); div.remove(); }
      });
      list.appendChild(div);
    });

    // Bind new canned button
    var newBtn = document.getElementById('btn-new-canned');
    if (newBtn && !newBtn._bound) {
      newBtn._bound = true;
      newBtn.addEventListener('click', function(){
        document.getElementById('canned-edit-id').value = '';
        document.getElementById('canned-shortcut').value = '';
        document.getElementById('canned-title').value = '';
        document.getElementById('canned-content').value = '';
        document.getElementById('canned-category').value = '';
        document.getElementById('modal-edit-canned').style.display = 'flex';
        document.getElementById('canned-modal-overlay').style.display = 'block';
      });
      document.querySelector('#modal-edit-canned .lcp-modal-close')?.addEventListener('click', function(){ document.getElementById('modal-edit-canned').style.display='none'; document.getElementById('canned-modal-overlay').style.display='none'; });
      document.getElementById('canned-modal-overlay')?.addEventListener('click', function(){ document.getElementById('modal-edit-canned').style.display='none'; document.getElementById('canned-modal-overlay').style.display='none'; });
      document.getElementById('btn-save-canned')?.addEventListener('click', async function(){
        var res = await ajaxPost('lcp_save_canned',{
          id: document.getElementById('canned-edit-id').value,
          shortcut: document.getElementById('canned-shortcut').value,
          title: document.getElementById('canned-title').value,
          content: document.getElementById('canned-content').value,
          category: document.getElementById('canned-category').value,
        });
        if (res.success) location.reload();
      });
    }
  }

  /* ── IA Suggestions ─────────────────────────────── */
  async function loadAiSuggestions() {
    if (!currentToken || !cfg.ai_enabled) return;
    var box  = document.getElementById('lcp-ai-suggestions');
    var list = document.getElementById('lcp-suggestions-list');
    if (!box || !list) return;
    box.style.display = 'block';
    list.innerHTML = '<span style="color:#94a3b8;font-size:12px;">⏳ Génération...</span>';
    var res = await api('admin/ai/suggest', { session_token: currentToken });
    list.innerHTML = '';
    if (res.success && res.suggestions && res.suggestions.length) {
      res.suggestions.forEach(function(s) {
        var pill = document.createElement('span');
        pill.className = 'lcp-suggestion-pill';
        pill.textContent = s;
        pill.addEventListener('click', function(){ var inp=document.getElementById('lcp-message-input'); if(inp){inp.value=s;inp.focus();} box.style.display='none'; });
        list.appendChild(pill);
      });
    } else { list.innerHTML = '<span style="color:#94a3b8;font-size:12px;">Aucune suggestion.</span>'; }
  }

  /* ── Audio ──────────────────────────────────────── */
  async function startRecording() {
    try {
      var stream = await navigator.mediaDevices.getUserMedia({audio:true});
      recMediaRecorder = new MediaRecorder(stream);
      recChunks = []; recSeconds = 0;
      recMediaRecorder.ondataavailable = function(e){ if(e.data.size>0) recChunks.push(e.data); };
      recMediaRecorder.start();
      document.getElementById('lcp-audio-recorder').style.display = 'flex';
      document.getElementById('btn-record-audio').style.display = 'none';
      recInterval = setInterval(function(){
        recSeconds++;
        var m=Math.floor(recSeconds/60), s=recSeconds%60;
        var el=document.getElementById('lcp-rec-timer');
        if(el) el.textContent = m+':'+(s<10?'0':'')+s;
      }, 1000);
    } catch(e) { alert('Microphone non disponible'); }
  }
  function stopRecording(send) {
    if (!recMediaRecorder) return;
    clearInterval(recInterval);
    recMediaRecorder.stream.getTracks().forEach(function(t){ t.stop(); });
    if (send) {
      recMediaRecorder.onstop = function(){
        var blob = new Blob(recChunks, {type:'audio/ogg; codecs=opus'});
        uploadAndSend(new File([blob], 'vocal_'+Date.now()+'.ogg', {type:'audio/ogg'}));
      };
    }
    recMediaRecorder.stop();
    document.getElementById('lcp-audio-recorder').style.display = 'none';
    document.getElementById('btn-record-audio').style.display = '';
  }
  async function uploadAndSend(file) {
    var fd = new FormData();
    fd.append('file', file);
    fd.append('session_token', currentToken);
    try {
      var r = await fetch(cfg.rest_url+'/upload',{method:'POST',headers:{'X-WP-Nonce':cfg.nonce},body:fd});
      var d = await r.json();
      if (d.success) sendMessage(d.name, d.type, {file_url:d.url, file_name:d.name});
    } catch(e){ console.error('LCP upload',e); }
  }

  /* ── Agent status ───────────────────────────────── */
  function bindAgentStatus() {
    var sel = document.getElementById('lcp-agent-status-select');
    if (sel) sel.addEventListener('change', function(){ updateAgentStatus(sel.value); });
  }
  async function updateAgentStatus(status) {
    setDot(status);
    await ajaxPost('lcp_agent_status', {status: status});
  }

  function updateStats(active, waiting) {
    var e1=document.getElementById('stat-active'), e2=document.getElementById('stat-waiting');
    if(e1) e1.textContent=active;
    if(e2) e2.textContent=waiting;
  }

  function bindSearch() {
    var inp = document.getElementById('lcp-search-visitors');
    if (inp) inp.addEventListener('input', function(){
      var q = inp.value.toLowerCase();
      document.querySelectorAll('.lcp-visitor-card').forEach(function(c){ c.style.display = c.textContent.toLowerCase().includes(q) ? '' : 'none'; });
    });
  }

  /* ── Stats / Contacts / History ─────────────────── */
  function startHeartbeat() {
    setInterval(loadSessions, 30000);
    if (document.getElementById('lcp-stats')) {
      loadStats();
      document.getElementById('stats-period')?.addEventListener('change', loadStats);
    }
    if (document.getElementById('lcp-contacts')) loadContacts();
    if (document.getElementById('lcp-history'))  loadHistory();
  }

  async function loadStats() {
    var period = (document.getElementById('stats-period')||{}).value || 30;
    var res = await api('admin/stats?period='+period, null, 'GET');
    if (!res.success) return;
    var s = res.stats;
    // Chiffres globaux
    var map = {sessions:'total_sessions',messages:'total_messages',contacts:'total_contacts',missed:'missed_sessions',response:'avg_response'};
    Object.entries(map).forEach(function(e){ var el=document.getElementById('s-'+e[0]); if(el) el.textContent = s[e[1]]||0; });

    // Liste sessions récentes
    var res2 = await api('admin/sessions/all?limit=20', null, 'GET');
    var statsGrid = document.getElementById('lcp-stats-grid');
    if (!statsGrid || !res2.sessions || !res2.sessions.length) return;

    // Ajouter tableau sous les stats
    var existing = document.getElementById('lcp-stats-sessions');
    if (existing) existing.remove();

    var table = document.createElement('div');
    table.id = 'lcp-stats-sessions';
    table.style.cssText = 'margin-top:24px;padding:0 24px;';
    table.innerHTML =
      '<h3 style="font-size:14px;font-weight:700;margin:0 0 12px;color:#1e293b;">Sessions récentes</h3>'+
      '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">'+
        '<table style="width:100%;border-collapse:collapse;font-size:13px;">'+
          '<thead><tr style="background:#f8fafc;">'+
            '<th style="padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;">Date</th>'+
            '<th style="padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;">Visiteur</th>'+
            '<th style="padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;">Pays</th>'+
            '<th style="padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;">Messages</th>'+
            '<th style="padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;">Statut</th>'+
            '<th style="padding:10px 14px;text-align:left;font-size:11px;text-transform:uppercase;color:#64748b;font-weight:700;">Action</th>'+
          '</tr></thead>'+
          '<tbody id="stats-sessions-tbody"></tbody>'+
        '</table>'+
      '</div>';

    statsGrid.parentElement.appendChild(table);

    var tbody = document.getElementById('stats-sessions-tbody');
    var flags = {'France':'🇫🇷','Morocco':'🇲🇦','Algeria':'🇩🇿','Tunisia':'🇹🇳','United States':'🇺🇸'};

    res2.sessions.forEach(function(s){
      var tr = document.createElement('tr');
      tr.style.cssText = 'border-bottom:1px solid #f1f5f9;cursor:pointer;';
      tr.innerHTML =
        '<td style="padding:10px 14px;">'+formatDate(s.started_at)+'</td>'+
        '<td style="padding:10px 14px;font-weight:600;">'+(s.visitor_name||esc(s.visitor_id.substr(0,10))+'...')+'</td>'+
        '<td style="padding:10px 14px;">'+(flags[s.country]||'🌍')+' '+esc(s.country||'?')+'</td>'+
        '<td style="padding:10px 14px;">'+(s.msg_count||0)+'</td>'+
        '<td style="padding:10px 14px;"><span style="background:#eef2ff;color:#6366f1;padding:2px 8px;border-radius:10px;font-size:11px;">'+s.status+'</span></td>'+
        '<td style="padding:10px 14px;">'+
          '<button class="lcp-btn lcp-btn-sm" data-token="'+s.session_token+'" style="font-size:11px;">💬 Ouvrir</button>'+
        '</td>';
      tr.querySelector('button').addEventListener('click', function(){
        window.location.href = '?page=livechatpremium#session=' + s.session_token;
      });
      tr.addEventListener('mouseenter', function(){ tr.style.background='#f8fafc'; });
      tr.addEventListener('mouseleave', function(){ tr.style.background=''; });
      tbody.appendChild(tr);
    });
  }

  async function loadContacts() {
    var res = await api('admin/contacts', null, 'GET');
    var grid = document.getElementById('lcp-contacts-grid');
    if (!grid || !res.success) return;
    grid.innerHTML = '';
    if (!res.contacts || !res.contacts.length) {
      grid.innerHTML = '<div style="padding:40px;text-align:center;color:#94a3b8;">Aucun contact pour le moment.</div>';
      return;
    }
    (res.contacts||[]).forEach(function(c){
      var div=document.createElement('div');
      div.className='lcp-contact-card';
      div.style.cursor='pointer';
      var initials = (c.name||c.visitor_id||'?')[0].toUpperCase();
      var phone = c.phone ? '<div style="font-size:12px;color:#64748b;margin-top:2px;">📱 '+esc(c.phone)+'</div>' : '';
      var email = c.email ? '<div class="lcp-contact-email">✉️ '+esc(c.email)+'</div>' : '';
      div.innerHTML =
        '<div class="lcp-contact-avatar">'+initials+'</div>'+
        '<div class="lcp-contact-name">'+esc(c.name||'Visiteur #'+c.id)+'</div>'+
        email + phone +
        '<div class="lcp-contact-meta" style="margin-top:8px;">'+
          '<span class="lcp-badge lcp-badge-info">'+c.total_sessions+' session(s)</span>'+
          '<span style="font-size:11px;color:#94a3b8;margin-left:8px;">'+formatDate(c.last_seen||c.created_at)+'</span>'+
        '</div>'+
        '<div style="margin-top:10px;display:flex;gap:6px;">'+
          '<button class="lcp-btn lcp-btn-sm lcp-btn-primary btn-contact-sessions" data-vid="'+esc(c.visitor_id)+'" data-name="'+esc(c.name||'Visiteur')+'">📋 Sessions</button>'+
        '</div>';
      // Clic → voir sessions de ce contact
      div.querySelector('.btn-contact-sessions').addEventListener('click', function(e){
        e.stopPropagation();
        showContactSessions(c);
      });
      grid.appendChild(div);
    });
    // Recherche live
    var s = document.getElementById('contacts-search');
    if (s && !s._bound) {
      s._bound = true;
      s.addEventListener('input', function(){
        var q=s.value.toLowerCase();
        grid.querySelectorAll('.lcp-contact-card').forEach(function(card){
          card.style.display=card.textContent.toLowerCase().includes(q)?'':'none';
        });
      });
    }
  }

  async function showContactSessions(contact) {
    // Créer un modal inline pour les sessions du contact
    var existing = document.getElementById('lcp-contact-modal');
    if (existing) existing.remove();

    var modal = document.createElement('div');
    modal.id = 'lcp-contact-modal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:100000;display:flex;align-items:center;justify-content:center;';
    modal.innerHTML =
      '<div style="background:#fff;border-radius:12px;width:700px;max-width:95vw;max-height:80vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.2);">'+
        '<div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #e2e8f0;">'+
          '<h3 style="margin:0;font-size:15px;">📋 Sessions de '+esc(contact.name||'ce visiteur')+' — '+esc(contact.phone||'')+'</h3>'+
          '<button id="close-contact-modal" style="background:none;border:none;font-size:20px;cursor:pointer;color:#64748b;">✕</button>'+
        '</div>'+
        '<div id="contact-sessions-list" style="overflow-y:auto;padding:16px;flex:1;">'+
          '<div style="text-align:center;padding:20px;color:#94a3b8;">Chargement...</div>'+
        '</div>'+
      '</div>';

    document.body.appendChild(modal);
    document.getElementById('close-contact-modal').addEventListener('click', function(){ modal.remove(); });
    modal.addEventListener('click', function(e){ if(e.target===modal) modal.remove(); });

    // Charger les sessions de ce visiteur
    var res = await api('admin/sessions/all?status=&limit=20', null, 'GET');
    var list = document.getElementById('contact-sessions-list');
    if (!list) return;

    var sessions = (res.sessions||[]).filter(function(s){ return s.visitor_id === contact.visitor_id; });
    if (!sessions.length) {
      list.innerHTML = '<p style="text-align:center;color:#94a3b8;">Aucune session trouvée.</p>';
      return;
    }
    list.innerHTML = '';
    sessions.forEach(function(s){
      var div = document.createElement('div');
      div.style.cssText = 'border:1px solid #e2e8f0;border-radius:8px;padding:12px;margin-bottom:8px;cursor:pointer;transition:background .15s;';
      div.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;">'+
          '<div>'+
            '<strong>'+formatDate(s.started_at)+'</strong>'+
            '<span style="margin-left:10px;font-size:11px;background:#eef2ff;color:#6366f1;padding:2px 8px;border-radius:10px;">'+s.status+'</span>'+
          '</div>'+
          '<div style="font-size:12px;color:#64748b;">'+esc(s.browser||'?')+' · '+esc(s.country||'?')+' · '+(s.msg_count||0)+' msgs</div>'+
        '</div>'+
        '<div style="font-size:11px;color:#94a3b8;margin-top:4px;">'+esc(s.page_url||'')+'</div>'+
        '<button class="lcp-btn lcp-btn-sm lcp-btn-primary" style="margin-top:8px;" data-token="'+s.session_token+'">💬 Ouvrir conversation</button>';
      div.querySelector('button').addEventListener('click', function(){
        modal.remove();
        // Naviguer vers dashboard et ouvrir cette session
        if (document.getElementById('lcp-dashboard')) {
          openChat(s.session_token);
        } else {
          window.location.href = '?page=livechatpremium#session=' + s.session_token;
        }
      });
      list.appendChild(div);
    });
  }

  async function loadHistory() {
    // Charger toutes les sessions (actives + fermées + manquées)
    var res = await api('admin/sessions/all?limit=50', null, 'GET');
    var tbody = document.getElementById('history-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    var flags={'France':'🇫🇷','Morocco':'🇲🇦','Algeria':'🇩🇿','Tunisia':'🇹🇳','United States':'🇺🇸'};
    (res.sessions||[]).forEach(function(s){
      var tr=document.createElement('tr');
      tr.innerHTML='<td>'+formatDate(s.started_at)+'</td><td>'+esc(s.visitor_id.substr(0,12))+'...</td><td>'+(flags[s.country]||'🌍')+' '+esc(s.country||'?')+'</td><td>'+esc(s.browser||'?')+'</td><td>'+(s.msg_count||0)+'</td><td><span class="lcp-badge lcp-badge-info">'+s.status+'</span></td><td><a href="'+cfg.ajax_url+'?action=lcp_export_transcript&token='+s.session_token+'&nonce='+cfg.ajax_nonce+'" target="_blank" class="lcp-btn lcp-btn-sm">📋</a></td>';
      tbody.appendChild(tr);
    });
  }

  /* ── Helpers ────────────────────────────────────── */
  function playSound(type) {
    try {
      var ctx=new (window.AudioContext||window.webkitAudioContext)();
      var osc=ctx.createOscillator(), gain=ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.frequency.value = type==='msg' ? 660 : 880;
      osc.type='sine';
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime+0.3);
      osc.start(ctx.currentTime); osc.stop(ctx.currentTime+0.3);
    } catch(e){}
  }
  function showNotifBrowser(title, body) {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'granted') new Notification(title,{body:body});
    else if (Notification.permission !== 'denied') Notification.requestPermission().then(function(p){ if(p==='granted') new Notification(title,{body:body}); });
  }
  function timeAgo(d) {
    var diff = Math.floor((Date.now()-new Date(d))/1000);
    if (diff<60) return 'À l\'instant';
    if (diff<3600) return Math.floor(diff/60)+'min';
    if (diff<86400) return Math.floor(diff/3600)+'h';
    return Math.floor(diff/86400)+'j';
  }
  function formatDate(d) {
    return new Date(d).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  }
  function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  async function api(endpoint, body, method) {
    method = method || 'POST';
    var url = cfg.rest_url + '/' + endpoint;
    var opts = { method:method, headers:{'Content-Type':'application/json','X-WP-Nonce':cfg.nonce} };
    if (body && method !== 'GET') opts.body = JSON.stringify(body);
    var res = await fetch(url, opts);
    return res.json();
  }
  async function ajaxPost(action, data) {
    var form = new FormData();
    form.append('action', action);
    form.append('nonce', cfg.ajax_nonce);
    Object.entries(data).forEach(function(e){ form.append(e[0], e[1]); });
    var res = await fetch(cfg.ajax_url, {method:'POST', body:form});
    return res.json();
  }

  /* ═══════════════════════════════════════════════════
     DÉMARRAGE — détection de page
  ═══════════════════════════════════════════════════ */
  document.addEventListener('DOMContentLoaded', function() {
    // Settings : toujours init, indépendant de Pusher
    if (document.getElementById('lcp-settings'))      initSettings();
    // Dashboard et autres : init complète
    if (document.getElementById('lcp-dashboard'))     initDashboard();
    if (document.getElementById('lcp-canned-page'))   loadCannedAdminList();
    if (document.getElementById('lcp-stats'))         loadStats();
    if (document.getElementById('lcp-contacts'))      loadContacts();
    if (document.getElementById('lcp-history'))       loadHistory();
  });

})();
