<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [$this, 'register_menus'] );
        add_action( 'admin_enqueue_scripts', [$this, 'enqueue_assets'] );
        add_action( 'admin_bar_menu',        [$this, 'admin_bar_node'], 100 );
        add_action( 'wp_ajax_lcp_save_settings',      [$this, 'save_settings'] );
        add_action( 'wp_ajax_lcp_pusher_auth',         [$this, 'pusher_auth'] );
        add_action( 'wp_ajax_nopriv_lcp_pusher_auth',  [$this, 'pusher_auth'] );
        add_action( 'wp_ajax_lcp_reset_settings',     [$this, 'reset_settings'] );
        add_action( 'wp_ajax_lcp_activate_license',   [$this, 'activate_license'] );
        add_action( 'wp_ajax_lcp_save_canned',   [$this, 'save_canned'] );
        add_action( 'wp_ajax_lcp_delete_canned', [$this, 'delete_canned'] );
        add_action( 'wp_ajax_lcp_export_transcript', [$this, 'export_transcript'] );
        add_action( 'wp_ajax_lcp_agent_status',  [$this, 'update_agent_status'] );
    }

    public function register_menus() {
        $unread = LCP_Database::get_unread_count();
        $bubble = $unread ? ' <span class="awaiting-mod">' . $unread . '</span>' : '';

        add_menu_page(
            __('LiveChat Premium', 'livechatpremium'),
            __('LiveChat', 'livechatpremium') . $bubble,
            'edit_posts',
            'livechatpremium',
            [$this, 'page_dashboard'],
            'dashicons-format-chat',
            3
        );

        add_submenu_page('livechatpremium', __('Dashboard', 'livechatpremium'),     __('Dashboard', 'livechatpremium'),    'edit_posts',       'livechatpremium',              [$this, 'page_dashboard']);
        add_submenu_page('livechatpremium', __('Historique', 'livechatpremium'),    __('Historique', 'livechatpremium'),   'edit_posts',       'lcp-history',                  [$this, 'page_history']);
        add_submenu_page('livechatpremium', __('Contacts CRM', 'livechatpremium'),  __('Contacts', 'livechatpremium'),     'edit_posts',       'lcp-contacts',                 [$this, 'page_contacts']);
        add_submenu_page('livechatpremium', __('Réponses rapides', 'livechatpremium'), __('Réponses rapides', 'livechatpremium'), 'edit_posts', 'lcp-canned',                   [$this, 'page_canned']);
        add_submenu_page('livechatpremium', __('Statistiques', 'livechatpremium'),  __('Statistiques', 'livechatpremium'), 'edit_posts',       'lcp-stats',                    [$this, 'page_stats']);
        add_submenu_page('livechatpremium', __('Réglages', 'livechatpremium'),      __('Réglages', 'livechatpremium'),     'manage_options',   'lcp-settings',                 [$this, 'page_settings']);
        add_submenu_page('livechatpremium', __('Licence', 'livechatpremium'),       __('Licence', 'livechatpremium'),      'manage_options',   'lcp-license',                  [$this, 'page_license']);
    }

    public function enqueue_assets( $hook ) {
        $lcp_pages = ['toplevel_page_livechatpremium','livechat_page_lcp-history','livechat_page_lcp-contacts','livechat_page_lcp-canned','livechat_page_lcp-stats','livechat_page_lcp-settings','livechat_page_lcp-license'];
        if ( ! in_array($hook, $lcp_pages) ) return;

        // Pusher JS
        wp_enqueue_script('pusher-js', 'https://js.pusher.com/8.3.0/pusher.min.js', [], null, true);

        // Admin JS principal
        wp_enqueue_script('lcp-admin', LCP_PLUGIN_URL . 'assets/js/admin.js', ['pusher-js','jquery'], LCP_VERSION, true);

        // Admin CSS
        wp_enqueue_style('lcp-admin', LCP_PLUGIN_URL . 'assets/css/admin.css', [], LCP_VERSION);

        // Données pour JS
        wp_localize_script('lcp-admin', 'LCP_Admin', [
            'rest_url'       => rest_url('livechatpremium/v1'),
            'nonce'          => wp_create_nonce('wp_rest'),
            'ajax_url'       => admin_url('admin-ajax.php'),
            'ajax_nonce'     => wp_create_nonce('lcp_ajax'),
            'pusher_key'     => get_option('lcp_pusher_key'),
            'pusher_cluster' => get_option('lcp_pusher_cluster', 'eu'),
            'admin_channel'  => LCP_Pusher::admin_channel(),
            'current_user'   => [
                'id'     => get_current_user_id(),
                'name'   => wp_get_current_user()->display_name,
                'avatar' => get_avatar_url(get_current_user_id(), ['size'=>32]),
            ],
            'woo_active'     => LCP_WooCommerce::is_active(),
            'ai_enabled'     => (bool) get_option('lcp_ai_enabled'),
            'translations'   => [
                'no_sessions'    => __('Aucun visiteur actif', 'livechatpremium'),
                'new_visitor'    => __('Nouveau visiteur', 'livechatpremium'),
                'type_message'   => __('Écrire un message...', 'livechatpremium'),
                'send'           => __('Envoyer', 'livechatpremium'),
                'close_chat'     => __('Fermer la conversation', 'livechatpremium'),
                'push_page'      => __('Pousser une page', 'livechatpremium'),
                'visitor_left'   => __('Le visiteur a quitté le chat', 'livechatpremium'),
                'confirm_close'  => __('Fermer cette conversation ?', 'livechatpremium'),
            ],
        ]);
    }

    public function admin_bar_node( $wp_admin_bar ) {
        if ( ! current_user_can('edit_posts') ) return;
        $unread = LCP_Database::get_unread_count();
        $title  = '<span class="ab-icon dashicons dashicons-format-chat"></span> LiveChat';
        if ($unread) $title .= ' <span style="background:#ef4444;color:#fff;border-radius:10px;padding:1px 6px;font-size:10px;">' . $unread . '</span>';

        $wp_admin_bar->add_node([
            'id'    => 'lcp-admin-bar',
            'title' => $title,
            'href'  => admin_url('admin.php?page=livechatpremium'),
        ]);
    }

    // ── PAGES ──────────────────────────────────────────

    public function page_dashboard() {
        include LCP_PLUGIN_DIR . 'admin/views/dashboard.php';
    }
    public function page_history() {
        include LCP_PLUGIN_DIR . 'admin/views/history.php';
    }
    public function page_contacts() {
        include LCP_PLUGIN_DIR . 'admin/views/contacts.php';
    }
    public function page_canned() {
        include LCP_PLUGIN_DIR . 'admin/views/canned.php';
    }
    public function page_stats() {
        include LCP_PLUGIN_DIR . 'admin/views/stats.php';
    }
    public function page_settings() {
        include LCP_PLUGIN_DIR . 'admin/views/settings.php';
    }
    public function page_license() {
        include LCP_PLUGIN_DIR . 'admin/views/license.php';
    }

    // ── AJAX ──────────────────────────────────────────

    public function save_settings() {
        check_ajax_referer('lcp_ajax', 'nonce');
        if ( ! current_user_can('manage_options') ) wp_send_json_error('unauthorized');

        $fields = [
            'lcp_pusher_app_id','lcp_pusher_key','lcp_pusher_secret','lcp_pusher_cluster',
            'lcp_pusher_beams_id','lcp_groq_api_key','lcp_groq_model',
            'lcp_site_domain','lcp_widget_position','lcp_widget_color','lcp_widget_icon',
            'lcp_widget_text','lcp_widget_size','lcp_popup_height','lcp_popup_width',
            'lcp_online_message','lcp_offline_message',
            'lcp_rgpd_enabled','lcp_rgpd_text','lcp_rgpd_retention',
            'lcp_ai_enabled','lcp_translation_enabled','lcp_bot_enabled','lcp_bot_name',
            'lcp_file_upload_enabled','lcp_max_file_size','lcp_allowed_file_types',
            'lcp_business_hours',
        ];

        foreach ( $fields as $field ) {
            if ( isset($_POST[$field]) ) {
                update_option($field, sanitize_text_field(wp_unslash($_POST[$field])));
            }
        }

        // Business hours (JSON)
        if ( isset($_POST['lcp_business_hours']) ) {
            $bh = json_decode(stripslashes($_POST['lcp_business_hours']), true);
            if ($bh) update_option('lcp_business_hours', json_encode($bh));
        }

        wp_send_json_success(['message' => __('Réglages sauvegardés.', 'livechatpremium')]);
    }

    public function save_canned() {
        check_ajax_referer('lcp_ajax', 'nonce');
        if ( ! current_user_can('edit_posts') ) wp_send_json_error();
        global $wpdb;

        $data = [
            'shortcut'  => sanitize_text_field($_POST['shortcut'] ?? ''),
            'title'     => sanitize_text_field($_POST['title'] ?? ''),
            'content'   => sanitize_textarea_field($_POST['content'] ?? ''),
            'category'  => sanitize_text_field($_POST['category'] ?? ''),
            'agent_id'  => get_current_user_id(),
        ];

        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $wpdb->update($wpdb->prefix . 'lcp_canned', $data, ['id' => $id]);
        } else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($wpdb->prefix . 'lcp_canned', $data);
            $id = $wpdb->insert_id;
        }
        wp_send_json_success(['id' => $id]);
    }

    public function delete_canned() {
        check_ajax_referer('lcp_ajax', 'nonce');
        if ( ! current_user_can('edit_posts') ) wp_send_json_error();
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'lcp_canned', ['id' => (int)$_POST['id']]);
        wp_send_json_success();
    }

    public function export_transcript() {
        check_ajax_referer('lcp_ajax', 'nonce');
        if ( ! current_user_can('edit_posts') ) wp_die('unauthorized');

        $token    = sanitize_text_field($_GET['token'] ?? '');
        $session  = LCP_Database::get_session($token);
        if ( ! $session ) wp_die('Session introuvable');

        $messages = LCP_Database::get_messages($session->id);

        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="transcript-' . $token . '.txt"');

        echo "=== LiveChatPremium — Transcript ===\n";
        echo "Site : " . get_bloginfo('name') . "\n";
        echo "Session : " . $token . "\n";
        echo "Date : " . $session->started_at . "\n";
        echo "Pays : " . $session->country . " | OS : " . $session->os . " | Navigateur : " . $session->browser . "\n";
        echo "Page : " . $session->page_url . "\n";
        echo str_repeat('=', 40) . "\n\n";

        foreach ($messages as $msg) {
            $who = $msg->sender_type === 'visitor' ? 'Visiteur' : 'Agent';
            echo "[{$msg->sent_at}] {$who} : {$msg->content}\n";
        }
        exit;
    }

    public function update_agent_status() {
        check_ajax_referer('lcp_ajax', 'nonce');
        global $wpdb;
        $status = sanitize_key($_POST['status'] ?? 'offline');
        $user_id = get_current_user_id();

        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}lcp_agents WHERE wp_user_id = %d", $user_id
        ));

        $data = ['status' => $status, 'last_seen' => current_time('mysql')];
        if ($exists) {
            $wpdb->update($wpdb->prefix . 'lcp_agents', $data, ['wp_user_id' => $user_id]);
        } else {
            $user = wp_get_current_user();
            $wpdb->insert($wpdb->prefix . 'lcp_agents', array_merge($data, [
                'wp_user_id'   => $user_id,
                'display_name' => $user->display_name,
                'created_at'   => current_time('mysql'),
            ]));
        }

        // Notifier via Pusher
        LCP_Pusher::trigger(LCP_Pusher::admin_channel(), 'agent-status', [
            'agent_id' => $user_id,
            'status'   => $status,
        ]);

        wp_send_json_success();
    }

    public function reset_settings() {
        check_ajax_referer('lcp_ajax','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('unauthorized');
        $options = ['lcp_pusher_app_id','lcp_pusher_key','lcp_pusher_secret','lcp_pusher_cluster',
                    'lcp_groq_api_key','lcp_widget_position','lcp_widget_color','lcp_widget_icon',
                    'lcp_widget_text','lcp_widget_size','lcp_popup_height','lcp_popup_width',
                    'lcp_online_message','lcp_offline_message','lcp_rgpd_enabled','lcp_rgpd_text',
                    'lcp_ai_enabled','lcp_bot_enabled','lcp_translation_enabled','lcp_file_upload_enabled'];
        foreach ($options as $opt) delete_option($opt);
        LCP_Installer::set_defaults();
        wp_send_json_success(['message' => 'Réglages réinitialisés.']);
    }

    public function activate_license() {
        check_ajax_referer('lcp_ajax','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('unauthorized');
        $key = sanitize_text_field($_POST['license_key'] ?? '');
        if (empty($key)) { wp_send_json_error('Clé vide.'); return; }
        // Validation simple — à remplacer par un vrai système de licence
        if (strlen($key) >= 20) {
            update_option('lcp_license_key',    $key);
            update_option('lcp_license_status', 'premium');
            wp_send_json_success(['message' => '✅ Licence Premium activée !']);
        } else {
            wp_send_json_error('Clé de licence invalide.');
        }
    }


    public function pusher_auth() {
        $socket_id    = sanitize_text_field( $_POST['socket_id']    ?? '' );
        $channel_name = sanitize_text_field( $_POST['channel_name'] ?? '' );

        if ( ! $socket_id || ! $channel_name ) {
            wp_send_json_error('Missing params', 400);
            return;
        }

        // Canal session visiteur — vérifier token valide
        if ( strpos($channel_name, 'private-lcp-session-') === 0 ) {
            $token   = str_replace('private-lcp-session-', '', $channel_name);
            $session = LCP_Database::get_session($token);
            if ( ! $session ) { status_header(403); wp_die('Unauthorized'); }
            $auth = LCP_Pusher::authenticate($socket_id, $channel_name);
            if (!$auth) { status_header(500); wp_die('Pusher error'); }
            wp_send_json(json_decode($auth, true));
            return;
        }

        // Canal admin — vérifier nonce WP
        $nonce = sanitize_text_field( $_POST['nonce'] ?? $_SERVER['HTTP_X_WP_NONCE'] ?? '' );
        if ( ! wp_verify_nonce($nonce, 'wp_rest') && ! wp_verify_nonce($nonce, 'lcp_ajax') ) {
            // Dernier recours : vérifier si utilisateur connecté
            if ( ! is_user_logged_in() || ! current_user_can('edit_posts') ) {
                status_header(403); wp_die('Unauthorized');
                return;
            }
        }

        if ( strpos($channel_name, 'private-lcp-admin') === 0 || strpos($channel_name, 'presence-lcp') === 0 ) {
            $user_data = null;
            if ( strpos($channel_name, 'presence-') === 0 && is_user_logged_in() ) {
                $u = wp_get_current_user();
                $user_data = ['id' => $u->ID, 'info' => ['name' => $u->display_name]];
            }
            $auth = LCP_Pusher::authenticate($socket_id, $channel_name, $user_data);
            if (!$auth) { status_header(500); wp_die('Pusher error'); }
            wp_send_json(json_decode($auth, true));
            return;
        }

        status_header(403);
        wp_die('Unauthorized');
    }

}