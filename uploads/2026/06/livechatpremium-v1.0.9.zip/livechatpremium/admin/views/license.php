<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lcp-admin-wrap" id="lcp-license">
  <div class="lcp-header">
    <div class="lcp-header-left"><h1>🔑 <?php _e('Licence', 'livechatpremium'); ?></h1></div>
  </div>

  <?php $status = get_option('lcp_license_status', 'free'); ?>

  <div class="lcp-license-box">
    <div class="lcp-license-status lcp-license-<?php echo esc_attr($status); ?>">
      <?php if ($status === 'free'): ?>
        <h2>🆓 <?php _e('Version Gratuite', 'livechatpremium'); ?></h2>
        <p><?php _e('Chat live, 1 agent, pop-up configurable, historique 30 jours.', 'livechatpremium'); ?></p>
      <?php else: ?>
        <h2>⭐ <?php _e('Version Premium — Activée', 'livechatpremium'); ?></h2>
        <p><?php _e('Toutes les fonctionnalités sont actives.', 'livechatpremium'); ?></p>
      <?php endif; ?>
    </div>

    <div class="lcp-field-group" style="margin-top:20px; max-width:500px;">
      <label><?php _e('Clé de licence', 'livechatpremium'); ?></label>
      <div style="display:flex; gap:10px;">
        <input type="text" id="license-key-input"
               value="<?php echo esc_attr(get_option('lcp_license_key')); ?>"
               placeholder="XXXXX-XXXXX-XXXXX-XXXXX" class="lcp-input">
        <button class="lcp-btn lcp-btn-primary" id="btn-activate-license">
          <?php _e('Activer', 'livechatpremium'); ?>
        </button>
      </div>
      <p id="license-result" style="margin-top:8px; font-size:13px;"></p>
    </div>

    <!-- Tableau comparatif -->
    <div class="lcp-comparison-table">
      <h3><?php _e('Fonctionnalités par version', 'livechatpremium'); ?></h3>
      <div class="lcp-table-wrap" style="margin:0;">
        <table class="lcp-table">
          <thead>
            <tr>
              <th><?php _e('Fonctionnalité', 'livechatpremium'); ?></th>
              <th style="text-align:center;"><?php _e('Gratuit', 'livechatpremium'); ?></th>
              <th style="text-align:center;"><?php _e('Premium', 'livechatpremium'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php
            $features = [
              [__('Chat live temps réel',        'livechatpremium'), true,  true],
              [__('Pop-up 100% configurable',     'livechatpremium'), true,  true],
              [__('Infos visiteur (pays, OS...)', 'livechatpremium'), true,  true],
              [__('1 agent',                      'livechatpremium'), true,  true],
              [__('Historique 30 jours',          'livechatpremium'), true,  true],
              [__('RGPD — modal consentement',    'livechatpremium'), true,  true],
              [__('Agents illimités',             'livechatpremium'), false, true],
              [__('IA Groq (suggestions)',        'livechatpremium'), false, true],
              [__('Chatbot automatique',          'livechatpremium'), false, true],
              [__('Traduction automatique',       'livechatpremium'), false, true],
              [__('Push produits WooCommerce',    'livechatpremium'), false, true],
              [__('Messages vocaux',              'livechatpremium'), false, true],
              [__('Envoi fichiers / images / PDF','livechatpremium'), false, true],
              [__('CRM contacts',                 'livechatpremium'), false, true],
              [__('Historique illimité',          'livechatpremium'), false, true],
              [__('Statistiques avancées',        'livechatpremium'), false, true],
              [__('Notifications push Pusher',    'livechatpremium'), false, true],
              [__('Export transcripts PDF/TXT',   'livechatpremium'), false, true],
            ];
            foreach ($features as [$label, $free, $premium]):
            ?>
            <tr>
              <td><?php echo esc_html($label); ?></td>
              <td style="text-align:center; font-size:16px; color:<?php echo $free ? '#22c55e' : '#cbd5e1'; ?>">
                <?php echo $free ? '✓' : '—'; ?>
              </td>
              <td style="text-align:center; font-size:16px; color:#22c55e;">✓</td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
document.getElementById('btn-activate-license')?.addEventListener('click', function() {
  const key = document.getElementById('license-key-input').value.trim();
  const result = document.getElementById('license-result');
  if (!key) { result.textContent = '⚠️ Saisissez une clé.'; result.style.color = '#f59e0b'; return; }

  this.textContent = '⏳...';
  this.disabled = true;

  const form = new FormData();
  form.append('action', 'lcp_activate_license');
  form.append('nonce', '<?php echo wp_create_nonce("lcp_ajax"); ?>');
  form.append('license_key', key);

  fetch('<?php echo admin_url("admin-ajax.php"); ?>', { method:'POST', body: form })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        result.textContent = '✅ ' + (data.data?.message || 'Licence activée !');
        result.style.color = '#22c55e';
        setTimeout(() => location.reload(), 1500);
      } else {
        result.textContent = '❌ ' + (data.data || 'Clé invalide.');
        result.style.color = '#ef4444';
      }
    })
    .catch(() => { result.textContent = '❌ Erreur réseau.'; result.style.color = '#ef4444'; })
    .finally(() => { this.textContent = '<?php _e("Activer", "livechatpremium"); ?>'; this.disabled = false; });
});
</script>
