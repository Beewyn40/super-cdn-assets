<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lcp-admin-wrap" id="lcp-contacts">
  <div class="lcp-header">
    <div class="lcp-header-left"><h1>👥 <?php _e('Contacts CRM', 'livechatpremium'); ?></h1></div>
    <div class="lcp-header-right">
      <input type="text" id="contacts-search" placeholder="<?php _e('Rechercher...', 'livechatpremium'); ?>" class="lcp-input" style="width:220px;">
    </div>
  </div>
  <div id="lcp-contacts-grid" class="lcp-contacts-grid">
    <div class="lcp-loading"><?php _e('Chargement...', 'livechatpremium'); ?></div>
  </div>
</div>
