<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lcp-admin-wrap" id="lcp-stats">
  <div class="lcp-header">
    <div class="lcp-header-left"><h1>📊 <?php _e('Statistiques', 'livechatpremium'); ?></h1></div>
    <div class="lcp-header-right">
      <select id="stats-period" class="lcp-input" style="width:auto;">
        <option value="7"><?php _e('7 derniers jours', 'livechatpremium'); ?></option>
        <option value="30" selected><?php _e('30 derniers jours', 'livechatpremium'); ?></option>
        <option value="90"><?php _e('90 derniers jours', 'livechatpremium'); ?></option>
        <option value="365"><?php _e('Cette année', 'livechatpremium'); ?></option>
      </select>
    </div>
  </div>
  <div class="lcp-stats-grid" id="lcp-stats-grid">
    <div class="lcp-stat-big"><span class="lcp-stat-val" id="s-sessions">—</span><span class="lcp-stat-lbl"><?php _e('Conversations', 'livechatpremium'); ?></span></div>
    <div class="lcp-stat-big"><span class="lcp-stat-val" id="s-messages">—</span><span class="lcp-stat-lbl"><?php _e('Messages échangés', 'livechatpremium'); ?></span></div>
    <div class="lcp-stat-big"><span class="lcp-stat-val" id="s-contacts">—</span><span class="lcp-stat-lbl"><?php _e('Contacts CRM', 'livechatpremium'); ?></span></div>
    <div class="lcp-stat-big"><span class="lcp-stat-val" id="s-missed">—</span><span class="lcp-stat-lbl"><?php _e('Conversations manquées', 'livechatpremium'); ?></span></div>
    <div class="lcp-stat-big"><span class="lcp-stat-val" id="s-response">—</span><span class="lcp-stat-lbl"><?php _e('Temps de réponse moyen', 'livechatpremium'); ?></span></div>
  </div>
</div>
