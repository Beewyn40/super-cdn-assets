<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lcp-admin-wrap" id="lcp-dashboard">

  <!-- HEADER -->
  <div class="lcp-header">
    <div class="lcp-header-left">
      <span class="lcp-logo">💬</span>
      <h1><?php _e('LiveChat Premium', 'livechatpremium'); ?></h1>
      <span class="lcp-version">v<?php echo LCP_VERSION; ?></span>
    </div>
    <div class="lcp-header-right">
      <div class="lcp-agent-status">
        <span id="lcp-status-dot" class="lcp-dot lcp-dot-offline"></span>
        <select id="lcp-agent-status-select">
          <option value="online"><?php _e('En ligne', 'livechatpremium'); ?></option>
          <option value="away"><?php _e('Absent', 'livechatpremium'); ?></option>
          <option value="offline" selected><?php _e('Hors ligne', 'livechatpremium'); ?></option>
        </select>
      </div>
      <?php if ( ! LCP_Pusher::is_configured() ): ?>
      <a href="<?php echo admin_url('admin.php?page=lcp-settings'); ?>" class="lcp-btn lcp-btn-warning">
        ⚠️ <?php _e('Configurer Pusher', 'livechatpremium'); ?>
      </a>
      <?php endif; ?>
    </div>
  </div>

  <?php if ( ! LCP_Pusher::is_configured() ): ?>
  <div class="lcp-notice lcp-notice-error">
    <strong><?php _e('Pusher non configuré', 'livechatpremium'); ?></strong> —
    <?php _e('Allez dans', 'livechatpremium'); ?>
    <a href="<?php echo admin_url('admin.php?page=lcp-settings'); ?>"><?php _e('Réglages', 'livechatpremium'); ?></a>
    <?php _e('pour saisir vos clés Pusher.', 'livechatpremium'); ?>
  </div>
  <?php endif; ?>

  <!-- STATS RAPIDES -->
  <div class="lcp-stats-bar">
    <div class="lcp-stat-card">
      <span class="lcp-stat-num" id="stat-active">0</span>
      <span class="lcp-stat-label"><?php _e('Visiteurs actifs', 'livechatpremium'); ?></span>
    </div>
    <div class="lcp-stat-card">
      <span class="lcp-stat-num" id="stat-waiting">0</span>
      <span class="lcp-stat-label"><?php _e('En attente', 'livechatpremium'); ?></span>
    </div>
    <div class="lcp-stat-card">
      <span class="lcp-stat-num" id="stat-today">0</span>
      <span class="lcp-stat-label"><?php _e('Aujourd\'hui', 'livechatpremium'); ?></span>
    </div>
    <div class="lcp-stat-card">
      <span class="lcp-stat-num" id="stat-unread">0</span>
      <span class="lcp-stat-label"><?php _e('Non lus', 'livechatpremium'); ?></span>
    </div>
  </div>

  <!-- LAYOUT PRINCIPAL -->
  <div class="lcp-layout">

    <!-- COLONNE GAUCHE : Liste visiteurs -->
    <div class="lcp-sidebar" id="lcp-visitors-list">
      <div class="lcp-sidebar-header">
        <h3><?php _e('Visiteurs', 'livechatpremium'); ?></h3>
        <button class="lcp-refresh-btn" id="lcp-refresh-sessions" title="<?php _e('Actualiser', 'livechatpremium'); ?>">↻</button>
      </div>
      <div class="lcp-search-box">
        <input type="text" id="lcp-search-visitors" placeholder="<?php _e('Rechercher...', 'livechatpremium'); ?>">
      </div>
      <div class="lcp-visitors-container" id="lcp-visitors-container">
        <div class="lcp-empty-state">
          <span>👁️</span>
          <p><?php _e('Aucun visiteur actif', 'livechatpremium'); ?></p>
        </div>
      </div>
    </div>

    <!-- COLONNE CENTRE : Fenêtre de chat -->
    <div class="lcp-chat-area" id="lcp-chat-area">
      <div class="lcp-chat-placeholder" id="lcp-chat-placeholder">
        <span>💬</span>
        <p><?php _e('Sélectionnez un visiteur pour démarrer', 'livechatpremium'); ?></p>
      </div>

      <!-- Chat actif (caché par défaut) -->
      <div class="lcp-chat-window" id="lcp-chat-window" style="display:none;">

        <!-- Header visiteur -->
        <div class="lcp-chat-header">
          <div class="lcp-visitor-info">
            <div class="lcp-visitor-avatar" id="chat-avatar">?</div>
            <div class="lcp-visitor-details">
              <strong id="chat-visitor-id"></strong>
              <small id="chat-visitor-meta"></small>
            </div>
          </div>
          <div class="lcp-chat-actions">
            <button class="lcp-action-btn" id="btn-push-page" title="<?php _e('Pousser une page', 'livechatpremium'); ?>">📄</button>
            <button class="lcp-action-btn" id="btn-send-product" title="<?php _e('Envoyer un produit', 'livechatpremium'); ?>">🛒</button>
            <button class="lcp-action-btn" id="btn-ai-suggest" title="<?php _e('Suggestions IA', 'livechatpremium'); ?>">🤖</button>
            <button class="lcp-action-btn" id="btn-transcript" title="<?php _e('Exporter transcript', 'livechatpremium'); ?>">📋</button>
            <button class="lcp-action-btn lcp-btn-danger" id="btn-close-session" title="<?php _e('Fermer conversation', 'livechatpremium'); ?>">✕</button>
          </div>
        </div>

        <!-- Navigation visiteur en temps réel -->
        <div class="lcp-visitor-nav" id="lcp-visitor-nav">
          <span>🌐</span> <span id="visitor-current-page"><?php _e('Page inconnue', 'livechatpremium'); ?></span>
        </div>

        <!-- Messages -->
        <div class="lcp-messages-container" id="lcp-messages-container"></div>

        <!-- Typing indicator -->
        <div class="lcp-typing" id="lcp-typing-indicator" style="display:none;">
          <span></span><span></span><span></span>
          <small><?php _e('Le visiteur écrit...', 'livechatpremium'); ?></small>
        </div>

        <!-- Suggestions IA -->
        <div class="lcp-ai-suggestions" id="lcp-ai-suggestions" style="display:none;">
          <div class="lcp-ai-header">🤖 <?php _e('Suggestions IA', 'livechatpremium'); ?> <button id="btn-close-ai">✕</button></div>
          <div id="lcp-suggestions-list"></div>
        </div>

        <!-- Zone de saisie -->
        <div class="lcp-input-area">
          <!-- Toolbar -->
          <div class="lcp-input-toolbar">
            <button class="lcp-tool-btn" id="btn-canned" title="<?php _e('Réponses rapides', 'livechatpremium'); ?>">⚡</button>
            <button class="lcp-tool-btn" id="btn-upload-file" title="<?php _e('Envoyer un fichier', 'livechatpremium'); ?>">📎</button>
            <button class="lcp-tool-btn" id="btn-record-audio" title="<?php _e('Message vocal', 'livechatpremium'); ?>">🎤</button>
            <button class="lcp-tool-btn" id="btn-send-link" title="<?php _e('Envoyer un lien', 'livechatpremium'); ?>">🔗</button>
            <input type="file" id="lcp-file-input" style="display:none;" accept="image/*,.pdf,.mp3,.ogg,.wav">
          </div>

          <!-- Textarea + Envoi -->
          <div class="lcp-textarea-row">
            <textarea id="lcp-message-input" placeholder="<?php _e('Écrire un message...', 'livechatpremium'); ?>" rows="2"></textarea>
            <button class="lcp-send-btn" id="lcp-send-btn">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
            </button>
          </div>

          <!-- Audio recorder (caché) -->
          <div class="lcp-audio-recorder" id="lcp-audio-recorder" style="display:none;">
            <div class="lcp-rec-indicator">⏺ <?php _e('Enregistrement...', 'livechatpremium'); ?> <span id="lcp-rec-timer">0:00</span></div>
            <button id="btn-stop-record" class="lcp-btn lcp-btn-danger"><?php _e('Arrêter', 'livechatpremium'); ?></button>
            <button id="btn-cancel-record" class="lcp-btn"><?php _e('Annuler', 'livechatpremium'); ?></button>
          </div>
        </div>
      </div>
    </div>

    <!-- COLONNE DROITE : Infos visiteur -->
    <div class="lcp-info-panel" id="lcp-info-panel" style="display:none;">
      <div class="lcp-panel-section">
        <h4><?php _e('Informations visiteur', 'livechatpremium'); ?></h4>
        <div id="lcp-visitor-details-panel"></div>
      </div>
      <div class="lcp-panel-section">
        <h4><?php _e('Navigation', 'livechatpremium'); ?></h4>
        <div id="lcp-visitor-pages"></div>
      </div>
      <div class="lcp-panel-section">
        <h4><?php _e('Actions rapides', 'livechatpremium'); ?></h4>
        <div class="lcp-quick-actions">
          <button class="lcp-btn lcp-btn-full" id="qa-push-home">🏠 <?php _e('Pousser l\'accueil', 'livechatpremium'); ?></button>

          <button class="lcp-btn lcp-btn-full" id="qa-push-contact">📧 <?php _e('Pousser Contact', 'livechatpremium'); ?></button>
        </div>
      </div>
      <div class="lcp-panel-section" id="lcp-contact-section">
        <h4><?php _e('Contact CRM', 'livechatpremium'); ?></h4>
        <div id="lcp-contact-info"></div>
      </div>
    </div>

  </div><!-- .lcp-layout -->
</div><!-- .lcp-admin-wrap -->

<!-- MODALS -->

<!-- Modal Push Page -->
<div class="lcp-modal" id="modal-push-page" style="display:none;">
  <div class="lcp-modal-content">
    <div class="lcp-modal-header">
      <h3>📄 <?php _e('Pousser une page', 'livechatpremium'); ?></h3>
      <button class="lcp-modal-close">✕</button>
    </div>
    <div class="lcp-modal-body">
      <div class="lcp-tab-nav">
        <button class="lcp-tab active" data-tab="pages"><?php _e('Pages/Articles', 'livechatpremium'); ?></button>
        <?php if (LCP_WooCommerce::is_active()): ?>
        <button class="lcp-tab" data-tab="products"><?php _e('Produits', 'livechatpremium'); ?></button>
        <button class="lcp-tab" data-tab="categories"><?php _e('Catégories', 'livechatpremium'); ?></button>
        <?php endif; ?>
        <button class="lcp-tab" data-tab="custom"><?php _e('URL personnalisée', 'livechatpremium'); ?></button>
      </div>
      <div class="lcp-tab-content active" id="tab-pages">
        <input type="text" id="search-pages" placeholder="<?php _e('Rechercher une page...', 'livechatpremium'); ?>" class="lcp-input">
        <div id="pages-results" class="lcp-search-results"></div>
      </div>
      <?php if (LCP_WooCommerce::is_active()): ?>
      <div class="lcp-tab-content" id="tab-products">
        <input type="text" id="search-products" placeholder="<?php _e('Rechercher un produit...', 'livechatpremium'); ?>" class="lcp-input">
        <div id="products-results" class="lcp-search-results"></div>
      </div>
      <div class="lcp-tab-content" id="tab-categories">
        <input type="text" id="search-categories" placeholder="<?php _e('Rechercher une catégorie...', 'livechatpremium'); ?>" class="lcp-input">
        <div id="categories-results" class="lcp-search-results"></div>
      </div>
      <?php endif; ?>
      <div class="lcp-tab-content" id="tab-custom">
        <input type="url" id="custom-url" placeholder="https://" class="lcp-input">
        <input type="text" id="custom-title" placeholder="<?php _e('Titre (optionnel)', 'livechatpremium'); ?>" class="lcp-input">
        <button class="lcp-btn lcp-btn-primary" id="btn-push-custom"><?php _e('Pousser cette URL', 'livechatpremium'); ?></button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Réponses rapides -->
<div class="lcp-modal" id="modal-canned" style="display:none;">
  <div class="lcp-modal-content lcp-modal-sm">
    <div class="lcp-modal-header">
      <h3>⚡ <?php _e('Réponses rapides', 'livechatpremium'); ?></h3>
      <button class="lcp-modal-close">✕</button>
    </div>
    <div class="lcp-modal-body">
      <input type="text" id="search-canned" placeholder="<?php _e('Chercher ou taper /shortcut...', 'livechatpremium'); ?>" class="lcp-input">
      <div id="canned-list" class="lcp-canned-list"></div>
    </div>
  </div>
</div>

<!-- Overlay modal -->
<div class="lcp-modal-overlay" id="lcp-modal-overlay" style="display:none;"></div>
