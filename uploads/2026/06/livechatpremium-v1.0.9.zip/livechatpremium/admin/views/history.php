<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lcp-admin-wrap" id="lcp-history">
  <div class="lcp-header">
    <div class="lcp-header-left"><h1>📋 <?php _e('Historique des conversations', 'livechatpremium'); ?></h1></div>
  </div>
  <div class="lcp-filter-bar">
    <input type="text" id="history-search" placeholder="<?php _e('Rechercher...', 'livechatpremium'); ?>" class="lcp-input">
    <select id="history-status" class="lcp-input">
      <option value=""><?php _e('Tous les statuts', 'livechatpremium'); ?></option>
      <option value="closed"><?php _e('Fermé', 'livechatpremium'); ?></option>
      <option value="missed"><?php _e('Manqué', 'livechatpremium'); ?></option>
    </select>
    <input type="date" id="history-date-from" class="lcp-input">
    <input type="date" id="history-date-to" class="lcp-input">
  </div>
  <div id="lcp-history-table" class="lcp-table-wrap">
    <table class="lcp-table">
      <thead><tr>
        <th><?php _e('Date', 'livechatpremium'); ?></th>
        <th><?php _e('Visiteur', 'livechatpremium'); ?></th>
        <th><?php _e('Pays', 'livechatpremium'); ?></th>
        <th><?php _e('Navigateur', 'livechatpremium'); ?></th>
        <th><?php _e('Messages', 'livechatpremium'); ?></th>
        <th><?php _e('Statut', 'livechatpremium'); ?></th>
        <th><?php _e('Actions', 'livechatpremium'); ?></th>
      </tr></thead>
      <tbody id="history-tbody">
        <tr><td colspan="7" class="lcp-loading"><?php _e('Chargement...', 'livechatpremium'); ?></td></tr>
      </tbody>
    </table>
  </div>
  <div class="lcp-pagination" id="history-pagination"></div>
</div>
