<?php if ( ! defined('ABSPATH') ) exit; ?>

<style>
#lcp-settings-page { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #1e293b; }
#lcp-settings-page * { box-sizing: border-box; }
.lcp-s-header { display:flex; align-items:center; justify-content:space-between; padding:14px 24px; background:#fff; border-bottom:1px solid #e2e8f0; margin-bottom:20px; }
.lcp-s-header h1 { margin:0; font-size:18px; }
.lcp-s-notice { display:none; padding:10px 16px; border-radius:8px; margin:0 24px 16px; font-size:13px; border-left:4px solid; }
.lcp-s-notice.success { background:#f0fdf4; border-color:#22c55e; color:#166534; display:block; }
.lcp-s-notice.error   { background:#fef2f2; border-color:#ef4444; color:#991b1b; display:block; }
.lcp-s-layout { display:flex; margin:0 24px; background:#fff; border:1px solid #e2e8f0; border-radius:10px; overflow:hidden; min-height:600px; }
.lcp-s-nav { width:200px; border-right:1px solid #e2e8f0; background:#f8fafc; flex-shrink:0; padding:12px 0; }
.lcp-s-navbtn { display:block; width:100%; text-align:left; padding:10px 16px; background:none; border:none; border-left:3px solid transparent; cursor:pointer; font-size:13px; color:#64748b; transition:all .15s; }
.lcp-s-navbtn:hover  { background:#e2e8f0; color:#1e293b; }
.lcp-s-navbtn.active { color:#6366f1; font-weight:700; border-left-color:#6366f1; background:#eef2ff; }
.lcp-s-content { flex:1; padding:24px; overflow-y:auto; }
.lcp-s-section { display:none; }
.lcp-s-section.active { display:block; }
.lcp-s-section h2 { font-size:16px; font-weight:700; margin:0 0 6px; }
.lcp-s-desc { color:#64748b; font-size:13px; margin:0 0 20px; }
.lcp-s-group { margin-bottom:18px; }
.lcp-s-group label { display:block; font-size:13px; font-weight:600; margin-bottom:5px; color:#1e293b; }
.lcp-s-group .hint { font-size:11px; color:#94a3b8; margin:4px 0 0; }
.lcp-s-row { display:flex; gap:16px; }
.lcp-s-half { flex:1; }
.lcp-s-input { width:100%; padding:8px 12px; border:1px solid #e2e8f0; border-radius:8px; font-size:13px; outline:none; color:#1e293b; background:#fff; transition:border-color .2s; }
.lcp-s-input:focus { border-color:#6366f1; }
select.lcp-s-input { cursor:pointer; }
.lcp-s-textarea { width:100%; padding:8px 12px; border:1px solid #e2e8f0; border-radius:8px; font-size:13px; outline:none; min-height:80px; resize:vertical; font-family:inherit; }
.lcp-s-textarea:focus { border-color:#6366f1; }
.lcp-s-toggle { display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600; }
.lcp-s-toggle input { width:16px; height:16px; accent-color:#6366f1; cursor:pointer; }
.lcp-s-btn { display:inline-flex; align-items:center; gap:6px; padding:8px 16px; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; border:1px solid #e2e8f0; background:#fff; color:#1e293b; transition:all .15s; }
.lcp-s-btn:hover { background:#f8fafc; }
.lcp-s-btn-primary { background:#6366f1; color:#fff; border-color:#6366f1; }
.lcp-s-btn-primary:hover { background:#4f46e5; }
.lcp-s-btn-danger { background:#ef4444; color:#fff; border-color:#ef4444; }
.lcp-s-color-row { display:flex; align-items:center; gap:8px; }
.lcp-s-color-row input[type="color"] { width:40px; height:36px; border:1px solid #e2e8f0; border-radius:6px; cursor:pointer; padding:2px; }
.lcp-s-icons { display:flex; gap:6px; flex-wrap:wrap; }
.lcp-s-icon { font-size:22px; cursor:pointer; padding:5px; border-radius:6px; border:2px solid transparent; transition:all .15s; }
.lcp-s-icon:hover, .lcp-s-icon.active { border-color:#6366f1; background:#eef2ff; }
.lcp-s-preview { background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:20px; margin-top:16px; }
.lcp-s-preview h4 { margin:0 0 12px; font-size:11px; text-transform:uppercase; color:#94a3b8; letter-spacing:.05em; }
.lcp-s-preview-widget { display:flex; justify-content:flex-end; padding:10px; min-height:70px; align-items:flex-end; }
.lcp-s-bubble { display:inline-flex; align-items:center; gap:8px; background:#6366f1; color:#fff; border-radius:50px; padding:0 20px 0 14px; height:52px; box-shadow:0 4px 16px rgba(0,0,0,.2); }
.lcp-s-hr { border:none; border-top:1px solid #e2e8f0; margin:20px 0; }
.lcp-s-badge { display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:700; }
.lcp-s-badge-ok  { background:#dcfce7; color:#166534; }
.lcp-s-badge-warn{ background:#fef9c3; color:#854d0e; }
.lcp-s-danger-zone { border-top:1px solid #fecaca; padding-top:16px; margin-top:16px; }
.lcp-s-danger-zone h4 { color:#ef4444; margin:0 0 10px; }
.lcp-hours-grid { display:flex; flex-direction:column; gap:8px; margin-top:12px; }
.lcp-hour-row { display:flex; align-items:center; gap:12px; padding:8px 12px; background:#f8fafc; border-radius:8px; }
.lcp-hour-day { width:100px; font-size:13px; font-weight:600; }
.lcp-hour-times { display:flex; align-items:center; gap:8px; }
.lcp-hour-times input[type="time"] { padding:4px 8px; border:1px solid #e2e8f0; border-radius:6px; font-size:12px; }
#pusher-test-result { font-size:12px; margin-left:10px; }
</style>

<div id="lcp-settings-page">

  <div class="lcp-s-header">
    <div style="display:flex;align-items:center;gap:10px;">
      <span style="font-size:24px;">⚙️</span>
      <h1>Réglages LiveChatPremium</h1>
    </div>
    <button class="lcp-s-btn lcp-s-btn-primary" id="lcp-save-btn">💾 Sauvegarder</button>
  </div>

  <div id="lcp-s-notice" class="lcp-s-notice"></div>

  <div class="lcp-s-layout">

    <!-- NAV -->
    <div class="lcp-s-nav">
      <button class="lcp-s-navbtn active" data-sec="pusher">🔌 Pusher</button>
      <button class="lcp-s-navbtn" data-sec="groq">🤖 IA / Groq</button>
      <button class="lcp-s-navbtn" data-sec="widget">🎨 Widget</button>
      <button class="lcp-s-navbtn" data-sec="messages">💬 Messages</button>
      <button class="lcp-s-navbtn" data-sec="uploads">📎 Fichiers</button>
      <button class="lcp-s-navbtn" data-sec="rgpd">🔒 RGPD</button>
      <button class="lcp-s-navbtn" data-sec="hours">🕐 Horaires</button>
      <button class="lcp-s-navbtn" data-sec="advanced">⚙️ Avancé</button>
    </div>

    <!-- CONTENT -->
    <div class="lcp-s-content">

      <!-- PUSHER -->
      <div class="lcp-s-section active" id="sec-pusher">
        <h2>🔌 Pusher Channels</h2>
        <p class="lcp-s-desc">Dashboard Pusher → votre app → <strong>App Keys</strong></p>
        <div class="lcp-s-group">
          <label>App ID</label>
          <input type="text" class="lcp-s-input" name="lcp_pusher_app_id" value="<?php echo esc_attr(get_option('lcp_pusher_app_id')); ?>" placeholder="1234567">
        </div>
        <div class="lcp-s-group">
          <label>Key</label>
          <input type="text" class="lcp-s-input" name="lcp_pusher_key" value="<?php echo esc_attr(get_option('lcp_pusher_key')); ?>" placeholder="abc123...">
        </div>
        <div class="lcp-s-group">
          <label>Secret</label>
          <input type="password" class="lcp-s-input" name="lcp_pusher_secret" value="<?php echo esc_attr(get_option('lcp_pusher_secret')); ?>" placeholder="••••••••">
        </div>
        <div class="lcp-s-group">
          <label>Cluster</label>
          <select class="lcp-s-input" name="lcp_pusher_cluster" style="width:auto;">
            <?php foreach(['eu','mt1','us2','us3','ap1','ap2','ap3','sa1'] as $c): ?>
            <option value="<?php echo $c; ?>" <?php selected(get_option('lcp_pusher_cluster','eu'),$c); ?>><?php echo strtoupper($c); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="lcp-s-group">
          <label>Pusher Beams Instance ID <span style="font-weight:400;color:#94a3b8;">(optionnel)</span></label>
          <input type="text" class="lcp-s-input" name="lcp_pusher_beams_id" value="<?php echo esc_attr(get_option('lcp_pusher_beams_id')); ?>" placeholder="cb286d7e-...">
        </div>
        <div class="lcp-s-group" style="display:flex;align-items:center;gap:10px;">
          <button type="button" class="lcp-s-btn" id="btn-test-pusher">🧪 Tester la connexion</button>
          <span id="pusher-test-result"></span>
        </div>
      </div>

      <!-- GROQ -->
      <div class="lcp-s-section" id="sec-groq">
        <h2>🤖 Intelligence Artificielle — Groq</h2>
        <p class="lcp-s-desc">Compte gratuit sur <strong>console.groq.com</strong> → API Keys → Create API Key</p>
        <div class="lcp-s-group">
          <label class="lcp-s-toggle">
            <input type="checkbox" name="lcp_ai_enabled" value="1" <?php checked(get_option('lcp_ai_enabled'),'1'); ?>>
            Activer l'IA
          </label>
        </div>
        <div class="lcp-s-group">
          <label>Clé API Groq</label>
          <input type="password" class="lcp-s-input" name="lcp_groq_api_key" value="<?php echo esc_attr(get_option('lcp_groq_api_key')); ?>" placeholder="gsk_...">
        </div>
        <div class="lcp-s-group">
          <label>Modèle</label>
          <select class="lcp-s-input" name="lcp_groq_model">
            <?php $m=get_option('lcp_groq_model','llama-3.1-70b-versatile'); ?>
            <option value="llama-3.1-70b-versatile" <?php selected($m,'llama-3.1-70b-versatile');?>>Llama 3.1 70B (recommandé)</option>
            <option value="llama-3.1-8b-instant"    <?php selected($m,'llama-3.1-8b-instant');   ?>>Llama 3.1 8B (rapide)</option>
            <option value="mixtral-8x7b-32768"       <?php selected($m,'mixtral-8x7b-32768');      ?>>Mixtral 8x7B</option>
          </select>
        </div>
        <hr class="lcp-s-hr">
        <div class="lcp-s-group">
          <label class="lcp-s-toggle">
            <input type="checkbox" name="lcp_bot_enabled" value="1" <?php checked(get_option('lcp_bot_enabled'),'1'); ?>>
            Activer le chatbot automatique
          </label>
          <p class="hint">Répond automatiquement quand aucun agent n'est disponible.</p>
        </div>
        <div class="lcp-s-group">
          <label>Nom du bot</label>
          <input type="text" class="lcp-s-input" name="lcp_bot_name" value="<?php echo esc_attr(get_option('lcp_bot_name','Assistant')); ?>">
        </div>
        <hr class="lcp-s-hr">
        <div class="lcp-s-group">
          <label class="lcp-s-toggle">
            <input type="checkbox" name="lcp_translation_enabled" value="1" <?php checked(get_option('lcp_translation_enabled'),'1'); ?>>
            Activer la traduction automatique (MyMemory — gratuit)
          </label>
        </div>
      </div>

      <!-- WIDGET -->
      <div class="lcp-s-section" id="sec-widget">
        <h2>🎨 Apparence du widget</h2>
        <div class="lcp-s-row">
          <div class="lcp-s-half lcp-s-group">
            <label>Position</label>
            <select class="lcp-s-input" name="lcp_widget_position" id="s-position">
              <?php $p=get_option('lcp_widget_position','bottom-right'); ?>
              <option value="bottom-right" <?php selected($p,'bottom-right');?>>Bas droite</option>
              <option value="bottom-left"  <?php selected($p,'bottom-left'); ?>>Bas gauche</option>
              <option value="top-right"    <?php selected($p,'top-right');   ?>>Haut droite</option>
              <option value="top-left"     <?php selected($p,'top-left');    ?>>Haut gauche</option>
            </select>
          </div>
          <div class="lcp-s-half lcp-s-group">
            <label>Taille du bouton</label>
            <select class="lcp-s-input" name="lcp_widget_size">
              <?php $sz=get_option('lcp_widget_size','medium'); ?>
              <option value="small"  <?php selected($sz,'small'); ?>>Petite</option>
              <option value="medium" <?php selected($sz,'medium');?>>Moyenne</option>
              <option value="large"  <?php selected($sz,'large'); ?>>Grande</option>
            </select>
          </div>
        </div>
        <div class="lcp-s-row">
          <div class="lcp-s-half lcp-s-group">
            <label>Couleur principale</label>
            <div class="lcp-s-color-row">
              <input type="color" id="s-color-picker" value="<?php echo esc_attr(get_option('lcp_widget_color','#6366f1')); ?>">
              <input type="text"  id="s-color-hex" class="lcp-s-input" style="width:100px;" value="<?php echo esc_attr(get_option('lcp_widget_color','#6366f1')); ?>">
              <input type="hidden" name="lcp_widget_color" id="s-color-val" value="<?php echo esc_attr(get_option('lcp_widget_color','#6366f1')); ?>">
            </div>
          </div>
          <div class="lcp-s-half lcp-s-group">
            <label>Icône</label>
            <div class="lcp-s-icons" id="s-icon-picker">
              <?php $ic=get_option('lcp_widget_icon','💬'); foreach(['💬','🗨️','💭','🤝','❓','📞','👋','🎯'] as $i): ?>
              <span class="lcp-s-icon <?php echo $ic===$i?'active':''; ?>" data-icon="<?php echo $i; ?>"><?php echo $i; ?></span>
              <?php endforeach; ?>
            </div>
            <input type="hidden" name="lcp_widget_icon" id="s-icon-val" value="<?php echo esc_attr($ic); ?>">
          </div>
        </div>
        <div class="lcp-s-group">
          <label>Texte du bouton</label>
          <input type="text" class="lcp-s-input" name="lcp_widget_text" id="s-widget-text" value="<?php echo esc_attr(get_option('lcp_widget_text','Besoin d\'aide ?')); ?>">
        </div>
        <div class="lcp-s-row">
          <div class="lcp-s-half lcp-s-group">
            <label>Largeur pop-up (px)</label>
            <input type="number" class="lcp-s-input" name="lcp_popup_width" value="<?php echo esc_attr(get_option('lcp_popup_width',380)); ?>" min="280" max="600">
          </div>
          <div class="lcp-s-half lcp-s-group">
            <label>Hauteur pop-up (px)</label>
            <input type="number" class="lcp-s-input" name="lcp_popup_height" value="<?php echo esc_attr(get_option('lcp_popup_height',500)); ?>" min="300" max="800">
          </div>
        </div>
        <div class="lcp-s-preview">
          <h4>Aperçu</h4>
          <div class="lcp-s-preview-widget">
            <div class="lcp-s-bubble" id="s-preview-bubble">
              <span id="s-preview-icon"><?php echo esc_html($ic); ?></span>
              <span id="s-preview-text"><?php echo esc_html(get_option('lcp_widget_text','Besoin d\'aide ?')); ?></span>
            </div>
          </div>
        </div>
      </div>

      <!-- MESSAGES -->
      <div class="lcp-s-section" id="sec-messages">
        <h2>💬 Messages</h2>
        <div class="lcp-s-group">
          <label>Message d'accueil (quand en ligne)</label>
          <textarea class="lcp-s-textarea" name="lcp_online_message"><?php echo esc_textarea(get_option('lcp_online_message','Bonjour ! Comment puis-je vous aider ?')); ?></textarea>
        </div>
        <div class="lcp-s-group">
          <label>Message hors ligne</label>
          <textarea class="lcp-s-textarea" name="lcp_offline_message"><?php echo esc_textarea(get_option('lcp_offline_message','Nous sommes absents. Laissez-nous un message !')); ?></textarea>
        </div>
      </div>

      <!-- FICHIERS -->
      <div class="lcp-s-section" id="sec-uploads">
        <h2>📎 Partage de fichiers</h2>
        <div class="lcp-s-group">
          <label class="lcp-s-toggle">
            <input type="checkbox" name="lcp_file_upload_enabled" value="1" <?php checked(get_option('lcp_file_upload_enabled','1'),'1'); ?>>
            Autoriser l'envoi de fichiers
          </label>
        </div>
        <div class="lcp-s-group">
          <label>Taille maximale (Mo)</label>
          <input type="number" class="lcp-s-input" name="lcp_max_file_size" value="<?php echo esc_attr(get_option('lcp_max_file_size',5)); ?>" min="1" max="20" style="width:100px;">
        </div>
        <div class="lcp-s-group">
          <label>Types autorisés <span style="font-weight:400;color:#94a3b8;">(séparés par des virgules)</span></label>
          <input type="text" class="lcp-s-input" name="lcp_allowed_file_types" value="<?php echo esc_attr(get_option('lcp_allowed_file_types','jpg,jpeg,png,gif,pdf,mp3,ogg,wav')); ?>">
        </div>
      </div>

      <!-- RGPD -->
      <div class="lcp-s-section" id="sec-rgpd">
        <h2>🔒 RGPD &amp; Confidentialité</h2>
        <div class="lcp-s-group">
          <label class="lcp-s-toggle">
            <input type="checkbox" name="lcp_rgpd_enabled" value="1" <?php checked(get_option('lcp_rgpd_enabled','1'),'1'); ?>>
            Afficher le modal de consentement avant le chat
          </label>
        </div>
        <div class="lcp-s-group">
          <label>Texte du consentement</label>
          <textarea class="lcp-s-textarea" name="lcp_rgpd_text"><?php echo esc_textarea(get_option('lcp_rgpd_text','En utilisant ce chat, vous acceptez notre politique de confidentialité.')); ?></textarea>
        </div>
        <div class="lcp-s-group">
          <label>Durée de conservation des données (jours)</label>
          <input type="number" class="lcp-s-input" name="lcp_rgpd_retention" value="<?php echo esc_attr(get_option('lcp_rgpd_retention',90)); ?>" min="7" max="365" style="width:120px;">
        </div>
      </div>

      <!-- HORAIRES -->
      <div class="lcp-s-section" id="sec-hours">
        <h2>🕐 Horaires d'ouverture</h2>
        <div class="lcp-s-group">
          <label class="lcp-s-toggle">
            <input type="checkbox" id="bh-enabled">
            Activer les horaires (sinon toujours en ligne)
          </label>
        </div>
        <div class="lcp-hours-grid" id="lcp-hours-grid"></div>
        <input type="hidden" name="lcp_business_hours" id="lcp-bh-val" value="<?php echo esc_attr(get_option('lcp_business_hours','{}')); ?>">
      </div>

      <!-- AVANCÉ -->
      <div class="lcp-s-section" id="sec-advanced">
        <h2>⚙️ Avancé</h2>
        <div class="lcp-s-group">
          <label>Domaine du site</label>
          <input type="url" class="lcp-s-input" name="lcp_site_domain" value="<?php echo esc_attr(get_option('lcp_site_domain',home_url())); ?>">
          <p class="hint">Utilisé pour la configuration CORS Pusher.</p>
        </div>
        <div class="lcp-s-group">
          <label>WooCommerce</label><br>
          <?php if(class_exists('WooCommerce')): ?>
            <span class="lcp-s-badge lcp-s-badge-ok">✓ WooCommerce actif</span>
          <?php else: ?>
            <span class="lcp-s-badge lcp-s-badge-warn">⚠ Non installé</span>
            <a href="<?php echo wp_nonce_url(add_query_arg(['action'=>'install-plugin','plugin'=>'woocommerce'],admin_url('update.php')),'install-plugin_woocommerce'); ?>" class="lcp-s-btn" style="margin-left:10px;">Installer WooCommerce</a>
          <?php endif; ?>
        </div>
        <div class="lcp-s-danger-zone">
          <h4>⚠️ Zone de danger</h4>
          <button type="button" class="lcp-s-btn lcp-s-btn-danger" id="btn-reset-settings">Réinitialiser tous les réglages</button>
        </div>
      </div>

    </div><!-- .lcp-s-content -->
  </div><!-- .lcp-s-layout -->
</div><!-- #lcp-settings-page -->

<script>
(function() {
  // ── Navigation onglets ────────────────────────────
  document.querySelectorAll('.lcp-s-navbtn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.lcp-s-navbtn').forEach(function(b) { b.classList.remove('active'); });
      document.querySelectorAll('.lcp-s-section').forEach(function(s) { s.style.display = 'none'; });
      btn.classList.add('active');
      var sec = document.getElementById('sec-' + btn.dataset.sec);
      if (sec) sec.style.display = 'block';
    });
  });
  // Initialiser : cacher toutes sauf la première
  document.querySelectorAll('.lcp-s-section').forEach(function(s) { s.style.display = 'none'; });
  var first = document.getElementById('sec-pusher');
  if (first) first.style.display = 'block';

  // ── Couleur ───────────────────────────────────────
  var picker = document.getElementById('s-color-picker');
  var hex    = document.getElementById('s-color-hex');
  var cval   = document.getElementById('s-color-val');
  var bubble = document.getElementById('s-preview-bubble');
  function syncColor(v) { if(picker) picker.value=v; if(hex) hex.value=v; if(cval) cval.value=v; if(bubble) bubble.style.background=v; }
  if (picker) picker.addEventListener('input', function() { syncColor(picker.value); });
  if (hex) hex.addEventListener('input', function() { if(/^#[0-9a-fA-F]{6}$/.test(hex.value)) syncColor(hex.value); });

  // ── Icône ─────────────────────────────────────────
  document.querySelectorAll('.lcp-s-icon').forEach(function(ic) {
    ic.addEventListener('click', function() {
      document.querySelectorAll('.lcp-s-icon').forEach(function(i){ i.classList.remove('active'); });
      ic.classList.add('active');
      var val = document.getElementById('s-icon-val');
      if (val) val.value = ic.dataset.icon;
      var prev = document.getElementById('s-preview-icon');
      if (prev) prev.textContent = ic.dataset.icon;
    });
  });

  // ── Texte preview ─────────────────────────────────
  var wtxt = document.querySelector('[name="lcp_widget_text"]');
  if (wtxt) wtxt.addEventListener('input', function() {
    var p = document.getElementById('s-preview-text');
    if (p) p.textContent = wtxt.value;
  });

  // ── Business hours ────────────────────────────────
  (function() {
    var grid  = document.getElementById('lcp-hours-grid');
    var valEl = document.getElementById('lcp-bh-val');
    var bhEn  = document.getElementById('bh-enabled');
    if (!grid) return;
    var days   = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
    var labels = {monday:'Lundi',tuesday:'Mardi',wednesday:'Mercredi',thursday:'Jeudi',friday:'Vendredi',saturday:'Samedi',sunday:'Dimanche'};
    var bh = {};
    try { bh = JSON.parse(valEl.value || '{}'); } catch(e) {}
    if (bhEn && bh.enabled) bhEn.checked = true;
    days.forEach(function(day) {
      var h = (bh.hours && bh.hours[day]) || {open:'09:00',close:'18:00',enabled:(day!=='saturday'&&day!=='sunday')};
      var row = document.createElement('div');
      row.className = 'lcp-hour-row';
      row.innerHTML = '<span class="lcp-hour-day">'+labels[day]+'</span>'
        +'<input type="checkbox" class="lcp-hour-toggle" data-day="'+day+'"'+(h.enabled?' checked':'')+'>'
        +'<div class="lcp-hour-times">'
        +'<input type="time" data-day="'+day+'" class="lcp-hour-open"  value="'+h.open+'">'
        +'<span>→</span>'
        +'<input type="time" data-day="'+day+'" class="lcp-hour-close" value="'+h.close+'">'
        +'</div>';
      grid.appendChild(row);
    });
    function syncBH() {
      var hours = {};
      days.forEach(function(day) {
        var tog   = grid.querySelector('input[data-day="'+day+'"]:not([type="time"])');
        var open  = grid.querySelector('.lcp-hour-open[data-day="'+day+'"]');
        var close = grid.querySelector('.lcp-hour-close[data-day="'+day+'"]');
        hours[day] = {enabled:tog?tog.checked:false, open:open?open.value:'09:00', close:close?close.value:'18:00'};
      });
      if (valEl) valEl.value = JSON.stringify({enabled:bhEn?bhEn.checked:false,timezone:'Africa/Casablanca',hours:hours});
    }
    grid.addEventListener('change', syncBH);
    if (bhEn) bhEn.addEventListener('change', syncBH);
  })();

  // ── Test Pusher ───────────────────────────────────
  document.getElementById('btn-test-pusher')?.addEventListener('click', function() {
    var result  = document.getElementById('pusher-test-result');
    var key     = document.querySelector('[name="lcp_pusher_key"]').value.trim();
    var appId   = document.querySelector('[name="lcp_pusher_app_id"]').value.trim();
    var cluster = document.querySelector('[name="lcp_pusher_cluster"]').value || 'eu';

    if (!key || !appId) {
      result.textContent = '⚠️ Saisissez App ID et Key d\'abord.';
      result.style.color = '#f59e0b'; return;
    }
    result.textContent = '⏳ Connexion en cours...';
    result.style.color = '#64748b';

    // Charger Pusher SDK si pas encore chargé
    function doTest() {
      try {
        var tp = new Pusher(key, { cluster: cluster });
        var done = false;
        var timer = setTimeout(function() {
          if (!done) {
            done = true;
            result.textContent = '❌ Timeout — vérifiez App ID, Key et Cluster.';
            result.style.color = '#ef4444';
            try { tp.disconnect(); } catch(e){}
          }
        }, 8000);
        tp.connection.bind('connected', function() {
          if (done) return; done = true;
          clearTimeout(timer);
          result.textContent = '✅ Pusher connecté ! Clés valides.';
          result.style.color = '#22c55e';
          setTimeout(function(){ tp.disconnect(); }, 1000);
        });
        tp.connection.bind('failed', function() {
          if (done) return; done = true;
          clearTimeout(timer);
          result.textContent = '❌ Connexion échouée — vérifiez vos clés.';
          result.style.color = '#ef4444';
        });
        tp.connection.bind('unavailable', function() {
          if (done) return; done = true;
          clearTimeout(timer);
          result.textContent = '⚠️ Pusher indisponible momentanément.';
          result.style.color = '#f59e0b';
        });
      } catch(e) {
        result.textContent = '❌ Erreur: ' + e.message;
        result.style.color = '#ef4444';
      }
    }

    if (window.Pusher) {
      doTest();
    } else {
      var s = document.createElement('script');
      s.src = 'https://js.pusher.com/8.3.0/pusher.min.js';
      s.onload = doTest;
      s.onerror = function() { result.textContent = '❌ Impossible de charger le SDK Pusher.'; result.style.color='#ef4444'; };
      document.head.appendChild(s);
    }
  });

  // ── Sauvegarde ────────────────────────────────────
  document.getElementById('lcp-save-btn').addEventListener('click', function() {
    var btn    = this;
    var notice = document.getElementById('lcp-s-notice');
    btn.textContent = '⏳ Sauvegarde...';
    btn.disabled = true;

    var form = new FormData();
    form.append('action', 'lcp_save_settings');
    form.append('nonce',  '<?php echo wp_create_nonce("lcp_ajax"); ?>');

    // Collecter tous les champs
    document.querySelectorAll('#lcp-settings-page input, #lcp-settings-page select, #lcp-settings-page textarea').forEach(function(el) {
      if (!el.name || el.name === '') return;
      if (el.type === 'checkbox') form.append(el.name, el.checked ? '1' : '0');
      else if (el.type === 'radio') { if (el.checked) form.append(el.name, el.value); }
      else form.append(el.name, el.value);
    });

    fetch('<?php echo admin_url("admin-ajax.php"); ?>', {method:'POST', body:form})
      .then(function(r){ return r.json(); })
      .then(function(d){
        notice.className = 'lcp-s-notice ' + (d.success ? 'success' : 'error');
        notice.textContent = d.success ? '✅ Réglages sauvegardés !' : ('❌ ' + (d.data || 'Erreur.'));
        notice.style.display = 'block';
        setTimeout(function(){ notice.style.display='none'; }, 4000);
      })
      .catch(function(){ notice.className='lcp-s-notice error'; notice.textContent='❌ Erreur réseau.'; notice.style.display='block'; })
      .finally(function(){ btn.textContent='💾 Sauvegarder'; btn.disabled=false; });
  });

  // ── Reset ─────────────────────────────────────────
  document.getElementById('btn-reset-settings')?.addEventListener('click', function() {
    if (confirm('Réinitialiser TOUS les réglages ? Cette action est irréversible.')) {
      var form = new FormData();
      form.append('action', 'lcp_reset_settings');
      form.append('nonce',  '<?php echo wp_create_nonce("lcp_ajax"); ?>');
      fetch('<?php echo admin_url("admin-ajax.php"); ?>', {method:'POST',body:form})
        .then(function(){ location.reload(); });
    }
  });

})();
</script>
