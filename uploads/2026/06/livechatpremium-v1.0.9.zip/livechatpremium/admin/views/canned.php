<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lcp-admin-wrap" id="lcp-canned-page">
  <div class="lcp-header">
    <div class="lcp-header-left"><h1>⚡ <?php _e('Réponses rapides', 'livechatpremium'); ?></h1></div>
    <div class="lcp-header-right">
      <button class="lcp-btn lcp-btn-primary" id="btn-new-canned">+ <?php _e('Nouvelle réponse', 'livechatpremium'); ?></button>
    </div>
  </div>
  <div id="lcp-canned-list" class="lcp-canned-admin-list">
    <div class="lcp-loading"><?php _e('Chargement...', 'livechatpremium'); ?></div>
  </div>

  <!-- Modal édition -->
  <div class="lcp-modal" id="modal-edit-canned" style="display:none;">
    <div class="lcp-modal-content lcp-modal-sm">
      <div class="lcp-modal-header">
        <h3><?php _e('Réponse rapide', 'livechatpremium'); ?></h3>
        <button class="lcp-modal-close">✕</button>
      </div>
      <div class="lcp-modal-body">
        <input type="hidden" id="canned-edit-id">
        <div class="lcp-field-group">
          <label><?php _e('Raccourci', 'livechatpremium'); ?></label>
          <input type="text" id="canned-shortcut" placeholder="/bonjour" class="lcp-input">
          <p class="lcp-hint"><?php _e('Tapez ce raccourci dans le chat pour l\'insérer automatiquement.', 'livechatpremium'); ?></p>
        </div>
        <div class="lcp-field-group">
          <label><?php _e('Titre', 'livechatpremium'); ?></label>
          <input type="text" id="canned-title" class="lcp-input" placeholder="<?php _e('Ex: Message de bienvenue', 'livechatpremium'); ?>">
        </div>
        <div class="lcp-field-group">
          <label><?php _e('Contenu du message', 'livechatpremium'); ?></label>
          <textarea id="canned-content" class="lcp-textarea" rows="4" placeholder="<?php _e('Bonjour ! Comment puis-je vous aider ?', 'livechatpremium'); ?>"></textarea>
        </div>
        <div class="lcp-field-group">
          <label><?php _e('Catégorie', 'livechatpremium'); ?></label>
          <input type="text" id="canned-category" placeholder="<?php _e('Ex: Accueil, Support, Ventes...', 'livechatpremium'); ?>" class="lcp-input">
        </div>
        <button class="lcp-btn lcp-btn-primary" id="btn-save-canned" style="width:100%;"><?php _e('💾 Sauvegarder', 'livechatpremium'); ?></button>
      </div>
    </div>
  </div>
  <div class="lcp-modal-overlay" id="canned-modal-overlay" style="display:none;"></div>
</div>
