=== LiveChatPremium ===
Contributors: livechatpremium
Tags: live chat, chat, support, woocommerce, pusher, ai
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Chat live professionnel avec visiteurs — temps réel Pusher, IA Groq, push WooCommerce, vocal, RGPD.

== Description ==

LiveChatPremium est un plugin de chat live complet pour WordPress.

= Fonctionnalités (Version Gratuite) =
* Chat live temps réel (Pusher Channels)
* Pop-up configurable (position, couleur, icône, texte)
* 1 agent
* Infos visiteur : pays, OS, navigateur
* Historique 30 jours
* RGPD : modal de consentement
* Mode hors ligne avec formulaire

= Fonctionnalités (Version Premium) =
* Agents illimités
* IA Groq : suggestions de réponses, bot automatique
* Traduction automatique (MyMemory)
* Push produits/pages WooCommerce
* Messages vocaux
* Envoi fichiers, images, PDF
* CRM contacts
* Historique illimité
* Statistiques avancées
* Notifications push (Pusher Beams)

== Installation ==

1. Téléchargez le plugin et décompressez dans /wp-content/plugins/livechatpremium/
2. Activez le plugin dans WordPress
3. Allez dans LiveChat → Réglages
4. Saisissez vos clés Pusher Channels (gratuit sur pusher.com)
5. (Optionnel) Saisissez votre clé Groq pour l'IA (gratuit sur console.groq.com)
6. Configurez l'apparence du widget
7. Sauvegardez et le widget apparaît sur votre site !

== Prérequis ==
* WordPress 6.0+
* PHP 7.4+
* MySQL 5.7+ ou MariaDB 10.3+
* Compte Pusher Channels gratuit (pusher.com)
* HTTPS recommandé (requis pour l'audio)

== Frequently Asked Questions ==

= Pourquoi Pusher ? =
Pusher fournit les WebSockets temps réel. Le plan gratuit inclut 200 connexions simultanées et 200 000 messages/jour — largement suffisant pour commencer.

= L'IA est-elle vraiment gratuite ? =
Oui. Groq offre un plan gratuit avec 6 000 requêtes/jour sur Llama 3.1 70B. Aucune carte bancaire requise.

= Fonctionne sur hébergement mutualisé ? =
Oui, c'est spécialement conçu pour ça.

== Changelog ==

= 1.0.0 =
* Version initiale

== Upgrade Notice ==

= 1.0.0 =
Première version stable.
