<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Rest_Api {

    const NAMESPACE = 'livechatpremium/v1';

    public static function register_routes() {

        // Visiteur
        register_rest_route( self::NAMESPACE, '/session/start',    ['methods'=>'POST',  'callback'=>[__CLASS__,'start_session'],       'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/session/consent',  ['methods'=>'POST',  'callback'=>[__CLASS__,'give_consent'],         'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/session/messages', ['methods'=>'GET',   'callback'=>[__CLASS__,'get_visitor_messages'], 'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/session/close',    ['methods'=>'POST',  'callback'=>[__CLASS__,'visitor_close'],        'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/message/send',     ['methods'=>'POST',  'callback'=>[__CLASS__,'visitor_send'],         'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/message/typing',   ['methods'=>'POST',  'callback'=>[__CLASS__,'typing'],               'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/upload',           ['methods'=>'POST',  'callback'=>[__CLASS__,'upload'],               'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/event/track',      ['methods'=>'POST',  'callback'=>[__CLASS__,'track_event'],          'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/pusher/auth',      ['methods'=>'POST',  'callback'=>[__CLASS__,'pusher_auth'],          'permission_callback'=>'__return_true'] );
        register_rest_route( self::NAMESPACE, '/rgpd/delete',      ['methods'=>'POST',  'callback'=>[__CLASS__,'delete_data'],          'permission_callback'=>'__return_true'] );

        // Admin
        register_rest_route( self::NAMESPACE, '/admin/sessions',                        ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_sessions'],    'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/session/(?P<token>[a-zA-Z0-9]+)', ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_session'],     'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/message/send',                    ['methods'=>'POST', 'callback'=>[__CLASS__,'admin_send'],         'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/push/page',                       ['methods'=>'POST', 'callback'=>[__CLASS__,'admin_push_page'],    'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/session/close',                   ['methods'=>'POST', 'callback'=>[__CLASS__,'admin_close'],        'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/session/assign',                  ['methods'=>'POST', 'callback'=>[__CLASS__,'admin_assign'],       'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/stats',                           ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_stats'],        'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/ai/suggest',                      ['methods'=>'POST', 'callback'=>[__CLASS__,'admin_ai_suggest'],   'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/woo/search',                      ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_woo_search'],   'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/pages/search',                    ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_pages_search'], 'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/canned',                          ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_canned'],       'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/contacts',                        ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_contacts'],     'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/sessions/all',                    ['methods'=>'GET',  'callback'=>[__CLASS__,'admin_sessions_all'], 'permission_callback'=>[__CLASS__,'is_agent']] );
        register_rest_route( self::NAMESPACE, '/admin/transcript/(?P<token>[a-zA-Z0-9]+)', ['methods'=>'GET', 'callback'=>[__CLASS__,'admin_transcript'], 'permission_callback'=>[__CLASS__,'is_agent']] );
    }

    public static function is_agent() {
        return current_user_can('edit_posts');
    }

    // ══════════════════════════════════════════════════
    // VISITEUR
    // ══════════════════════════════════════════════════

    public static function start_session( $request ) {
        $p = $request->get_json_params();

        $ip      = self::get_ip();
        $ip_hash = hash('sha256', $ip . wp_salt());
        $geo     = self::get_geo($ip);
        $ua      = sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' );
        $parsed  = self::parse_ua($ua);

        $visitor_id    = sanitize_text_field( $p['visitor_id']    ?? wp_generate_password(16,false) );
        $visitor_name  = sanitize_text_field( $p['visitor_name']  ?? '' );
        $visitor_phone = sanitize_text_field( $p['visitor_phone'] ?? '' );

        $token = LCP_Database::create_session([
            'visitor_id'    => $visitor_id,
            'visitor_name'  => $visitor_name,
            'visitor_phone' => $visitor_phone,
            'ip_address'    => get_option('lcp_rgpd_enabled') ? '' : $ip,
            'ip_hash'       => $ip_hash,
            'country'       => $geo['country'] ?? '',
            'city'          => $geo['city']    ?? '',
            'os'            => $parsed['os'],
            'browser'       => $parsed['browser'],
            'device'        => $parsed['device'],
            'page_url'      => esc_url_raw( $p['page_url']  ?? '' ),
            'referrer'      => esc_url_raw( $p['referrer']  ?? '' ),
            'user_agent'    => $ua,
            'status'        => 'waiting',
            'consent'       => 0,
        ]);

        $session = LCP_Database::get_session($token);

        // Notifier admin via Pusher
        LCP_Pusher::notify_new_visitor($session);

        // Créer ou mettre à jour contact CRM
        if ( $visitor_name || $visitor_phone ) {
            LCP_Database::upsert_contact([
                'visitor_id' => $visitor_id,
                'name'       => $visitor_name,
                'phone'      => $visitor_phone,
            ]);
        }

        return rest_ensure_response([
            'success'        => true,
            'session_token'  => $token,
            'visitor_id'     => $visitor_id,
            'pusher_key'     => get_option('lcp_pusher_key'),
            'pusher_cluster' => get_option('lcp_pusher_cluster','eu'),
            'channel'        => 'private-lcp-session-' . $token,
            'rgpd_required'  => (bool) get_option('lcp_rgpd_enabled'),
            'rgpd_text'      => get_option('lcp_rgpd_text'),
            'online_message' => get_option('lcp_online_message'),
            'is_online'      => LCP_Session::is_online(),
        ]);
    }

    public static function give_consent( $request ) {
        $p     = $request->get_json_params();
        $token = sanitize_text_field( $p['session_token'] ?? '' );
        if ( !$token ) return self::err('missing_token');
        LCP_Database::update_session($token, ['consent'=>1]);
        $s = LCP_Database::get_session($token);
        if ($s) LCP_Database::log_event($s->id,'consent_given',$s->page_url);
        return rest_ensure_response(['success'=>true]);
    }

    public static function visitor_send( $request ) {
        $p       = $request->get_json_params();
        $token   = sanitize_text_field( $p['session_token'] ?? '' );
        $content = sanitize_textarea_field( $p['content']  ?? '' );
        $type    = sanitize_key( $p['type']                ?? 'text' );

        if ( !$token ) return self::err('missing_token');
        $session = LCP_Database::get_session($token);
        if ( !$session ) return self::err('invalid_session');

        if ( $session->status === 'waiting' ) {
            LCP_Database::update_session($token, ['status'=>'active']);
        }

        $msg_id = LCP_Database::save_message([
            'session_id'  => $session->id,
            'sender_type' => 'visitor',
            'type'        => $type,
            'content'     => $content,
            'file_url'    => esc_url_raw( $p['file_url']  ?? '' ),
            'file_name'   => sanitize_text_field( $p['file_name'] ?? '' ),
        ]);

        $message = [
            'id'           => $msg_id,
            'session_id'   => $session->id,
            'session_token'=> $token,
            'sender_type'  => 'visitor',
            'sender_name'  => $session->visitor_name ?? 'Visiteur',
            'visitor_name' => $session->visitor_name ?? '',
            'visitor_phone'=> $session->visitor_phone ?? '',
            'type'         => $type,
            'content'      => $content,
            'file_url'     => $p['file_url']  ?? '',
            'file_name'    => $p['file_name'] ?? '',
            'sent_at'      => current_time('mysql'),
        ];

        // Pusher → admin
        LCP_Pusher::trigger(LCP_Pusher::admin_channel(), 'visitor-message', $message);

        // Bot IA si activé
        if ( get_option('lcp_bot_enabled') && !$session->agent_id && get_option('lcp_ai_enabled') && LCP_Groq::is_configured() ) {
            $history = LCP_Database::get_messages($session->id, 10);
            $reply   = LCP_Groq::bot_reply($content, (array)$history);
            if ($reply) {
                $bot_id = LCP_Database::save_message([
                    'session_id'  => $session->id,
                    'sender_type' => 'bot',
                    'type'        => 'text',
                    'content'     => $reply,
                ]);
                LCP_Pusher::send_message_to_visitor($token, [
                    'id'          => $bot_id,
                    'sender_type' => 'bot',
                    'sender_name' => get_option('lcp_bot_name','Assistant'),
                    'type'        => 'text',
                    'content'     => $reply,
                    'sent_at'     => current_time('mysql'),
                ]);
            }
        }

        // Analyse sentiment urgence
        if ( get_option('lcp_ai_enabled') && LCP_Groq::is_configured() && $content ) {
            $sentiment = LCP_Groq::analyze_sentiment($content);
            if ($sentiment === 'U') {
                LCP_Pusher::trigger(LCP_Pusher::admin_channel(), 'urgent-visitor', [
                    'session_token' => $token,
                    'message'       => $content,
                ]);
            }
        }

        return rest_ensure_response(['success'=>true,'message_id'=>$msg_id]);
    }

    public static function typing( $request ) {
        $p      = $request->get_json_params();
        $token  = sanitize_text_field( $p['session_token'] ?? '' );
        $sender = sanitize_text_field( $p['sender']        ?? 'visitor' );
        if ( !$token ) return self::err('missing_token');
        LCP_Pusher::typing($token, $sender);
        return rest_ensure_response(['success'=>true]);
    }

    public static function get_visitor_messages( $request ) {
        $token = sanitize_text_field( $request->get_param('session_token') );
        if ( !$token ) return self::err('missing_token');
        $session = LCP_Database::get_session($token);
        if ( !$session ) return self::err('invalid_session');
        $messages = LCP_Database::get_messages($session->id);
        LCP_Database::mark_read($session->id,'agent');
        return rest_ensure_response(['success'=>true,'messages'=>$messages]);
    }

    public static function visitor_close( $request ) {
        $p     = $request->get_json_params();
        $token = sanitize_text_field( $p['session_token'] ?? '' );
        if (!$token) return self::err('missing_token');
        LCP_Database::close_session($token);
        LCP_Pusher::trigger(LCP_Pusher::admin_channel(),'session-closed-by-visitor',['session_token'=>$token]);
        return rest_ensure_response(['success'=>true]);
    }

    public static function upload( $request ) {
        if ( !get_option('lcp_file_upload_enabled','1') ) return self::err('uploads_disabled');
        $token = sanitize_text_field( $request->get_param('session_token') );
        if ( !$token ) return self::err('missing_token');
        $session = LCP_Database::get_session($token);
        if ( !$session ) return self::err('invalid_session');
        return LCP_Upload::handle_upload($request);
    }

    public static function pusher_auth( $request ) {
        $socket_id    = sanitize_text_field( $request->get_param('socket_id') );
        $channel_name = sanitize_text_field( $request->get_param('channel_name') );
        if ( !$socket_id || !$channel_name ) return self::err('missing_params');

        // Canal session visiteur → vérifier token valide
        if ( strpos($channel_name,'private-lcp-session-') === 0 ) {
            $token   = str_replace('private-lcp-session-','',$channel_name);
            $session = LCP_Database::get_session($token);
            if ( !$session ) return new WP_REST_Response(['error'=>'Unauthorized'], 403);
            $auth = LCP_Pusher::authenticate($socket_id,$channel_name);
            if (!$auth) return new WP_REST_Response(['error'=>'Pusher not configured'], 500);
            return new WP_REST_Response(json_decode($auth,true), 200);
        }

        // Canal admin → doit être connecté WP
        if ( strpos($channel_name,'private-lcp-admin') === 0 || strpos($channel_name,'presence-lcp') === 0 ) {
            // On accepte aussi les requêtes avec nonce valide sans être connecté (pour les agents sur mobile)
            $nonce_valid = wp_verify_nonce( $request->get_header('X-WP-Nonce') ?? '', 'wp_rest' );
            if ( !$nonce_valid && !current_user_can('edit_posts') ) {
                return new WP_REST_Response(['error'=>'Unauthorized'], 403);
            }
            $user_data = null;
            if ( strpos($channel_name,'presence-') === 0 && is_user_logged_in() ) {
                $u = wp_get_current_user();
                $user_data = ['id'=>$u->ID,'info'=>['name'=>$u->display_name]];
            }
            $auth = LCP_Pusher::authenticate($socket_id,$channel_name,$user_data);
            if (!$auth) return new WP_REST_Response(['error'=>'Pusher not configured'], 500);
            return new WP_REST_Response(json_decode($auth,true), 200);
        }

        return new WP_REST_Response(['error'=>'Unauthorized'], 403);
    }

    public static function track_event( $request ) {
        $p    = $request->get_json_params();
        $token= sanitize_text_field( $p['session_token'] ?? '' );
        $type = sanitize_key( $p['type'] ?? '' );
        $url  = esc_url_raw( $p['page_url'] ?? '' );
        if (!$token || !$type) return self::err('missing_params');
        $session = LCP_Database::get_session($token);
        if (!$session) return self::err('invalid_session');
        LCP_Database::log_event($session->id,$type,$url,$p['payload']??[]);
        if ($type === 'page_view') {
            LCP_Database::update_session($token,['page_url'=>$url]);
            LCP_Pusher::trigger(LCP_Pusher::admin_channel(),'visitor-navigation',[
                'session_token' => $token,
                'page_url'      => $url,
                'page_title'    => sanitize_text_field($p['payload']['title']??''),
            ]);
        }
        return rest_ensure_response(['success'=>true]);
    }

    public static function delete_data( $request ) {
        $p  = $request->get_json_params();
        $vid= sanitize_text_field( $p['visitor_id'] ?? '' );
        if (!$vid) return self::err('missing_params');
        LCP_Database::delete_visitor_data($vid);
        return rest_ensure_response(['success'=>true]);
    }

    // ══════════════════════════════════════════════════
    // ADMIN
    // ══════════════════════════════════════════════════

    public static function admin_sessions( $request ) {
        $sessions = LCP_Database::get_active_sessions(100);
        return rest_ensure_response(['success'=>true,'sessions'=>$sessions]);
    }

    public static function admin_sessions_all( $request ) {
        $args = [
            'limit'  => (int)($request->get_param('limit')  ?? 20),
            'offset' => (int)($request->get_param('offset') ?? 0),
            'status' => sanitize_text_field($request->get_param('status') ?? ''),
            'search' => sanitize_text_field($request->get_param('q')      ?? ''),
        ];
        $sessions = LCP_Database::get_all_sessions($args);
        return rest_ensure_response(['success'=>true,'sessions'=>$sessions]);
    }

    public static function admin_session( $request ) {
        $token   = sanitize_text_field($request->get_param('token'));
        $session = LCP_Database::get_session($token);
        if (!$session) return self::err('not_found',404);
        $messages = LCP_Database::get_messages($session->id);
        LCP_Database::mark_read($session->id,'visitor');
        // Notifier visiteur que messages lus
        LCP_Pusher::trigger('private-lcp-session-'.$token,'messages-read',[]);
        return rest_ensure_response(['success'=>true,'session'=>$session,'messages'=>$messages]);
    }

    public static function admin_send( $request ) {
        $p       = $request->get_json_params();
        $token   = sanitize_text_field($p['session_token'] ?? '');
        $content = sanitize_textarea_field($p['content']   ?? '');
        $type    = sanitize_key($p['type']                 ?? 'text');
        if (!$token) return self::err('missing_token');
        $session = LCP_Database::get_session($token);
        if (!$session) return self::err('invalid_session');
        $user   = wp_get_current_user();
        $msg_id = LCP_Database::save_message([
            'session_id'  => $session->id,
            'sender_type' => 'agent',
            'sender_id'   => $user->ID,
            'type'        => $type,
            'content'     => $content,
            'file_url'    => esc_url_raw($p['file_url']  ?? ''),
            'file_name'   => sanitize_text_field($p['file_name'] ?? ''),
            'metadata'    => json_encode($p['metadata']  ?? []),
        ]);
        $msg = [
            'id'          => $msg_id,
            'sender_type' => 'agent',
            'sender_name' => $user->display_name,
            'avatar'      => get_avatar_url($user->ID,['size'=>32]),
            'type'        => $type,
            'content'     => $content,
            'file_url'    => $p['file_url']  ?? '',
            'file_name'   => $p['file_name'] ?? '',
            'metadata'    => $p['metadata']  ?? [],
            'sent_at'     => current_time('mysql'),
        ];
        LCP_Pusher::send_message_to_visitor($token,$msg);
        if ($session->status === 'waiting') {
            LCP_Database::update_session($token,['status'=>'active','agent_id'=>$user->ID]);
        }
        return rest_ensure_response(['success'=>true,'message_id'=>$msg_id]);
    }

    public static function admin_push_page( $request ) {
        $p     = $request->get_json_params();
        $token = sanitize_text_field($p['session_token'] ?? '');
        $url   = esc_url_raw($p['url']   ?? '');
        $title = sanitize_text_field($p['title'] ?? '');
        if (!$token || !$url) return self::err('missing_params');
        $session = LCP_Database::get_session($token);
        if ($session) {
            $user = wp_get_current_user();
            LCP_Database::save_message([
                'session_id'  => $session->id,
                'sender_type' => 'agent',
                'sender_id'   => $user->ID,
                'type'        => 'page',
                'content'     => $title ?: $url,
                'file_url'    => $url,
            ]);
        }
        LCP_Pusher::push_page($token,$url,$title);
        return rest_ensure_response(['success'=>true]);
    }

    public static function admin_close( $request ) {
        $p     = $request->get_json_params();
        $token = sanitize_text_field($p['session_token'] ?? '');
        if (!$token) return self::err('missing_token');
        LCP_Database::close_session($token);
        LCP_Pusher::close_session($token);
        return rest_ensure_response(['success'=>true]);
    }

    public static function admin_assign( $request ) {
        $p        = $request->get_json_params();
        $token    = sanitize_text_field($p['session_token'] ?? '');
        $agent_id = (int)($p['agent_id'] ?? get_current_user_id());
        if (!$token) return self::err('missing_token');
        LCP_Database::update_session($token,['agent_id'=>$agent_id,'status'=>'active']);
        return rest_ensure_response(['success'=>true]);
    }

    public static function admin_stats( $request ) {
        $period = (int)($request->get_param('period') ?? 30);
        return rest_ensure_response(['success'=>true,'stats'=>LCP_Database::get_stats($period)]);
    }

    public static function admin_ai_suggest( $request ) {
        $p     = $request->get_json_params();
        $token = sanitize_text_field($p['session_token'] ?? '');
        if (!$token) return self::err('missing_token');
        $session = LCP_Database::get_session($token);
        if (!$session) return self::err('invalid_session');
        $msgs = LCP_Database::get_messages($session->id,10);
        $sugg = LCP_Groq::suggest_replies((array)$msgs);
        return rest_ensure_response(['success'=>true,'suggestions'=>$sugg]);
    }

    public static function admin_woo_search( $request ) {
        if (!class_exists('WooCommerce')) return self::err('woo_not_installed');
        $q    = sanitize_text_field($request->get_param('q')    ?? '');
        $type = sanitize_text_field($request->get_param('type') ?? 'product');
        return rest_ensure_response(['success'=>true,'results'=>LCP_WooCommerce::search($q,$type)]);
    }

    public static function admin_pages_search( $request ) {
        $q    = sanitize_text_field($request->get_param('q')    ?? '');
        $type = sanitize_text_field($request->get_param('type') ?? 'page');
        $posts= get_posts(['s'=>$q,'post_type'=>in_array($type,['page','post','any'])?$type:'any','post_status'=>'publish','posts_per_page'=>10]);
        $results = array_map(fn($p)=>['id'=>$p->ID,'title'=>$p->post_title,'url'=>get_permalink($p->ID),'type'=>$p->post_type],$posts);
        return rest_ensure_response(['success'=>true,'results'=>$results]);
    }

    public static function admin_canned( $request ) {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}lcp_canned ORDER BY shortcut ASC");
        return rest_ensure_response(['success'=>true,'canned'=>$rows]);
    }

    public static function admin_contacts( $request ) {
        global $wpdb;
        $q     = sanitize_text_field($request->get_param('q') ?? '');
        $where = $q ? $wpdb->prepare('WHERE email LIKE %s OR name LIKE %s OR phone LIKE %s',"%$q%","%$q%","%$q%") : '';
        $rows  = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}lcp_contacts $where ORDER BY last_seen DESC LIMIT 100");
        return rest_ensure_response(['success'=>true,'contacts'=>$rows]);
    }

    public static function admin_transcript( $request ) {
        $token   = sanitize_text_field($request->get_param('token'));
        $session = LCP_Database::get_session($token);
        if (!$session) return self::err('not_found',404);
        $messages = LCP_Database::get_messages($session->id);
        $summary  = '';
        if (get_option('lcp_ai_enabled') && LCP_Groq::is_configured() && count((array)$messages)>2) {
            $summary = LCP_Groq::summarize_conversation((array)$messages);
        }
        return rest_ensure_response(['success'=>true,'session'=>$session,'messages'=>$messages,'summary'=>$summary]);
    }

    // ══════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════

    private static function err($code,$status=400) {
        $msgs = [
            'missing_token'   => 'Token manquant.',
            'missing_params'  => 'Paramètres manquants.',
            'invalid_session' => 'Session invalide.',
            'unauthorized'    => 'Non autorisé.',
            'not_found'       => 'Introuvable.',
            'uploads_disabled'=> 'Uploads désactivés.',
            'woo_not_installed'=>'WooCommerce non installé.',
        ];
        return new WP_Error($code,$msgs[$code]??$code,['status'=>$status]);
    }

    private static function get_ip() {
        foreach(['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) {
                $ip = trim(explode(',',$_SERVER[$k])[0]);
                if (filter_var($ip,FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '0.0.0.0';
    }

    private static function get_geo($ip) {
        if ($ip==='127.0.0.1'||$ip==='0.0.0.0') return ['country'=>'Local','city'=>''];
        $r = wp_remote_get("http://ip-api.com/json/{$ip}?fields=country,city,countryCode",['timeout'=>3]);
        if (is_wp_error($r)) return [];
        $d = json_decode(wp_remote_retrieve_body($r),true);
        return $d ?: [];
    }

    private static function parse_ua($ua) {
        $os='Unknown';$browser='Unknown';$device='desktop';
        if     (preg_match('/Windows NT/i',$ua))  $os='Windows';
        elseif (preg_match('/Mac OS X/i',$ua))    $os='macOS';
        elseif (preg_match('/Android/i',$ua))     $os='Android';
        elseif (preg_match('/iPhone|iPad/i',$ua)) $os='iOS';
        elseif (preg_match('/Linux/i',$ua))       $os='Linux';
        if     (preg_match('/Edg\//i',$ua))       $browser='Edge';
        elseif (preg_match('/OPR|Opera/i',$ua))   $browser='Opera';
        elseif (preg_match('/Chrome/i',$ua))      $browser='Chrome';
        elseif (preg_match('/Firefox/i',$ua))     $browser='Firefox';
        elseif (preg_match('/Safari/i',$ua))      $browser='Safari';
        if (preg_match('/Mobile|Android|iPhone/i',$ua)) $device='mobile';
        elseif (preg_match('/Tablet|iPad/i',$ua))       $device='tablet';
        return compact('os','browser','device');
    }
}
