<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Groq {

    const API_URL = 'https://api.groq.com/openai/v1/chat/completions';

    /**
     * Requête générique à l'API Groq
     */
    private static function request( $messages, $max_tokens = 300 ) {
        $api_key = get_option('lcp_groq_api_key');
        $model   = get_option('lcp_groq_model', 'llama-3.1-70b-versatile');

        if ( empty($api_key) ) return null;

        $response = wp_remote_post( self::API_URL, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ],
            'body' => json_encode([
                'model'       => $model,
                'messages'    => $messages,
                'max_tokens'  => $max_tokens,
                'temperature' => 0.7,
            ]),
        ]);

        if ( is_wp_error($response) ) {
            error_log( 'LCP Groq error: ' . $response->get_error_message() );
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body($response), true );
        return $body['choices'][0]['message']['content'] ?? null;
    }

    /**
     * Suggérer 3 réponses pour l'agent
     */
    public static function suggest_replies( $conversation_history, $site_context = '' ) {
        $site_name = get_bloginfo('name');
        $system = "Tu es un assistant pour l'équipe du site \"{$site_name}\". {$site_context}
Analyse la conversation et propose exactement 3 courtes réponses possibles pour l'agent.
Réponds UNIQUEMENT avec un JSON : {\"suggestions\": [\"réponse1\", \"réponse2\", \"réponse3\"]}
Réponses courtes, naturelles, professionnelles, en français.";

        $messages = [
            ['role' => 'system', 'content' => $system],
        ];

        foreach ( $conversation_history as $msg ) {
            $role = $msg['sender_type'] === 'visitor' ? 'user' : 'assistant';
            $messages[] = ['role' => $role, 'content' => $msg['content']];
        }

        $result = self::request( $messages, 200 );
        if ( ! $result ) return [];

        // Extraire JSON même si entouré de texte
        preg_match('/\{.*\}/s', $result, $matches);
        if ( empty($matches[0]) ) return [];

        $data = json_decode( $matches[0], true );
        return $data['suggestions'] ?? [];
    }

    /**
     * Analyser le sentiment d'un message
     */
    public static function analyze_sentiment( $message ) {
        $messages = [
            ['role' => 'system', 'content' => 'Analyse le sentiment de ce message client en une seule lettre : P (positif), N (négatif), U (urgent/frustré), O (neutre). Réponds UNIQUEMENT avec la lettre.'],
            ['role' => 'user', 'content' => $message],
        ];

        $result = self::request( $messages, 5 );
        $result = trim( strtoupper($result ?? 'O') );

        return in_array($result, ['P','N','U','O']) ? $result : 'O';
    }

    /**
     * Réponse bot automatique
     */
    public static function bot_reply( $visitor_message, $conversation_history = [], $faq_context = '' ) {
        $site_name = get_bloginfo('name');
        $site_desc = get_bloginfo('description');

        $system = "Tu es l'assistant virtuel du site \"{$site_name}\" ({$site_desc}).
{$faq_context}
Réponds de façon concise, utile et professionnelle en français.
Si tu ne sais pas, dis que tu vas transférer à un agent humain.
Ne mentionne jamais que tu es une IA sauf si on te le demande directement.";

        $messages = [['role' => 'system', 'content' => $system]];

        foreach ( array_slice($conversation_history, -6) as $msg ) {
            $role = $msg['sender_type'] === 'visitor' ? 'user' : 'assistant';
            $messages[] = ['role' => $role, 'content' => $msg['content']];
        }

        $messages[] = ['role' => 'user', 'content' => $visitor_message];

        return self::request( $messages, 400 );
    }

    /**
     * Générer un résumé de conversation pour l'agent
     */
    public static function summarize_conversation( $messages ) {
        $transcript = '';
        foreach ( $messages as $msg ) {
            $who = $msg['sender_type'] === 'visitor' ? 'Visiteur' : 'Agent';
            $transcript .= "{$who}: {$msg['content']}\n";
        }

        $prompt = [
            ['role' => 'system', 'content' => 'Résume cette conversation support en 2-3 phrases : problème principal, statut, action requise. En français, concis.'],
            ['role' => 'user', 'content' => $transcript],
        ];

        return self::request( $prompt, 150 );
    }

    /**
     * Détecter l'intention d'achat
     */
    public static function detect_purchase_intent( $message ) {
        $prompt = [
            ['role' => 'system', 'content' => 'Ce message montre-t-il une intention d\'achat ou d\'intérêt commercial ? Réponds 1 (oui) ou 0 (non) uniquement.'],
            ['role' => 'user', 'content' => $message],
        ];
        $result = trim( self::request($prompt, 3) ?? '0' );
        return $result === '1';
    }

    public static function is_configured() {
        return ! empty( get_option('lcp_groq_api_key') );
    }
}
