<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * LCP_Settings — Helper accès aux options
 * Toutes les options sont gérées via get_option/update_option WordPress.
 * Cette classe fournit des raccourcis typés.
 */
class LCP_Settings {

    public static function get( $key, $default = '' ) {
        return get_option( $key, $default );
    }

    public static function set( $key, $value ) {
        return update_option( $key, $value );
    }

    public static function is_premium() {
        return get_option('lcp_license_status') === 'premium';
    }

    public static function pusher_configured() {
        return ! empty(get_option('lcp_pusher_app_id'))
            && ! empty(get_option('lcp_pusher_key'))
            && ! empty(get_option('lcp_pusher_secret'));
    }

    public static function groq_configured() {
        return ! empty(get_option('lcp_groq_api_key'));
    }

    public static function get_all() {
        $keys = [
            'lcp_pusher_app_id','lcp_pusher_key','lcp_pusher_cluster','lcp_pusher_beams_id',
            'lcp_groq_api_key','lcp_groq_model','lcp_site_domain',
            'lcp_widget_position','lcp_widget_color','lcp_widget_icon','lcp_widget_text',
            'lcp_widget_size','lcp_popup_height','lcp_popup_width',
            'lcp_online_message','lcp_offline_message',
            'lcp_rgpd_enabled','lcp_rgpd_text','lcp_rgpd_retention',
            'lcp_ai_enabled','lcp_translation_enabled','lcp_bot_enabled','lcp_bot_name',
            'lcp_file_upload_enabled','lcp_max_file_size','lcp_allowed_file_types',
            'lcp_license_key','lcp_license_status','lcp_business_hours',
        ];
        $result = [];
        foreach ($keys as $k) $result[$k] = get_option($k, '');
        return $result;
    }
}
