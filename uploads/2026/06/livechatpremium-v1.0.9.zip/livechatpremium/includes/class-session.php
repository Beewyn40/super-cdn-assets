<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Session {

    public static function get_or_create( $visitor_id, $page_url = '' ) {
        global $wpdb;
        // Chercher session active récente (< 30 min)
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}lcp_sessions
             WHERE visitor_id = %s AND status IN ('waiting','active')
             AND updated_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
             ORDER BY updated_at DESC LIMIT 1",
            $visitor_id
        ));
        if ( $existing ) return $existing->session_token;
        return null;
    }

    public static function get_widget_config() {
        return [
            'position'         => get_option('lcp_widget_position', 'bottom-right'),
            'color'            => get_option('lcp_widget_color', '#6366f1'),
            'icon'             => get_option('lcp_widget_icon', 'chat'),
            'text'             => get_option('lcp_widget_text', 'Besoin d\'aide ?'),
            'size'             => get_option('lcp_widget_size', 'medium'),
            'popup_height'     => (int) get_option('lcp_popup_height', 500),
            'popup_width'      => (int) get_option('lcp_popup_width', 380),
            'online_message'   => get_option('lcp_online_message', 'Bonjour ! Comment puis-je vous aider ?'),
            'offline_message'  => get_option('lcp_offline_message', 'Nous sommes absents. Laissez-nous un message !'),
            'rgpd_enabled'     => (bool) get_option('lcp_rgpd_enabled', 1),
            'rgpd_text'        => LCP_Rgpd::get_consent_text(),
            'file_upload'      => (bool) get_option('lcp_file_upload_enabled', 1),
            'allowed_types'    => get_option('lcp_allowed_file_types', 'jpg,jpeg,png,gif,pdf,mp3,ogg,wav'),
            'max_file_size'    => (int) get_option('lcp_max_file_size', 5),
            'translation'      => (bool) get_option('lcp_translation_enabled', 0),
            'pusher_key'       => get_option('lcp_pusher_key', ''),
            'pusher_cluster'   => get_option('lcp_pusher_cluster', 'eu'),
            'rest_url'         => rest_url('livechatpremium/v1'),
            'nonce'            => wp_create_nonce('wp_rest'),
            'ajax_url'         => admin_url('admin-ajax.php'),
            'is_online'        => self::is_online(),
            'bot_enabled'      => (bool) get_option('lcp_bot_enabled', 0),
            'bot_name'         => get_option('lcp_bot_name', 'Assistant'),
            'visitor_name'     => '',
            'visitor_phone'    => '',
        ];
    }

    public static function is_online() {
        $bh = json_decode(get_option('lcp_business_hours', '{}'), true);
        if ( empty($bh['enabled']) ) return true;

        $tz   = $bh['timezone'] ?? 'UTC';
        $now  = new DateTime('now', new DateTimeZone($tz));
        $day  = strtolower($now->format('l'));
        $time = $now->format('H:i');
        $h    = $bh['hours'][$day] ?? null;

        if ( ! $h || empty($h['enabled']) ) return false;
        return $time >= $h['open'] && $time <= $h['close'];
    }
}


