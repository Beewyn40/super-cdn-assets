<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Core {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
    }

    private function init() {
        // Internationalisation
        add_action( 'init', [$this, 'load_textdomain'] );

        // REST API
        add_action( 'rest_api_init', ['LCP_Rest_Api', 'register_routes'] );

        // Admin
        if ( is_admin() ) {
            new LCP_Admin();
        }

        // Front
        new LCP_Frontend();

        // RGPD
        new LCP_Rgpd();


        // Nettoyage automatique
        add_action( 'lcp_daily_cleanup', ['LCP_Database', 'cleanup_old_data'] );
        if ( ! wp_next_scheduled( 'lcp_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'lcp_daily_cleanup' );
        }

        // Mise à jour DB si nécessaire
        if ( get_option('lcp_db_version') !== LCP_DB_VERSION ) {
            LCP_Installer::create_tables();
            LCP_Installer::migrate();
            update_option( 'lcp_db_version', LCP_DB_VERSION );
        }
    }

    public function load_textdomain() {
        load_plugin_textdomain(
            'livechatpremium',
            false,
            dirname( plugin_basename( LCP_PLUGIN_FILE ) ) . '/languages/'
        );
    }

    public static function is_premium() {
        return get_option('lcp_license_status') === 'premium';
    }

    public static function get_setting( $key, $default = '' ) {
        return get_option( $key, $default );
    }
}
