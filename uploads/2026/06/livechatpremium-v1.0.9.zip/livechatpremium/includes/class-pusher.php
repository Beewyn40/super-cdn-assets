<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Pusher {

    private static $pusher = null;

    public static function get_instance() {
        if ( self::$pusher !== null ) return self::$pusher;

        $app_id  = get_option('lcp_pusher_app_id');
        $key     = get_option('lcp_pusher_key');
        $secret  = get_option('lcp_pusher_secret');
        $cluster = get_option('lcp_pusher_cluster', 'eu');

        if ( ! $app_id || ! $key || ! $secret ) return null;

        // Pusher PHP SDK via include manuel (pas Composer sur mutualisé)
        require_once LCP_PLUGIN_DIR . 'includes/pusher-php/autoload.php';

        self::$pusher = new Pusher\Pusher( $key, $secret, $app_id, [
            'cluster'   => $cluster,
            'useTLS'    => true,
        ]);

        return self::$pusher;
    }

    /**
     * Envoyer un message à un canal de session
     */
    public static function trigger( $channel, $event, $data ) {
        $pusher = self::get_instance();
        if ( ! $pusher ) return false;

        try {
            $pusher->trigger( $channel, $event, $data );
            return true;
        } catch ( Exception $e ) {
            error_log( 'LCP Pusher error: ' . $e->getMessage() );
            return false;
        }
    }

    /**
     * Canal privé pour une session
     */
    public static function session_channel( $session_token ) {
        return 'private-lcp-session-' . $session_token;
    }

    /**
     * Canal admin (tous les agents)
     */
    public static function admin_channel() {
        return 'lcp-admin';
    }

    /**
     * Canal présence (liste des agents en ligne)
     */
    public static function presence_channel() {
        return 'presence-lcp-agents';
    }

    /**
     * Authentification canal privé/présence
     */
    public static function authenticate( $socket_id, $channel_name, $user_data = null ) {
        $pusher = self::get_instance();
        if ( ! $pusher ) return false;

        if ( $user_data ) {
            return $pusher->authorizePresenceChannel( $channel_name, $socket_id, $user_data );
        }
        return $pusher->authorizeChannel( $channel_name, $socket_id );
    }

    /**
     * Notifier l'admin d'un nouveau visiteur
     */
    public static function notify_new_visitor( $session ) {
        return self::trigger( self::admin_channel(), 'new-visitor', [
            'session_id'    => $session->id,
            'session_token' => $session->session_token,
            'visitor_id'    => $session->visitor_id,
            'country'       => $session->country,
            'city'          => $session->city,
            'os'            => $session->os,
            'browser'       => $session->browser,
            'device'        => $session->device,
            'page_url'      => $session->page_url,
            'score'         => $session->score,
            'started_at'    => $session->started_at,
            'visitor_name'  => $session->visitor_name  ?? '',
            'visitor_phone' => $session->visitor_phone ?? '',
        ]);
    }

    /**
     * Envoyer un message à un visiteur
     */
    public static function send_message_to_visitor( $session_token, $message ) {
        return self::trigger(
            self::session_channel( $session_token ),
            'new-message',
            $message
        );
    }

    /**
     * Envoyer un message à l'admin
     */
    public static function send_message_to_admin( $session_token, $message ) {
        return self::trigger(
            self::admin_channel(),
            'visitor-message',
            array_merge( $message, ['session_token' => $session_token] )
        );
    }

    /**
     * Pousser une page sur le navigateur visiteur
     */
    public static function push_page( $session_token, $url, $title = '' ) {
        return self::trigger(
            self::session_channel( $session_token ),
            'push-page',
            ['url' => $url, 'title' => $title]
        );
    }

    /**
     * Notifier typing
     */
    public static function typing( $session_token, $sender ) {
        return self::trigger(
            self::session_channel( $session_token ),
            'typing',
            ['sender' => $sender]
        );
    }

    /**
     * Notifier fermeture de session
     */
    public static function close_session( $session_token ) {
        return self::trigger(
            self::session_channel( $session_token ),
            'session-closed',
            ['message' => __('La conversation a été fermée.', 'livechatpremium')]
        );
    }

    /**
     * Vérifier si Pusher est configuré
     */
    public static function is_configured() {
        return ! empty( get_option('lcp_pusher_app_id') )
            && ! empty( get_option('lcp_pusher_key') )
            && ! empty( get_option('lcp_pusher_secret') );
    }
}
