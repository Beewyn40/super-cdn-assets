<?php
namespace Pusher;

class Pusher {
    private $app_key, $app_secret, $app_id, $options, $api_host;

    public function __construct($app_key, $app_secret, $app_id, $options = []) {
        $this->app_key    = $app_key;
        $this->app_secret = $app_secret;
        $this->app_id     = $app_id;
        $this->options    = array_merge(['cluster'=>'eu','useTLS'=>true,'timeout'=>10], $options);
        $scheme           = $this->options['useTLS'] ? 'https' : 'http';
        $this->api_host   = "{$scheme}://api-{$this->options['cluster']}.pusher.com";
    }

    public function trigger($channels, $event, $data, $params = []) {
        if (is_string($channels)) $channels = [$channels];
        $body = json_encode(['name'=>$event,'channels'=>$channels,'data'=>is_string($data)?$data:json_encode($data)]);
        $path = "/apps/{$this->app_id}/events";
        $url  = $this->api_host . $path . '?' . $this->buildAuthQuery('POST', $path, $body);
        return $this->httpPost($url, $body);
    }

    public function authorizeChannel($channel_name, $socket_id) {
        return json_encode(['auth' => $this->app_key . ':' . $this->sign($socket_id . ':' . $channel_name)]);
    }

    public function authorizePresenceChannel($channel_name, $socket_id, $user_data) {
        $ud  = json_encode($user_data);
        $sig = $this->app_key . ':' . $this->sign($socket_id . ':' . $channel_name . ':' . $ud);
        return json_encode(['auth' => $sig, 'channel_data' => $ud]);
    }

    private function buildAuthQuery($method, $path, $body) {
        $params = ['auth_key'=>$this->app_key,'auth_timestamp'=>time(),'auth_version'=>'1.0','body_md5'=>md5($body)];
        ksort($params);
        $sts = implode("\n", [$method, $path, http_build_query($params)]);
        $params['auth_signature'] = $this->sign($sts);
        return http_build_query($params);
    }

    private function sign($s) { return hash_hmac('sha256', $s, $this->app_secret); }

    private function httpPost($url, $body) {
        if (function_exists('wp_remote_post')) {
            $r = wp_remote_post($url, ['body'=>$body,'headers'=>['Content-Type'=>'application/json'],'timeout'=>$this->options['timeout']]);
            return is_wp_error($r) ? false : wp_remote_retrieve_body($r);
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$this->options['timeout'],CURLOPT_HTTPHEADER=>['Content-Type: application/json']]);
        $r = curl_exec($ch); curl_close($ch); return $r;
    }
}
