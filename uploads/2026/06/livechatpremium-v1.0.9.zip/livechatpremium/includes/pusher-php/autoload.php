<?php
// Autoloader Pusher PHP standalone — sans Composer
spl_autoload_register(function($class) {
    $prefix = 'Pusher\\';
    if (strpos($class, $prefix) !== 0) return;
    $file = __DIR__ . '/src/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) require_once $file;
});
