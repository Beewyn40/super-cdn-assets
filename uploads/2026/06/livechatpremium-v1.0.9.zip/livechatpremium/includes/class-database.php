<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Database {

    // ═══════════════════════════════════════
    // SESSIONS
    // ═══════════════════════════════════════

    public static function create_session( $data ) {
        global $wpdb;
        $token = wp_generate_password(32, false);
        $wpdb->insert( $wpdb->prefix . 'lcp_sessions', array_merge([
            'session_token' => $token,
            'started_at'    => current_time('mysql'),
            'updated_at'    => current_time('mysql'),
        ], $data));
        return $token;
    }

    public static function get_session( $token ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}lcp_sessions WHERE session_token = %s LIMIT 1",
            $token
        ));
    }

    public static function get_session_by_id( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}lcp_sessions WHERE id = %d LIMIT 1",
            $id
        ));
    }

    public static function update_session( $token, $data ) {
        global $wpdb;
        return $wpdb->update(
            $wpdb->prefix . 'lcp_sessions',
            array_merge($data, ['updated_at' => current_time('mysql')]),
            ['session_token' => $token]
        );
    }

    public static function close_session( $token ) {
        return self::update_session($token, [
            'status'    => 'closed',
            'closed_at' => current_time('mysql'),
        ]);
    }

    public static function get_active_sessions( $limit = 100 ) {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT s.id, s.session_token, s.visitor_id, s.visitor_name, s.visitor_phone,
             s.ip_hash, s.country, s.city, s.os, s.browser, s.device, s.page_url,
             s.status, s.score, s.agent_id, s.started_at, s.updated_at,
             (SELECT COUNT(*) FROM {$wpdb->prefix}lcp_messages m WHERE m.session_id = s.id) as msg_count,
             (SELECT COUNT(*) FROM {$wpdb->prefix}lcp_messages m WHERE m.session_id = s.id AND m.is_read = 0 AND m.sender_type = 'visitor') as unread_count
             FROM {$wpdb->prefix}lcp_sessions s
             WHERE s.status IN ('waiting','active')
             ORDER BY s.updated_at DESC
             LIMIT {$limit}"
        );
    }

    public static function get_all_sessions( $args = [] ) {
        global $wpdb;
        $defaults = ['limit'=>50, 'offset'=>0, 'status'=>'', 'search'=>''];
        $args = wp_parse_args($args, $defaults);

        $where = '1=1';
        if ( $args['status'] ) $where .= $wpdb->prepare(' AND s.status = %s', $args['status']);
        if ( $args['search'] ) {
            $like = '%' . $wpdb->esc_like($args['search']) . '%';
            $where .= $wpdb->prepare(' AND (s.country LIKE %s OR s.browser LIKE %s OR s.visitor_id LIKE %s)', $like, $like, $like);
        }

        // Vérifier si colonnes visitor_name/phone existent
        $cols = $wpdb->get_col("SHOW COLUMNS FROM {$wpdb->prefix}lcp_sessions");
        $has_name  = in_array('visitor_name',  $cols);
        $has_phone = in_array('visitor_phone', $cols);
        $extra = '';
        if ($has_name)  $extra .= ', s.visitor_name';
        if ($has_phone) $extra .= ', s.visitor_phone';

        $sql = $wpdb->prepare(
            "SELECT s.id, s.session_token, s.visitor_id{$extra},
             s.ip_hash, s.country, s.city, s.os, s.browser, s.device,
             s.page_url, s.status, s.agent_id, s.started_at, s.updated_at, s.closed_at,
             (SELECT COUNT(*) FROM {$wpdb->prefix}lcp_messages m WHERE m.session_id = s.id) as msg_count
             FROM {$wpdb->prefix}lcp_sessions s
             WHERE {$where}
             ORDER BY s.started_at DESC
             LIMIT %d OFFSET %d",
            $args['limit'], $args['offset']
        );

        return $wpdb->get_results($sql) ?: [];
    }

    // ═══════════════════════════════════════
    // MESSAGES
    // ═══════════════════════════════════════

    public static function save_message( $data ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'lcp_messages', array_merge([
            'sent_at' => current_time('mysql'),
        ], $data));
        return $wpdb->insert_id;
    }

    public static function get_messages( $session_id, $limit = 100, $before_id = 0 ) {
        global $wpdb;
        $where = $wpdb->prepare('session_id = %d', $session_id);
        if ( $before_id ) $where .= $wpdb->prepare(' AND id < %d', $before_id);

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}lcp_messages WHERE {$where} ORDER BY sent_at ASC LIMIT %d",
            $limit
        ));
    }

    public static function mark_read( $session_id, $sender_type = 'visitor' ) {
        global $wpdb;
        return $wpdb->update(
            $wpdb->prefix . 'lcp_messages',
            ['is_read' => 1, 'read_at' => current_time('mysql')],
            ['session_id' => $session_id, 'sender_type' => $sender_type, 'is_read' => 0]
        );
    }

    public static function get_unread_count( $agent_id = 0 ) {
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}lcp_messages m
             INNER JOIN {$wpdb->prefix}lcp_sessions s ON s.id = m.session_id
             WHERE m.sender_type = 'visitor' AND m.is_read = 0 AND s.status = 'active'"
        );
    }

    // ═══════════════════════════════════════
    // CONTACTS
    // ═══════════════════════════════════════

    public static function upsert_contact( $data ) {
        global $wpdb;
        $existing = null;
        if ( ! empty($data['email']) ) {
            $existing = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}lcp_contacts WHERE email = %s LIMIT 1",
                $data['email']
            ));
        } elseif ( ! empty($data['visitor_id']) ) {
            $existing = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}lcp_contacts WHERE visitor_id = %s LIMIT 1",
                $data['visitor_id']
            ));
        }

        if ( $existing ) {
            $wpdb->update( $wpdb->prefix . 'lcp_contacts',
                array_merge($data, [
                    'total_sessions' => $existing->total_sessions + 1,
                    'last_seen'      => current_time('mysql'),
                ]),
                ['id' => $existing->id]
            );
            return $existing->id;
        }

        $wpdb->insert( $wpdb->prefix . 'lcp_contacts', array_merge([
            'total_sessions' => 1,
            'last_seen'      => current_time('mysql'),
            'created_at'     => current_time('mysql'),
        ], $data));
        return $wpdb->insert_id;
    }

    // ═══════════════════════════════════════
    // EVENTS
    // ═══════════════════════════════════════

    public static function log_event( $session_id, $type, $page_url = '', $payload = [] ) {
        global $wpdb;
        return $wpdb->insert( $wpdb->prefix . 'lcp_events', [
            'session_id' => $session_id,
            'type'       => $type,
            'page_url'   => $page_url,
            'payload'    => json_encode($payload),
            'created_at' => current_time('mysql'),
        ]);
    }

    // ═══════════════════════════════════════
    // STATS
    // ═══════════════════════════════════════

    public static function get_stats( $period = 30 ) {
        global $wpdb;
        $date = date('Y-m-d H:i:s', strtotime("-{$period} days"));

        return [
            'total_sessions'  => (int) $wpdb->get_var( $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}lcp_sessions WHERE started_at >= %s", $date) ),
            'active_sessions' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}lcp_sessions WHERE status IN ('waiting','active')"),
            'total_messages'  => (int) $wpdb->get_var( $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}lcp_messages WHERE sent_at >= %s", $date) ),
            'missed_sessions' => (int) $wpdb->get_var( $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}lcp_sessions WHERE status = 'missed' AND started_at >= %s", $date) ),
            'total_contacts'  => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}lcp_contacts"),
            'avg_response'    => self::get_avg_response_time($date),
        ];
    }

    private static function get_avg_response_time( $since ) {
        global $wpdb;
        $result = $wpdb->get_var( $wpdb->prepare(
            "SELECT AVG(TIMESTAMPDIFF(SECOND, 
                (SELECT MIN(sent_at) FROM {$wpdb->prefix}lcp_messages WHERE session_id = s.id AND sender_type = 'visitor'),
                (SELECT MIN(sent_at) FROM {$wpdb->prefix}lcp_messages WHERE session_id = s.id AND sender_type = 'agent')
             ))
             FROM {$wpdb->prefix}lcp_sessions s WHERE s.started_at >= %s AND s.status = 'closed'",
            $since
        ));
        return round( (float)$result );
    }

    // ═══════════════════════════════════════
    // NETTOYAGE RGPD
    // ═══════════════════════════════════════

    public static function cleanup_old_data() {
        global $wpdb;
        $days = (int) get_option('lcp_rgpd_retention', 90);
        $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));

        // Supprimer les messages des sessions expirées
        $wpdb->query( $wpdb->prepare(
            "DELETE m FROM {$wpdb->prefix}lcp_messages m
             INNER JOIN {$wpdb->prefix}lcp_sessions s ON s.id = m.session_id
             WHERE s.started_at < %s",
            $date
        ));

        // Supprimer les sessions expirées
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}lcp_sessions WHERE started_at < %s",
            $date
        ));

        // Supprimer les événements expirés
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}lcp_events WHERE created_at < %s",
            $date
        ));
    }

    public static function delete_visitor_data( $visitor_id ) {
        global $wpdb;
        $sessions = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}lcp_sessions WHERE visitor_id = %s",
            $visitor_id
        ));

        if ( $sessions ) {
            $ids = implode(',', array_map('intval', $sessions));
            $wpdb->query("DELETE FROM {$wpdb->prefix}lcp_messages WHERE session_id IN ({$ids})");
            $wpdb->query("DELETE FROM {$wpdb->prefix}lcp_events WHERE session_id IN ({$ids})");
        }

        $wpdb->delete( $wpdb->prefix . 'lcp_sessions', ['visitor_id' => $visitor_id] );
        $wpdb->delete( $wpdb->prefix . 'lcp_contacts', ['visitor_id' => $visitor_id] );
        return true;
    }
}
