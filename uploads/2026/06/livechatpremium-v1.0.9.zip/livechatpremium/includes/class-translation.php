<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Translation {

    const API_URL = 'https://api.mymemory.translated.net/get';

    public static function translate( $text, $from = 'auto', $to = 'fr' ) {
        if ( ! get_option('lcp_translation_enabled') ) return $text;
        if ( empty(trim($text)) ) return $text;

        $cache_key = 'lcp_trans_' . md5($text . $from . $to);
        $cached    = get_transient($cache_key);
        if ( $cached !== false ) return $cached;

        $response = wp_remote_get( add_query_arg([
            'q'        => urlencode($text),
            'langpair' => ($from === 'auto' ? 'autodetect' : $from) . '|' . $to,
            'de'       => get_option('admin_email'),
        ], self::API_URL), ['timeout' => 5]);

        if ( is_wp_error($response) ) return $text;

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $translated = $body['responseData']['translatedText'] ?? $text;

        // Cache 1 heure
        set_transient($cache_key, $translated, HOUR_IN_SECONDS);
        return $translated;
    }

    public static function detect_language( $text ) {
        $response = wp_remote_get( add_query_arg([
            'q'        => urlencode(substr($text, 0, 100)),
            'langpair' => 'autodetect|en',
        ], self::API_URL), ['timeout' => 5]);

        if ( is_wp_error($response) ) return 'unknown';
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['responseData']['detectedLanguage'] ?? 'unknown';
    }

    public static function get_supported_languages() {
        return [
            'fr' => 'Français',    'en' => 'English',
            'ar' => 'العربية',     'es' => 'Español',
            'de' => 'Deutsch',     'it' => 'Italiano',
            'pt' => 'Português',   'nl' => 'Nederlands',
            'ru' => 'Русский',     'zh' => '中文',
            'ja' => '日本語',       'tr' => 'Türkçe',
        ];
    }
}
