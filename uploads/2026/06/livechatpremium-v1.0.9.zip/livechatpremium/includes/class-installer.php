<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Installer {

    public static function activate() {
        self::create_tables();
        self::migrate();
        self::set_defaults();
        flush_rewrite_rules();
        update_option( 'lcp_db_version', LCP_DB_VERSION );
    }

    public static function migrate() {
        global $wpdb;
        $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}lcp_sessions" );
        if ( ! in_array('visitor_name', $cols) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}lcp_sessions ADD COLUMN visitor_name  VARCHAR(191) DEFAULT '' AFTER visitor_id" );
        }
        if ( ! in_array('visitor_phone', $cols) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}lcp_sessions ADD COLUMN visitor_phone VARCHAR(64)  DEFAULT '' AFTER visitor_name" );
        }
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Table sessions visiteurs
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}lcp_sessions (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_token VARCHAR(64)     NOT NULL UNIQUE,
            visitor_id    VARCHAR(64)     NOT NULL,
            ip_address    VARCHAR(64)     DEFAULT '',
            ip_hash       VARCHAR(64)     DEFAULT '',
            country       VARCHAR(64)     DEFAULT '',
            city          VARCHAR(64)     DEFAULT '',
            os            VARCHAR(64)     DEFAULT '',
            browser       VARCHAR(64)     DEFAULT '',
            device        VARCHAR(32)     DEFAULT '',
            page_url      TEXT,
            referrer      TEXT,
            user_agent    TEXT,
            status        ENUM('waiting','active','closed','missed') DEFAULT 'waiting',
            score         TINYINT UNSIGNED DEFAULT 0,
            consent       TINYINT(1)      DEFAULT 0,
            agent_id      BIGINT UNSIGNED DEFAULT 0,
            started_at    DATETIME        DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            closed_at     DATETIME        DEFAULT NULL,
            PRIMARY KEY (id),
            KEY visitor_id (visitor_id),
            KEY status (status),
            KEY started_at (started_at),
            KEY agent_id (agent_id)
        ) $charset;");

        // Table messages
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}lcp_messages (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id   BIGINT UNSIGNED NOT NULL,
            sender_type  ENUM('visitor','agent','bot') NOT NULL DEFAULT 'visitor',
            sender_id    BIGINT UNSIGNED DEFAULT 0,
            type         ENUM('text','image','audio','file','pdf','link','page','product','system') DEFAULT 'text',
            content      LONGTEXT,
            file_url     TEXT,
            file_name    VARCHAR(255)    DEFAULT '',
            file_size    INT UNSIGNED    DEFAULT 0,
            metadata     JSON,
            is_read      TINYINT(1)      DEFAULT 0,
            sent_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
            read_at      DATETIME        DEFAULT NULL,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY sent_at (sent_at),
            KEY sender_type (sender_type),
            KEY is_read (is_read)
        ) $charset;");

        // Table contacts CRM
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}lcp_contacts (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            email          VARCHAR(191)    DEFAULT '',
            name           VARCHAR(191)    DEFAULT '',
            phone          VARCHAR(64)     DEFAULT '',
            visitor_id     VARCHAR(64)     DEFAULT '',
            wp_user_id     BIGINT UNSIGNED DEFAULT 0,
            tags           TEXT,
            notes          TEXT,
            segments       TEXT,
            total_sessions INT UNSIGNED    DEFAULT 0,
            total_messages INT UNSIGNED    DEFAULT 0,
            last_seen      DATETIME        DEFAULT NULL,
            created_at     DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY email (email),
            KEY visitor_id (visitor_id),
            KEY wp_user_id (wp_user_id)
        ) $charset;");

        // Table événements (navigation, comportement)
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}lcp_events (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id BIGINT UNSIGNED NOT NULL,
            type       VARCHAR(64)     NOT NULL,
            page_url   TEXT,
            payload    JSON,
            created_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY type (type),
            KEY created_at (created_at)
        ) $charset;");

        // Table agents
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}lcp_agents (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            wp_user_id   BIGINT UNSIGNED NOT NULL UNIQUE,
            display_name VARCHAR(191)    DEFAULT '',
            avatar_url   TEXT,
            status       ENUM('online','away','offline') DEFAULT 'offline',
            max_chats    TINYINT UNSIGNED DEFAULT 5,
            last_seen    DATETIME        DEFAULT NULL,
            created_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY wp_user_id (wp_user_id),
            KEY status (status)
        ) $charset;");

        // Table réponses prédéfinies
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}lcp_canned (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            shortcut   VARCHAR(64)     NOT NULL,
            title      VARCHAR(191)    NOT NULL,
            content    TEXT            NOT NULL,
            category   VARCHAR(64)     DEFAULT '',
            agent_id   BIGINT UNSIGNED DEFAULT 0,
            created_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY shortcut (shortcut),
            KEY agent_id (agent_id)
        ) $charset;");
    }

    public static function set_defaults() {
        $defaults = [
            'lcp_pusher_app_id'      => '',
            'lcp_pusher_key'         => '',
            'lcp_pusher_secret'      => '',
            'lcp_pusher_cluster'     => 'eu',
            'lcp_pusher_beams_id'    => '',
            'lcp_groq_api_key'       => '',
            'lcp_groq_model'         => 'llama-3.1-70b-versatile',
            'lcp_site_domain'        => home_url(),
            'lcp_widget_position'    => 'bottom-right',
            'lcp_widget_color'       => '#6366f1',
            'lcp_widget_icon'        => 'chat',
            'lcp_widget_text'        => 'Besoin d\'aide ?',
            'lcp_widget_size'        => 'medium',
            'lcp_popup_height'       => '500',
            'lcp_popup_width'        => '380',
            'lcp_online_message'     => 'Bonjour ! Comment puis-je vous aider ?',
            'lcp_offline_message'    => 'Nous sommes absents. Laissez-nous un message !',
            'lcp_rgpd_enabled'       => '1',
            'lcp_rgpd_text'          => 'En utilisant ce chat, vous acceptez notre politique de confidentialité.',
            'lcp_rgpd_retention'     => '90',
            'lcp_ai_enabled'         => '0',
            'lcp_translation_enabled'=> '0',
            'lcp_bot_enabled'        => '0',
            'lcp_bot_name'           => 'Assistant',
            'lcp_file_upload_enabled'=> '1',
            'lcp_max_file_size'      => '5',
            'lcp_allowed_file_types' => 'jpg,jpeg,png,gif,pdf,mp3,ogg,wav',
            'lcp_license_key'        => '',
            'lcp_license_status'     => 'free',
            'lcp_business_hours'     => json_encode([
                'enabled' => false,
                'timezone'=> 'Africa/Casablanca',
                'hours'   => [
                    'monday'   => ['open'=>'09:00','close'=>'18:00','enabled'=>true],
                    'tuesday'  => ['open'=>'09:00','close'=>'18:00','enabled'=>true],
                    'wednesday'=> ['open'=>'09:00','close'=>'18:00','enabled'=>true],
                    'thursday' => ['open'=>'09:00','close'=>'18:00','enabled'=>true],
                    'friday'   => ['open'=>'09:00','close'=>'18:00','enabled'=>true],
                    'saturday' => ['open'=>'09:00','close'=>'13:00','enabled'=>false],
                    'sunday'   => ['open'=>'09:00','close'=>'18:00','enabled'=>false],
                ]
            ]),
        ];

        foreach ( $defaults as $key => $value ) {
            if ( get_option( $key ) === false ) {
                add_option( $key, $value );
            }
        }
    }
}

