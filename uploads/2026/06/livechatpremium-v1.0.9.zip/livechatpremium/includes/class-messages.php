<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * LCP_Messages — Helpers formatage et envoi de messages
 */
class LCP_Messages {

    public static function format( $msg ) {
        return [
            'id'          => (int) $msg->id,
            'session_id'  => (int) $msg->session_id,
            'sender_type' => $msg->sender_type,
            'sender_name' => $msg->sender_name ?? '',
            'type'        => $msg->type,
            'content'     => $msg->content,
            'file_url'    => $msg->file_url ?? '',
            'file_name'   => $msg->file_name ?? '',
            'metadata'    => json_decode( $msg->metadata ?? '{}', true ),
            'is_read'     => (bool) $msg->is_read,
            'sent_at'     => $msg->sent_at,
            'read_at'     => $msg->read_at ?? null,
        ];
    }

    public static function format_many( $msgs ) {
        return array_map( [__CLASS__, 'format'], (array) $msgs );
    }

    public static function system_message( $session_id, $content ) {
        return LCP_Database::save_message([
            'session_id'  => $session_id,
            'sender_type' => 'bot',
            'type'        => 'system',
            'content'     => $content,
        ]);
    }

    public static function get_type_label( $type ) {
        $labels = [
            'text'    => 'Texte',
            'image'   => 'Image',
            'audio'   => 'Audio',
            'file'    => 'Fichier',
            'pdf'     => 'PDF',
            'link'    => 'Lien',
            'page'    => 'Page',
            'product' => 'Produit',
            'system'  => 'Système',
        ];
        return $labels[ $type ] ?? $type;
    }
}
