<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Upload {

    public static function handle_upload( $request ) {
        if ( empty($_FILES['file']) ) {
            return new WP_Error('no_file', 'Aucun fichier reçu.', ['status'=>400]);
        }

        $max_mb   = (int) get_option('lcp_max_file_size', 5);
        $max_size = $max_mb * 1024 * 1024;
        $allowed  = array_map('trim', explode(',', get_option('lcp_allowed_file_types', 'jpg,jpeg,png,gif,pdf,mp3,ogg,wav,webp,m4a')));

        $file = $_FILES['file'];
        $name = sanitize_file_name($file['name']);
        $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $size = (int) $file['size'];
        $tmp  = $file['tmp_name'];

        // Validation taille
        if ( $size > $max_size ) {
            return new WP_Error('too_large', "Fichier trop volumineux. Max : {$max_mb}Mo.", ['status'=>400]);
        }

        // Validation extension
        if ( !in_array($ext, $allowed) ) {
            return new WP_Error('bad_type', "Type .{$ext} non autorisé.", ['status'=>400]);
        }

        // Validation MIME (avec fallback si finfo absent)
        $mime_map = [
            'jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png',
            'gif'=>'image/gif','webp'=>'image/webp','pdf'=>'application/pdf',
            'mp3'=>'audio/mpeg','ogg'=>'audio/ogg','wav'=>'audio/wav','m4a'=>'audio/mp4',
        ];

        if ( function_exists('finfo_open') ) {
            $finfo    = finfo_open(FILEINFO_MIME_TYPE);
            $detected = finfo_file($finfo, $tmp);
            finfo_close($finfo);
            if ( isset($mime_map[$ext]) ) {
                // Vérification souple : même famille MIME
                $expected_type = explode('/', $mime_map[$ext])[0]; // 'image', 'audio', 'application'
                $detected_type = explode('/', $detected)[0];
                // Exception : les blobs audio JS peuvent être 'application/octet-stream'
                $is_audio_ext = in_array($ext, ['mp3','ogg','wav','m4a']);
                $is_octet     = ($detected === 'application/octet-stream');
                if ( $detected_type !== $expected_type && !($is_audio_ext && $is_octet) ) {
                    // Log mais ne pas bloquer en prod mutualisé
                    error_log("LCP Upload: MIME mismatch ext={$ext} detected={$detected} expected={$mime_map[$ext]}");
                    // On accepte quand même si l'extension est valide
                }
            }
        }

        // Dossier upload sécurisé
        $upload_dir = wp_upload_dir();
        $lcp_dir    = $upload_dir['basedir'] . '/livechatpremium/' . date('Y/m');
        $lcp_url    = $upload_dir['baseurl'] . '/livechatpremium/' . date('Y/m');

        if ( ! wp_mkdir_p($lcp_dir) ) {
            return new WP_Error('mkdir_failed', 'Impossible de créer le dossier upload.', ['status'=>500]);
        }

        // Protéger le dossier
        $htaccess = dirname($lcp_dir) . '/.htaccess';
        if ( !file_exists($htaccess) ) {
            file_put_contents($htaccess, "Options -Indexes\n");
        }

        // Nom unique sécurisé
        $safe_name = 'lcp_' . time() . '_' . wp_generate_password(8, false) . '.' . $ext;
        $dest      = $lcp_dir . '/' . $safe_name;

        if ( !move_uploaded_file($tmp, $dest) ) {
            // Fallback : copy + unlink
            if ( !copy($tmp, $dest) ) {
                return new WP_Error('upload_failed', "Échec de l'upload. Vérifiez les permissions.", ['status'=>500]);
            }
            @unlink($tmp);
        }

        $file_url  = $lcp_url . '/' . $safe_name;
        $msg_type  = self::get_type($ext);

        return rest_ensure_response([
            'success'  => true,
            'url'      => $file_url,
            'name'     => $file['name'],
            'size'     => $size,
            'type'     => $msg_type,
            'ext'      => $ext,
        ]);
    }

    private static function get_type($ext) {
        if ( in_array($ext, ['jpg','jpeg','png','gif','webp']) ) return 'image';
        if ( $ext === 'pdf' )                                    return 'pdf';
        if ( in_array($ext, ['mp3','ogg','wav','m4a']) )         return 'audio';
        return 'file';
    }
}
