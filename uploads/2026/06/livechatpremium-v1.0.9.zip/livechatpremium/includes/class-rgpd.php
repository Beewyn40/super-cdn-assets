<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_Rgpd {

    public function __construct() {
        add_action( 'wp_ajax_lcp_delete_my_data',        [$this, 'ajax_delete'] );
        add_action( 'wp_ajax_nopriv_lcp_delete_my_data', [$this, 'ajax_delete'] );
    }

    public static function is_required() {
        return (bool) get_option('lcp_rgpd_enabled', 1);
    }

    public static function get_consent_text() {
        return get_option('lcp_rgpd_text',
            'En utilisant ce chat, vous acceptez notre <a href="' . esc_url(get_privacy_policy_url()) . '" target="_blank">politique de confidentialité</a>. Vos données (navigateur, pays) sont utilisées uniquement pour améliorer votre expérience.'
        );
    }

    public static function get_retention_days() {
        return (int) get_option('lcp_rgpd_retention', 90);
    }

    public function ajax_delete() {
        $visitor_id = sanitize_text_field( $_POST['visitor_id'] ?? '' );
        if ( ! $visitor_id ) wp_send_json_error('missing_visitor_id');
        LCP_Database::delete_visitor_data($visitor_id);
        wp_send_json_success(['message' => __('Vos données ont été supprimées.', 'livechatpremium')]);
    }

    // Anonymiser une IP
    public static function anonymize_ip( $ip ) {
        if ( filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ) {
            return substr($ip, 0, strrpos($ip, '.')) . '.0';
        }
        if ( filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ) {
            return substr($ip, 0, strrpos($ip, ':')) . ':0:0:0:0';
        }
        return '0.0.0.0';
    }
}
