<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LCP_WooCommerce {

    public static function is_active() {
        return class_exists('WooCommerce');
    }

    public static function search( $query, $type = 'product', $limit = 10 ) {
        if ( ! self::is_active() ) return [];

        $results = [];

        if ( $type === 'product' || $type === 'all' ) {
            $products = wc_get_products([
                's'      => $query,
                'limit'  => $limit,
                'status' => 'publish',
            ]);
            foreach ( $products as $product ) {
                $results[] = [
                    'id'        => $product->get_id(),
                    'type'      => 'product',
                    'title'     => $product->get_name(),
                    'url'       => get_permalink($product->get_id()),
                    'price'     => $product->get_price_html(),
                    'price_raw' => (float) $product->get_price(),
                    'image'     => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail'),
                    'sku'       => $product->get_sku(),
                    'stock'     => $product->is_in_stock() ? __('En stock', 'livechatpremium') : __('Rupture', 'livechatpremium'),
                    'category'  => implode(', ', wp_get_post_terms($product->get_id(), 'product_cat', ['fields'=>'names'])),
                ];
            }
        }

        if ( $type === 'category' || $type === 'all' ) {
            $cats = get_terms([
                'taxonomy'   => 'product_cat',
                'search'     => $query,
                'number'     => 5,
                'hide_empty' => true,
            ]);
            foreach ( (array)$cats as $cat ) {
                if ( is_wp_error($cat) ) continue;
                $results[] = [
                    'id'    => $cat->term_id,
                    'type'  => 'category',
                    'title' => $cat->name,
                    'url'   => get_term_link($cat),
                    'count' => $cat->count,
                    'image' => '',
                ];
            }
        }

        return $results;
    }

    public static function get_product_card( $product_id ) {
        if ( ! self::is_active() ) return null;
        $product = wc_get_product($product_id);
        if ( ! $product ) return null;

        return [
            'id'          => $product->get_id(),
            'title'       => $product->get_name(),
            'description' => wp_trim_words($product->get_short_description(), 20),
            'price'       => $product->get_price_html(),
            'url'         => get_permalink($product->get_id()),
            'image'       => wp_get_attachment_image_url($product->get_image_id(), 'medium') ?: wc_placeholder_img_src(),
            'sku'         => $product->get_sku(),
            'stock'       => $product->is_in_stock(),
            'rating'      => $product->get_average_rating(),
            'add_to_cart' => $product->add_to_cart_url(),
        ];
    }

    public static function format_message_payload( $product_id ) {
        $card = self::get_product_card($product_id);
        if ( ! $card ) return null;
        return [
            'type'     => 'product',
            'content'  => $card['title'],
            'file_url' => $card['url'],
            'metadata' => $card,
        ];
    }
}
